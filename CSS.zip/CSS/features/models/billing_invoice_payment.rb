class BillingInvoicePayment < BillingEntity
  self.table_name = 'BLNG_INVOICE_PAYMENT_STATUS'

end