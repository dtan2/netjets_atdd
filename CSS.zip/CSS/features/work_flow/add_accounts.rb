module AddAccounts

  def add_account_from_manage_account
    on(HomePage).payments_and_invoices
    on(UnpaidInvoicePage).manage_accounts
    on(ManageAccountsPage).add_account
    Session[:bank_account_details] = on(BankAccountDetailsPage).submit_bank_account_details()

  end

  alias :add_another_account_from_manage_account :add_account_from_manage_account

  def add_identical_accounts_from_manage_account(account_details = nil)
    goto_invoices_from_login
    invoice = on(UnpaidInvoicePage).select_payable_invoice
    if invoice
      on(UnpaidInvoicePage).continue
      on(EnterPaymentDetailsPage).wait_for_ajax
      on(EnterPaymentDetailsPage).add_account
      Session[:bank_account_details] = on(BankAccountDetailsPage).submit_bank_account_details(account_details)

      on(EnterPaymentDetailsPage).wait_for_ajax
      on(EnterPaymentDetailsPage).add_account
      on(BankAccountDetailsPage).submit_bank_account_details(Session[:bank_account_details])
    else
      pending 'Could not find any invoices to select'
    end
  end

  def add_account_from_auto_pay
    on(HomePage).payments_and_invoices
    on(UnpaidInvoicePage).auto_pay
    on(AutoPayPage).add_account
    Session[:bank_account_details] = on(BankAccountDetailsPage).submit_bank_account_details()
  end

  def add_accounts_single_payment(account_details = nil)
    goto_invoices_from_login
    invoice = on(UnpaidInvoicePage).select_payable_invoice
    if invoice
      on(UnpaidInvoicePage).continue
      on(EnterPaymentDetailsPage).wait_for_ajax
      add_account_from_enter_payment_details(account_details)
    else
      pending 'Could not find any invoices to select'
    end
  end

  def add_account_from_enter_payment_details(account_details = nil)
    on(EnterPaymentDetailsPage).add_account

    Session[:bank_account_details] = on(BankAccountDetailsPage).submit_bank_account_details(account_details)
  end

  def cancel_add_bank_account(account_details = nil)
    goto_invoices_from_login
    on(UnpaidInvoicePage).select_payable_invoice
    on(UnpaidInvoicePage).continue
    on(EnterPaymentDetailsPage).wait_for_ajax
    on(EnterPaymentDetailsPage).add_account

    Session[:bank_account_details] = on(BankAccountDetailsPage).cancel_add_bank_acct_details(account_details)
  end

  def cancel_add_accounts_from_manage_account
    on(HomePage).payments_and_invoices
    on(UnpaidInvoicePage).manage_accounts
    on(ManageAccountsPage).add_account
    Session[:bank_account_details] = on(BankAccountDetailsPage).cancel_bank_account_details()
  end

  def find_account_with_nickname(account_nickname)
    on(EnterPaymentDetailsPage).added_bank_accounts_options.find { |bank_account| bank_account.include? account_nickname }
  end

  def format_matching_bank_acount(nickname, last_four)
    nickname[0..19] + '...' + last_four
  end

end

World AddAccounts