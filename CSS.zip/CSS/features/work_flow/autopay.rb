module Autopay

  def select_autopays_to_enroll(autopay_details)
    goto_invoices_from_login
    on(UnpaidInvoicePage).autopay_setup
    on(AutopaySetupPage) do |page|
      page.setup_autopay_for(autopay_details[:contract], autopay_details[:invoice_type])
      page.bank_account = autopay_details[:bank_account]
      page.continue
    end
  end

  def accept_terms_and_conditions
    on(AutopayTermsPage) do |page|
      page.accept_terms_check
      terms = page.terms_and_conditions
      page.continue
      terms
    end
  end

end

World Autopay