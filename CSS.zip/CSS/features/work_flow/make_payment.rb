module MakePayment


  def make_a_full_payment_on_a_single_invoice
    goto_invoices_from_login
    on(UnpaidInvoicePage).select_payable_invoice
    on(UnpaidInvoicePage).continue
    on(EnterPaymentDetailsPage).wait_for_ajax
    on(EnterPaymentDetailsPage).pay_selected_invoices

    payment_details = on(EnterPaymentDetailsPage).payment_details
    on(EnterPaymentDetailsPage).continue
    confirm_and_submit_payment
    payment_details
  end

  def use_default_payment_details

    on(EnterPaymentDetailsPage).continue
  end

  def confirm_and_submit_payment

    on(ConfirmSubmitPaymentPage).accept_terms_authorize_payment
    on(ConfirmSubmitPaymentPage).continue
  end

  def payment_confirmation_details
    on(PaymentConfirmationPage).confirmation_details
  end

  def select_not_payable_invoice (amount)
    on(HomePage).payments_and_invoices
    on(UnpaidInvoicePage).select_not_payable_invoice(amount)
    on(UnpaidInvoicePage).can_continued
  end

  def pay_invoice_without_bank_acct
    login_as(Login::USERWITHOUTBANKACCT)
    goto_invoices_from_login
    on(UnpaidInvoicePage).select_payable_invoice
    on(UnpaidInvoicePage).continue
    on(EnterPaymentDetailsPage).wait_for_ajax
    on(EnterPaymentDetailsPage).pay_selected_invoices

  end

  def view_enter_payment_details_page
    goto_invoices_from_login
    on(UnpaidInvoicePage).select_payable_invoice
    on(UnpaidInvoicePage).continue
    on(EnterPaymentDetailsPage).wait_for_ajax
  end

  def submit_payment_without_terms
    login_as(Login::USERWITHUNPAIDINVOICES)
    goto_invoices_from_login
    on(UnpaidInvoicePage).select_payable_invoice
    on(UnpaidInvoicePage).continue
    on(EnterPaymentDetailsPage).wait_for_ajax
    on(EnterPaymentDetailsPage).pay_selected_invoices
    on(EnterPaymentDetailsPage).payment_details
    on(EnterPaymentDetailsPage).continue
  end

  def pay_more_than_full_balance
    login_as(Login::USERWITHUNPAIDINVOICES)
    goto_invoices_from_login
    on(UnpaidInvoicePage).select_payable_invoice
    on(UnpaidInvoicePage).continue
    on(EnterPaymentDetailsPage).wait_for_ajax
    on(EnterPaymentDetailsPage).payment_type_custom_amount
    Session[:invoice_amount] = on(EnterPaymentDetailsPage).find_selected_invoice_amount
    on(EnterPaymentDetailsPage).custom_payment_amount = (Session[:invoice_amount] + 0.01)
    on(EnterPaymentDetailsPage).continue

  end

  def make_a_full_payment_on_multiple_invoices
    goto_invoices_from_login
    on(UnpaidInvoicePage).select_multiple_payable_invoices
    on(UnpaidInvoicePage).continue
    on(EnterPaymentDetailsPage).wait_for_ajax
    on(EnterPaymentDetailsPage).pay_selected_invoices

    payment_details = on(EnterPaymentDetailsPage).payment_details
    on(EnterPaymentDetailsPage).continue
    confirm_and_submit_payment
    payment_details
  end


  def pay_multiple_invoices_without_bank_acct
    goto_invoices_from_login
    on(UnpaidInvoicePage).select_payable_invoice
    on(UnpaidInvoicePage).select_payable_invoice
    on(UnpaidInvoicePage).continue
  end

  def submit_payment_without_terms_on_multiple_invoices
    goto_invoices_from_login
    on(UnpaidInvoicePage).select_multiple_payable_invoices
    on(UnpaidInvoicePage).continue
    on(EnterPaymentDetailsPage).wait_for_ajax
    on(EnterPaymentDetailsPage).pay_selected_invoices
    on(EnterPaymentDetailsPage).continue
  end

  def delete_unprocessed_payments
    delete_payment_session = BrowserSelector.create_browser ENV['TEST_BROWSER'] || 'chrome'
    delete_payment_session.goto(select_login_url('opop_clear_payments'))
    delete_payment_session.text_field(id: 'username').set 'mgraf'
    delete_payment_session.text_field(id: 'password').set 'Timg2pw4w09'
    delete_payment_session.button(text: /Login/).click
    Watir::Wait.until { delete_payment_session.text.include? 'Invoice Payment Statuses purged' }
    delete_payment_session.close
  end

  def pay_invoices(invoice_numbers)
    on(UnpaidInvoicePage).select_invoices(invoice_numbers)
    on(UnpaidInvoicePage).continue
    on(EnterPaymentDetailsPage).wait_for_ajax
  end

  def partial_payment_without_terms(amount = nil)
    login_as(Login::USERWITHUNPAIDINVOICES)
    goto_invoices_from_login
    on(UnpaidInvoicePage) do |page|
      page.select_payable_invoice
      page.continue
    end
    on(EnterPaymentDetailsPage) do |page|
      page.wait_for_ajax
      page.payment_type_custom_amount = amount
      payment_details = page.payment_details :custom
      page.continue
      payment_details
    end


  end

  def apply_partial_payment(amount)
    goto_invoices_from_login
    invoice = on(UnpaidInvoicePage).select_payable_invoice
    due = invoice.due
    on(UnpaidInvoicePage).continue
    payment_details = enter_payment_details(amount, due)
    confirm_and_submit_payment
    payment_details
  end

  def partially_pay_invoice_type(type)
    invoice = on(UnpaidInvoicePage).select_payable_invoice_type(type)
    due = invoice.due
    on(UnpaidInvoicePage).continue
    payment_details = enter_payment_details(0.01, due)
    confirm_and_submit_payment
    payment_details
  end

  def enter_payment_details(amount, due)
    on(EnterPaymentDetailsPage) do |page|
      page.wait_for_ajax
      page.payment_type_custom_amount = amount
      payment_details = page.payment_details :custom
      payment_details.merge!({:due => due})
      page.continue
      return payment_details
    end
  end

  def goto_invoices_from_login
    on(HomePage) do |page|
      page.select_account_invoice
      page.payments_and_invoices
    end
  end

end

World MakePayment