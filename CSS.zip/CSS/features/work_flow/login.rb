module Login

  NONFINANCIALUSER = 'l.baru@any.domain.cc'
  USERWITHUNPAIDINVOICES = 'ascribante@netjets.com'
  USERWITHUNPAIDINVOICES2 = 't.olofson@any.domain.cc'
  USERWITHNOUNPAIDINVOICES = 'invoice1@netjets.com'
  NJEUSERWITHINVOICES = 'nje@netjets.com'
  USERWITHOUTBANKACCT = 'nobankaccount@netjets.com'
  USERWITHMULTIPLEBANKACCTS = ''
  TESTUSER = 'tim.chaloner@ge.domain.xy'
  USER1ACCOUNTA = ''
  USER2ACCOUNTA = ''

  def login_as(user)
    visit(LoginPage).login_as(user)
    on(HomePage).verify_on_home_page
  end
end

World Login