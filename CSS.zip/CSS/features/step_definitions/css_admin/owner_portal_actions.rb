When(/^enrollment status is (.+) click on (.+)$/) do |enrStatus, menuItem|
  #sleep 4
  #@index = on_page(IndividualPage).select_action_in_all_pages(enrStatus,menuItem)
  Session[:question] = 'nickname'
  Session[:answer] = 'bobo'
  Session[:password] = 'abc123ABC'
  on(IndividualPage).enroll_a_not_enrolled_user
  #on_page(IndividualPage).enrollment("xyz@netjets.com", "What is the middle name of your oldest child?", "abc")
end

#When(/^I enter individual email address  "(.*)" and choose security Question "(.*)" and security Answer "(.*)" and click enroll$/) do |arg1, arg2, arg3|
#  on_page(IndividualPage).enrollment(arg1, arg2, arg3)
#  I enter individual email address  <Email Address> and choose security Question <Security Question> and security Answer dasfdas and click enroll
#end


When(/^I enter individual email address  (.*) and choose security Question (.*) and security (.*) and click enroll$/) do |email, question, answer|
  #on_page(IndividualPage).enrollment(arg1, arg2, arg3)
  Session[:user_id] = on_page(IndividualPage).get_first_not_enrolled_user_id
    on_page(IndividualPage).enroll_user(Session[:user_id],question,answer,email)
end

When(/^I enter a blank security answer and click enroll$/) do
  #on_page(IndividualPage).enrollment(arg1, arg2, arg3)
  Session[:user_id] = on_page(IndividualPage).get_first_not_enrolled_user_id
  Session[:question] = 'nickname'
  Session[:answer] = 'bobo'
  Session[:password] = 'abc123ABC'
  Session[:user]
  on_page(IndividualPage).enroll_user(Session[:user_id], Session[:question],'null',Session[:email])
end

Then(/^I should verify the "([^"]*)" changes the enrollment status "([^"]*)"$/) do |arg1, arg2|
  sleep 5
  on_page(IndividualPage).verify_action(@index,arg1 ,arg2)

  # Delete enrollment
  @index = on_page(IndividualPage).select_action_in_all_pages('PENDING','Delete Enrollment')
  on_page(IndividualPage).confirmation_yes
end


Given(/^enrollment request email is sent to user and I click on Complete your enrollment email link$/) do
  ####Include pre requistes ##############

#Given user is logged into CSS Admin
#    map = DataHelper.get_data_map('TestAccount')
#    on_page LoginPage do |page|
#    page.set_login_username_password  map
#    end

    step "user is logged into CSS Admin"
# When I search for the account Goodtime Aviation, L.L.C.
    InputDataHelper.load_yml("css_admin_data")
    map =InputDataHelper.get_map('AccountStatus')

    @account = on_page(AccountSearchPage).set_account_search_field('Account_Name',map)
#And Select the account
    on_page AccountSearchPage do |page|
    page.select_account @account
    end
# When enrollment status is NOT ENROLLED click on Enroll
    @index = on_page(IndividualPage).select_action_in_all_pages('NOT ENROLLED','Enroll')
#And I enter email address "complete_enrollment@netjets.com" and choose security Question "What is the middle name of your oldest child?" and security Answer "abc" and click enroll
    on_page(IndividualPage).enrollment("complete_enrollment@netjets.com", "What is the middle name of your oldest child?", "abc")

enrollmentLink = on_page(IndividualPage).input_box "Please Enter the URL from the Email that you have recieved:", "Warning!!!!!"
on_page(EnrollPage).set_enrollment_link_in_new_browser enrollmentLink
end

When(/^I enter security Answer "([^"]*)" and Password to complete enrollment$/) do |arg|
  on_page(EnrollPage).set_security_question(arg)
  on_page(EnrollPage).set_next_button
  on_page(EnrollPage).complete_enrollment
end

When(/^I select Secret Question (.+) and enter answer$/) do |question|
  @answer = on_page(IndividualPage).update_questionanswer(question)
end

When(/^Click on Update button$/) do
  on_page(IndividualPage).update_button
end

Then(/^I  should verify the "([^"]*)" is (.*)$/) do |arg, question|
  on_page(IndividualPage).verify_action(@index,arg ,question)
end



Then(/^I  should verify the "([^"]*)"$/) do |arg|
  on_page(IndividualPage).verify_action(@index ,arg, @answer)
end

When(/^I Select Individual with email address "([^"]*)" whose security question\/answer has been updated and click on "([^"]*)".$/) do |arg1, arg2|
  @index = on_page(IndividualPage).select_action_in_all_pages(arg1,arg2)
end


Then(/^Verify that View activity has a audit of security question answer update with (.*), (.*), (.*), (.*)$/) do |user_id, event_description, date_created, created_by|
    InputDataHelper.load_yml("css_login")
    map =InputDataHelper.get_map('css_admin_test_account')
    on_page(IndividualPage).verify_view_activity user_id, event_description, date_created, map['username']
end

Then(/^I  should verify the message "([^"]*)"$/) do |arg|
 on_page(LoginPage).verify_text_resend_enrollment arg
end
#When(/^enrollment status is (.*), verify that OSR is eligible to (.*)$/) do |enrollment_status, action_item|
#  on_page(IndividualPage).verify_action_in_all_pages enrollment_status, action_item
#end

#When(/^enrollment status is (.*), verify that OSR is eligible to (.*)$/) do |enrollment_status, action_item|
#  on_page(IndividualPage).verify_action_in_all_pages enrollment_status, action_item
#end

Then(/^Verify that individual page have (.+) or less than (.+) individuals on each pages$/) do |arg1, arg2|
  on_page(IndividualPage).verify_pagination
end
When(/^Enter individual (.*) to search for individual$/) do |arg|
  on_page(IndividualPage).individual_search_by_last_name arg
end
Then(/^I  should verify the results "([^"]*)"$/) do |arg|
  sleep 5
  on_page(IndividualPage).verify_text_enrollment_page arg
end
When(/^I enter individual email address and choose security Question and security Answer and click enroll$/) do
  #on_page(IndividualPage).enrollment(arg1, arg2, arg3)
  on_page(IndividualPage).enrollment("test_enrollment@netjets.com", "What is the middle name of your oldest child?", "abc")
end
When(/^I enter security Answer "([^"]*)"$/) do |arg|
  on_page(EnrollPage).set_security_question(arg)
  on_page(EnrollPage).set_next_button
end
When(/^I enter five bad security Answer "([^"]*)"$/) do |arg|
  on_page(EnrollPage).set_security_question(arg)
  on_page(EnrollPage).set_next_button
  on_page(EnrollPage).set_security_question(arg)
  on_page(EnrollPage).set_next_button
  on_page(EnrollPage).set_security_question(arg)
  on_page(EnrollPage).set_next_button
  on_page(EnrollPage).set_security_question(arg)
  on_page(EnrollPage).set_next_button
  on_page(EnrollPage).set_security_question(arg)
  on_page(EnrollPage).set_next_button
end
When(/^I enter security Answer "([^"]*)" and enter two different Passwords to complete enrollment$/) do |arg|
  on_page(EnrollPage).set_security_question(arg)
  on_page(EnrollPage).set_next_button
  on_page(EnrollPage).complete_enrollment_password_mismatch
end
Then(/^open a new browser$/) do
  on_page(EnrollPage).new_browser_css_admin
end
When(/^I Select Individual with email address "([^"]*)" and click on "([^"]*)".$/) do |arg1, arg2|
sleep 4
@index = on_page(IndividualPage).select_action_in_all_pages(arg1,arg2)
end

Then(/^Verify that View activity has a audit of complete enrollment with (.*), (.*), (.*), (.*)$/) do |user_id, event_description, date_created, created_by|
  on_page(IndividualPage).verify_view_activity user_id, event_description, date_created, created_by
end

Given(/^user is logged into Owner's portal with (.*) and (.*)$/) do |arg1, arg2|
  sleep 10
  on_page(EnrollPage).Owner_portal_login arg1, arg2
end
Then(/^I should verify the message "([^"]*)"$/) do |arg|
  on_page(CssAdminLoginPage).verify_OP_landingpage arg
end
Then(/^Verify that View activity has a audit of disabling the enrollment with (.*), (.*), (.*), (.*)$/) do |user_id, event_description, date_created, created_by|
  #InputDataHelper.load_yml("css_login")
  map =InputDataHelper.get_map('css_admin_test_account')
  on_page(IndividualPage).verify_view_activity user_id, event_description, date_created, map['username']
end

Then(/^Verify that View activity has a audit of enabling the enrollment with (.*), (.*), (.*), (.*)$/) do |user_id, event_description, date_created, created_by|
  #InputDataHelper.load_yml("css_login")
  map =InputDataHelper.get_map('css_admin_test_account')
  on_page(IndividualPage).verify_view_activity user_id, event_description, date_created, map['username']
end
Then(/^Verify that View activity has a audit of resend enrollment with (.*), (.*), (.*), (.*)$/) do |user_id, event_description, date_created, created_by|
  #InputDataHelper.load_yml("css_login")
  map =InputDataHelper.get_map('css_admin_test_account')
  on_page(IndividualPage).verify_view_activity user_id, event_description, date_created, map['username']
end

When(/^Click yes$/) do
  sleep 4
  on_page(IndividualPage).confirmation_yes
end
#When(/^enrollment status is  verify that OSR is eligible to $/) do | table|
#  # table is a | Account | ACTIVE            | View Activity            |
#  table.hashes.each do |items|
#    on_page(IndividualPage).verify_action_in_all_pages enrollment_status, action_item items['enrollment_status', 'action_item']
#  end
#end
When(/^enrollment status is Enrollment_status verify that OSR is eligible to Action_item$/) do |table|
  # table is a | ACTIVE            | View Activity            |
  table.hashes.each do |items|
    on_page(IndividualPage).verify_action_in_all_pages items['Enrollment_status'], items['Action_item']

  end
end

When(/^user is logged into OP with "([^"]*)" and three bad password "([^"]*)"$/) do |arg1, arg2|
on_page(EnrollPage).open_browser
on_page(EnrollPage).op_login(arg1,arg2)
on_page(EnrollPage).op_login(arg1,arg2)
on_page(EnrollPage).op_login(arg1,arg2)
#on_page(EnrollPage).op_login(arg1,arg2)
#on_page(EnrollPage).op_login(arg1,arg2)
end

When(/^I login into CSS ADMIN$/) do
  InputDataHelper.load_yml("css_login")
  map =InputDataHelper.get_map('css_admin_test_account')
  on_page EnrollPage do |page|
    page.login_admin_verify_status  map
  end

end
Then(/^verify the Enrollment status is "([^"]*)" for "([^"]*)"$/) do |arg1, arg2|
  on_page(IndividualPage).verify_enrollment_status arg1, arg2
end

Given(/^Password request email is sent to user and I click on Reset Password email link$/) do
  ####Include pre requistes ##############

  #Given user is logged into CSS Admin
  #InputDataHelper.load_yml("css_login")
  #map =InputDataHelper.get_map('css_admin_test_account')
  #
  #on_page LoginPage do |page|
  #  page.set_login_username_password  map
  #end

  step "user is logged into CSS Admin"
# When I search for the account Goodtime Aviation, L.L.C.
  InputDataHelper.load_yml("css_admin_data")
  map =InputDataHelper.get_map('AccountStatus')
  @account = on_page(AccountSearchPage).set_account_search_field('Account_Name',map)
#And Select the account
  on_page AccountSearchPage do |page|
    page.select_account @account
  end
# When enrollment status is Active click on Reset Password
  @index = on_page(IndividualPage).select_action_in_all_pages('ACTIVE','Reset Password')
#And I enter email address "complete_enrollment@netjets.com" and choose security Question "What is the middle name of your oldest child?" and security Answer "abc" and click enroll
  on_page(IndividualPage).confirmation_yes

  enrollmentLink = on_page(IndividualPage).input_box "Please Enter the URL from the Email that you have recieved:", "Warning!!!!!"
  on_page(EnrollPage).set_enrollment_link_in_new_browser enrollmentLink
end



When(/^I enter security Answer "([^"]*)" and Password to complete Reset Password$/) do |arg|
  on_page(EnrollPage).set_security_question_reset_password(arg)
  on_page(EnrollPage).set_next_button
  on_page(EnrollPage).Password_Reset
end
When(/^I enter three bad security Answer "([^"]*)"$/) do |arg|
  on_page(EnrollPage).set_security_question_reset_password(arg)
  on_page(EnrollPage).set_next_button
  on_page(EnrollPage).set_security_question_reset_password(arg)
  on_page(EnrollPage).set_next_button
  on_page(EnrollPage).set_security_question_reset_password(arg)
  on_page(EnrollPage).set_next_button
  on_page(EnrollPage).set_security_question_reset_password(arg)
  on_page(EnrollPage).set_next_button
  on_page(EnrollPage).set_security_question_reset_password(arg)
  on_page(EnrollPage).set_next_button
end
Given(/^user opens Owner's Portal$/) do
  on_page(EnrollPage).open_browser
end
When(/^I click on Reset you password link$/) do
  on_page(EnrollPage).password_reset_owner_portal
end


When(/^enter user id "([^"]*)" and click on Reset you password button$/) do |arg|
  on_page(EnrollPage).set_username_password_reset_owner_portal arg

end
When(/^I click on PROFILE link and I click on Edit username and password$/) do
  on_page(EnrollPage).change_password
end

When(/^Enter old password "([^"]*)" and enter new password "([^"]*)" and enter confirm password "([^"]*)"$/) do |arg1, arg2, arg3|
  on_page(EnrollPage).set_oldpassword_for_change_password arg1
  on_page(EnrollPage).set_newpassword_for_change_password arg2
  on_page(EnrollPage).set_confirmpassword_for_change_password arg3
end
When(/^Save Password Change$/) do
  on_page(EnrollPage).set_Save_password_change
end
Then(/^Signout of Owner portal$/) do
  sleep 7
  on_page(EnrollPage).signout_op
end
Then(/^Verify that View activity has a audit of change password with (.*), (.*), (.*), (.*)$/) do |user_id, event_description, date_created, created_by|

end
When(/^Enter three old password "([^"]*)" and enter new password "([^"]*)" and enter confirm password "([^"]*)"$/) do |arg1, arg2, arg3|
  on_page(EnrollPage).set_oldpassword_for_change_password arg1
  on_page(EnrollPage).set_newpassword_for_change_password arg2
  on_page(EnrollPage).set_confirmpassword_for_change_password arg3
  on_page(EnrollPage).set_Save_password_change
  on_page(EnrollPage).set_oldpassword_for_change_password arg1
  on_page(EnrollPage).set_newpassword_for_change_password arg2
  on_page(EnrollPage).set_confirmpassword_for_change_password arg3
  on_page(EnrollPage).set_Save_password_change
  on_page(EnrollPage).set_oldpassword_for_change_password arg1
  on_page(EnrollPage).set_newpassword_for_change_password arg2
  on_page(EnrollPage).set_confirmpassword_for_change_password arg3
  on_page(EnrollPage).set_Save_password_change
  #on_page(EnrollPage).set_oldpassword_for_change_password arg1
  #on_page(EnrollPage).set_newpassword_for_change_password arg2
  #on_page(EnrollPage).set_confirmpassword_for_change_password arg3
  #on_page(EnrollPage).set_Save_password_change
  #on_page(EnrollPage).set_oldpassword_for_change_password arg1
  #on_page(EnrollPage).set_newpassword_for_change_password arg2
  #on_page(EnrollPage).set_confirmpassword_for_change_password arg3
  #on_page(EnrollPage).set_Save_password_change
end
Then(/^I  should verify the message is displayed "([^"]*)"$/) do |arg|
  sleep 2
  on_page(LoginPage).verify_text_resend_enrollment arg

  # Delete enrollment
  @index = on_page(IndividualPage).select_action_in_all_pages(enrStatus,menuItem)
  on_page(IndividualPage).confirmation_yes
end
When(/^I select Secret Question (.*) and enter answer (.*)$/) do |question, answer|
  @answer = on_page(IndividualPage).update_questionanswer(question, answer)
end

When(/^I Select Individual with email address "([^"]*)" and click on "([^"]*)" and click Yes.$/) do |arg1, arg2|
  sleep 4
  @index = on_page(IndividualPage).select_action_in_all_pages(arg1,arg2)
  on_page(IndividualPage).confirmation_yes
end
Then(/^I should verify the results "([^"]*)"$/) do |arg|
  sleep 4
  on_page(IndividualPage).verify_text_enrollment_page arg
  sleep 8
   @browser.div(:class=>'modal hide fade in').button(:text => 'Cancel').click
end