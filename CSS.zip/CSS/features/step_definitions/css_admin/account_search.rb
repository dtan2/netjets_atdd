Given(/^user is logged into CSS Admin$/) do
  on(LoginPage).navigate_to(select_login_url('op_admin_login'))
  InputDataHelper.load_yml("css_login")
  map =InputDataHelper.get_map('css_admin_test_account')

  on_page CssAdminLoginPage do |page|
  page.set_login_username_password  map #using Login ID and password from Yml file
  end
end

When(/^I login into CSS Admin$/) do
  step "user is logged into CSS Admin"
end

Then(/^I  should see the (.*)$/) do |results|

 on_page(AccountSearchPage) do |page|
   page.wait_for_ajax
    msg = page.result_text_element.text
   expect(msg).to include results
 end
end

#When(/^I search for the account (.*)$/) do |account_name|
#  map = DataHelper.get_data_map('AccountStatus')
#  @account = on_page(AccountSearchPage).set_account_search_field(account_name,map)
#end


When(/^Select the account$/) do
  on_page AccountSearchPage do |page|
    #page.select_account @account
    page.wait_for_ajax
    # page.search_for @account
    page.open @account
    page.wait_for_ajax
  end
end
Then(/^Verify that account page have (\d+) or less than (\d+) accounts on each pages$/) do |arg1, arg2|

  on_page(IndividualPage).account_verify_pagination
end
When(/^I select "([^"]*)" filter$/) do |arg|
 on_page(AccountSearchPage).select_program_filter arg
end
When(/^I search for the account (.*)$/) do |account_name|

  InputDataHelper.load_yml("css_admin_data")
  map =InputDataHelper.get_map('AccountStatus')
  @account = on_page(AccountSearchPage).set_account_search_field(account_name,map)
end

#When(/^I search for the Account$/) do |table|
#      map = DataHelper.get_data_map('AccountStatus')
#    table.hashes.each do |items|
#
#    @account = on_page(AccountSearchPage).set_account_search_field items['Account'],map
#    end
#  end


When(/^I click on advanced search link$/) do
  on_page(AccountSearchPage).click_advanced_search_link
end
When(/^I enter last name (.*) and search accounts$/) do |arg|
  on_page(AccountSearchPage).set_advanced_account_lastName(arg)
  on_page(AccountSearchPage).set_search
end
When(/^I enter first name (.*) and search accounts$/) do |arg|
  on_page(AccountSearchPage).set_advanced_account_firstName(arg)
  on_page(AccountSearchPage).set_search
end

When(/^I enter first and last names (.*),(.*) and search accounts$/) do |arg1, arg2|
  on_page(AccountSearchPage).set_advanced_account_firstName(arg1)
  on_page(AccountSearchPage).set_advanced_account_lastName(arg2)
  on_page(AccountSearchPage).set_search
end

When(/^I enter (.*) and Active,Credit Watch,restricted, select Account status and search accounts$/) do |arg2|
  on_page(AccountSearchPage).set_advanced_account_acctstatus
  on_page(AccountSearchPage).set_advanced_account_lastName(arg2)
  on_page(AccountSearchPage).set_search
end
When(/^I enter  (.*) and search accounts$/) do |arg|
  on_page(AccountSearchPage).set_advanced_account_cardNumber(arg)
  on_page(AccountSearchPage).set_search
end


And(/^the account status is (.*)$/) do |accountStatus|

 status = on(AccountSearchPage).get_account_status_for @account

 expect(status).to eq accountStatus
end

Then(/^I want to see the warning message (.*)$/) do |results|

  on(AccountSearchPage) do |page|
  page.wait_for_ajax

  if @account.empty?
  msg = page.alert_msg_element.text
  else
  msg = page.warning_msg_element.text
  end
  expect(msg).to include results
  end

end

Then(/^I want to see the account name: (.*)$/) do |results|

  on(AccountSearchPage) do |page|
  page.wait_for_ajax
  msg = page.gather_account_name
  expect(msg[0]).to include results
  end
end

Then(/^I see alert message (.*)$/) do |results|
  on(AccountSearchPage) do |page|
    page.wait_for_ajax

    if @account.length < 3
    msg = page.alert_msg_element.text
     else
     msg = page.result_text_element.text
    end

    expect(msg).to include results
  end
end

And(/^I want to see the account status (.*)$/) do |account_status|

  on(AccountSearchPage) do |page|
  status = page.get_account_status_for @account
  expect(status).to eq account_status
  end
end

Then(/^I see account individual (.*)$/) do |results|
  on(IndividualPage) do |page|
  page.verify_on_individual_page
  msg = page.error_msg_element.text
  expect(msg).to include results
  end
end

Then(/^I see the (.*)$/) do |results|
  name = on(IndividualPage).gather_individual_from_result
  expect(name[0].downcase).to eq results.downcase
end

Then(/^I can see the warning message (.*)$/) do |results|
  msg = on(IndividualPage).result_msg_element.text
  expect(msg).to include results

end

Then(/^I can see the error message (.*)$/) do |results|
  msg = on(IndividualPage).error_msg_element.text
  expect(msg).to include results
end