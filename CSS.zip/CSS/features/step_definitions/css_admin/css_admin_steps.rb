Given(/^the user is enrolled in Owner Portal$/) do
  # $user_security = {:question => 'nickname', :answer => 'bobo', :password => 'abc123ABC'}
  Session[:question] = 'nickname'
  Session[:answer] = 'bobo'
  Session[:password] = 'abc123ABC'

  navigate_to(HomePage, :using => :css_admin_enroll)
 end
When(/^the user uses the change password feature in Owner Portal$/) do

  on(LoginPage) do |page|
  page.verify_on_login_page
  sleep 15
  page.login_as Session[:user_email]
  end
  on(HomePage) do |page|
  page.wait_for_ajax
  page.select_username_password
  end
end
When(/^the user updates their password$/) do
  @user_new_password = 'abc123XYZ'
  on(ChangePasswordPage).change_password_from_to(Session[:password], @user_new_password)
  on(ChangePasswordPage).wait_for_ajax
  on(ChangePasswordPage).log_out
  on(ChangePasswordPage).wait_for_ajax
end
Then(/^the user must login with their new password$/) do
  on(LoginPage) do |page|
    page.verify_on_login_page
    sleep 15
    page.userName = Session[:user_email]
    page.userPassword = @user_new_password
    page.wait_for_ajax
    page.signIn
  end

  on(ProfilePage).select_username_password
  on(ChangePasswordPage).change_password_from_to(@user_new_password, Session[:password])
end
Given(/^the user updates their password in Owner Portal$/) do

steps %{ Given the user is enrolled in Owner Portal
       And   the user uses the change password feature in Owner Portal
       When  the user updates their password}

end
When(/^viewing the user's activity log$/) do
  navigate_to(IndividualPage, :using => :css_admin_enroll)
  @recent_activity = on(IndividualPage).get_recent_activity_log_for_user Session[:user_id]
end
Then(/^the individual's activity log includes$/) do |table|
  on(IndividualPage) do |page|
    page.log_entry_user_id_include?(Session[:user_email], @recent_activity).should == true
    page.log_entry_event_desc_include?(table.raw[2][1], @recent_activity).should == true
    if table.raw[4][1] == "user's email address"
      page.log_entry_created_by_include?(Session[:user_email], @recent_activity).should == true
    else
      page.log_entry_created_by_include?(Session[:osr_user], @recent_activity).should == true
    end
  end
end
When(/^the user attempts to change their password to the current password$/) do
  @user_new_password = 'abc123ABC'

  on(HomePage).wait_for_ajax
  on(ProfilePage).select_username_password
  on(ChangePasswordPage).change_password_from_to(Session[:password], @user_new_password)
end
Then(/^the following error is displayed "([^"]*)"$/) do |message|
  msg = on(ChangePasswordPage).gather_error_msg
  expect(msg[2]).to eq message
end
When(/^the user changes their password back to the prior password$/) do

  on(LoginPage) do |page|
    page.wait_for_ajax
    page.userName = Session[:user_email]
    page.userPassword = @user_new_password
    page.wait_for_ajax
    page.signIn
  end

  on(HomePage).select_username_password
  on(ChangePasswordPage).change_password_from_to(@user_new_password, Session[:password])
end
Then(/^the user is able to login with their original password$/) do
  on(ChangePasswordPage).log_out

  on(LoginPage) do |page|
    page.userName = Session[:user_email]
    page.userPassword = Session[:password]
    page.wait_for_ajax
    page.signIn
  end
  on(HomePage).verify_on_home_page
end
When(/^the user attempts to change their password (\d+) times with an invalid current password$/) do |reset_attempt|
  @user_new_password = 'abc123XYZ'
  on(HomePage).select_username_password
  reset_attempt.to_i.times do
    on(ChangePasswordPage) do |page|
    page.change_password_from_to('1nv4l1dPW', @user_new_password)
    page.cancel_password_element.when_visible
    page.cancel_password
    page.wait_for_ajax
    end
  end
end
Then(/^the user's account is locked$/) do
  navigate_to(IndividualPage, :using => :css_admin_individual)
  enrollment_status = on(IndividualPage).get_enrollment_status_of_user $user_id
  enrollment_status.should == 'LOCKED'
end
When(/^the user's account is unlocked$/) do
  navigate_to(IndividualPage, :using => :css_admin_individual)
  on(IndividualPage).unlock_account_for_user Sesiion[:user_id]
end
Then(/^the user's account is active$/) do
  navigate_to(IndividualPage, :using => :css_admin_individual)
  enrollment_status = on(IndividualPage).get_enrollment_status_of_user Session[:user_id]
  enrollment_status.should == 'ACTIVE'
end
Given(/^I request enrollment for a user$/) do
  Session[:question] = 'nickname'
  Session[:answer] = 'bobo'
  Session[:password] = 'abc123ABC'
  navigate_to(CompleteEnrollmentSecurityPage, using: :css_admin_enroll)
end
When(/^the user inputs their security answer$/) do
  continue_navigation_to(CompleteEnrollmentPasswordPage, using: :css_admin_enroll)
end
When(/^the user creates a password$/) do
  on(CompleteEnrollmentPasswordPage).password_field = Session[:password]
  on(CompleteEnrollmentPasswordPage).password_retype_field = Session[:password]
end
When(/^the user accepts the terms of service$/) do
  on(CompleteEnrollmentPasswordPage).check_accept_terms_checkbox
  on(CompleteEnrollmentPasswordPage).submit_button
end
Then(/^the user can login to Owner Portal$/) do
  sleep 30
  on(LoginPage) do |page|
    @browser.goto(select_login_url('op_login'))
    page.userName = Session[:user_email]
    page.userPassword = Session[:password]
    page.signIn
  end
  on(HomePage).verify_on_home_page
end
Given(/^a user is enrolled in Owner Portal$/) do
  Session[:question] = 'nickname'
  Session[:answer] = 'bobo'
  Session[:password] = 'abc123ABC'
  navigate_to(HomePage, :using => :css_admin_enroll)
  sleep 30
  on(LoginPage) do |page|
    # @browser.goto(select_login_url('op_login'))
    page.userName = Session[:user_email]
    page.userPassword = Session[:password]
    page.signIn
  end
  on(HomePage).wait_for_ajax
  # on(HomePage).log_out_element.when_visible(11)
  on(HomePage).log_out
end
When(/^viewing available actions for the user$/) do
  on(IndividualPage).click_actions_button_for Session[:user_id]
end
Then(/^the following actions are available$/) do |table|
  #table -- | Enrollment_status | Action_item |
  expected_actions = table.hashes.collect{|item|item.values[1]}
  actions = on(IndividualPage).get_available_actions_for_user Session[:user_id]
  expected_actions.sort.should == actions.sort
end
When(/^the user's enrollment is deleted$/) do
  on(IndividualPage).disable_account_for_user Session[:user_id]
  on(IndividualPage).delete_enrollment_for_user Session[:user_id]
end
Then(/^the user's account is not enrolled$/) do
  enrollment_status = on(IndividualPage).get_enrollment_status_of_user Session[:user_id]
  enrollment_status.should == 'NOT ENROLLED'
end
When(/^the user provides an invalid secret answer$/) do
  on(CompleteEnrollmentSecurityPage).submit_security_enrollment_answer_as '1nv4l1d'
end
When(/^the user provides an invalid secret answer (\d+) times$/) do |invalid_attempt|
  invalid_attempt.to_i.times do
    on(CompleteEnrollmentSecurityPage).submit_security_enrollment_answer_as '1nv4l1d'
    end
  msg = on(ChangePasswordPage).gather_error_msg
  expect(msg[1]).to eq 'Sorry, but your enrollment could not be completed.'
end
Then(/^the user's account is pending$/) do
  navigate_to(IndividualPage, :using => :css_admin_individual)
  enrollment_status = on(IndividualPage).get_enrollment_status_of_user Session[:user_id]
  enrollment_status.should == 'PENDING'
end
When(/^the user provides a password and confirmation password that don't match$/) do
  continue_navigation_to(CompleteEnrollmentPasswordPage, using: :css_admin_enroll)
  on(CompleteEnrollmentPasswordPage) do |page|
    page.password_field = 'abc123ABC'
    page.password_retype_field = 'abc123XYZ'
  end
end
Then(/^the user is unable to submit their password$/) do
  on(CompleteEnrollmentPasswordPage).submit_button_element.disabled?.should == true
end
Given(/^I am enrolling a user on the (.*) account in (.*) status$/) do |account, account_status|
  navigate_to(AccountSearchPage, using: :css_admin_enroll)
  on(AccountSearchPage) do |page|
    page.search_for account
    status = page.get_account_status_for(account)
    expect(status).to eq account_status
    page.open account
  end
end
When(/^I request enrollment for a user on the (.*) account$/) do |account|
  Session[:question] = 'nickname'
  Session[:answer] = 'bobo'
  Session[:password] = 'abc123ABC'
  on(IndividualPage).enroll_a_not_enrolled_user
end
Then(/^the user's account status is PENDING$/) do
  on(IndividualPage).get_enrollment_status_of_user(Session[:user_id]).should == 'PENDING'
end
Given(/^I enroll a user with an email address$/) do
  Session[:question] = 'nickname'
  Session[:answer] = 'bobo'
  Session[:password] = 'abc123ABC'
  navigate_to(NetjetsWebmailLoginPage, :using => :css_admin_enroll)
end
When(/^I attempt to enroll another user with the email address already in use$/) do
  #navigate_to(IndividualPage, :using => :css_admin_enroll)
  user = on(IndividualPage).get_first_not_enrolled_user_id
  Session[:user_email] = on(IndividualPage).get_email_of_user Session[:user_id]
  on(IndividualPage) do |page|
    page.enroll_action_for(user)
    page.email_address_field_element.when_visible(10)
    page.set_email_address Session[:user_email]
    page.set_security_question_and_answer(Session[:question], Session[:answer])
    page.enroll_button
  end
  sleep 2
end
Given(/^The user initiates enrollment with a secret answer having special characters$/) do
  Session[:question] = 'nickname'
  Session[:answer] = 'bobo'
  Session[:password] = 'abc123ABC'

  navigate_to(IndividualPage, using: :css_admin_enroll)
  on(IndividualPage).enroll_a_not_enrolled_user
  on(IndividualPage).get_security_answer_of_user(Session[:user_id]).should == Session[:answer]
  on(IndividualPage).verify_on_individual_page
end
When(/^The user completes their enrollment$/) do
  continue_navigation_to(HomePage, using: :css_admin_enroll)
end
When(/^the user's account is disabled$/) do
  navigate_to(IndividualPage, using: :css_admin_individual)
  on(IndividualPage).disable_account_for_user Session[:user_id]
end
Then(/^the user's account status is disabled$/) do
  on(IndividualPage).get_enrollment_status_of_user(Session[:user_id]).should == 'DISABLED'
end
Then(/^the available css admin actions to perform on this user are:$/) do |table|
  expected_actions = table.hashes.collect{|hash| hash['Action_item']}
  available_actions = on(IndividualPage).get_available_actions_for_user(Session[:user_id])
  available_actions.sort.should == expected_actions.sort
end
When(/^the user's account is enabled$/) do
  navigate_to(IndividualPage, using: :css_admin_individual)
  on(IndividualPage).enable_account_for_user Session[:user_id]
end
When(/^the user attempts to login (\d+) times with an invalid current password$/) do |reset_attempt|
  navigate_to(LoginPage, using: :default)
  @browser.goto(select_login_url('op_login'))
  reset_attempt.to_i.times do
    on(LoginPage) do |page|
      page.username_element.when_visible
      page.username = Session[:user_email]
      page.password = '1nv4l1d'
      page.login
    end
  end
end
When(/^the user's password is reset$/) do
  @user_new_password = 'abc123XYZ'
  navigate_to(IndividualPage, using: :css_admin_individual)
  on(IndividualPage).reset_password_for_user Session[:user_id]
  on(NetjetsWebmailLoginPage).login_to_webmail
  on(NetjetsWebmailInboxPage).reset_password_for_user Session[:user_email]
  on(ResetPasswordSecurityPage).submit_security_answer_as($user_security[:answer])
  on(ResetPasswordPage).submit_password_as @user_new_password
  on(HomePage).log_out_element.when_visible
  on(HomePage).log_out
end

When(/^the user submits (\d+) bad security answer attempts$/) do |arg|
  navigate_to(IndividualPage, using: :css_admin_individual)
  on(IndividualPage).reset_password_for_user Session[:user_id]
  on(NetjetsWebmailLoginPage).login_to_webmail
  on(NetjetsWebmailInboxPage).reset_password_for_user Session[:user_email]
  on(ResetPasswordSecurityPage) do |page|
    5.times do
      page.submit_security_enrollment_answer_as('WrongAnswer')
    end
  end
end

When(/^I change password with the same password$/) do
  on(HomePage) do |page|
   page.wait_for_ajax
   page.select_username_password
  end

  on(ChangePasswordPage) do |page|
  page.wait_for_ajax
  page.verify_on_chg_password_page
  page.edit_password
  page.wait_for_ajax
  page.old_password = Session[:password]
  page.new_password = Session[:password]
  page.confirm_password = 'abc123ASD'
  page.submit_password
  end

end

Then(/^I see the You cannot change your password with same values warning message$/) do
  on(ChangePasswordPage) do |page|
    page.wait_for_ajax
    msg = page.password_msg_element.text
    expect(msg).to eq 'Password doesn\'t match'
  end
end

Then(/^an error message is displayed "([^"]*)"$/) do |message|
  msg = on(ChangePasswordPage).gather_error_msg
  expect(msg[1]).to eq message
end

Then(/^a pop up message shows up$/) do
  msg = on(ChangePasswordPage).gather_pop_msg
  expect(msg[0]).to eq "Failed to create user: The name '#{Session[:user_email]}' already exists."
end