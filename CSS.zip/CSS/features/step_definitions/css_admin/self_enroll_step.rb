Given(/^I input an invalidly formatted email address$/) do
  navigate_to(SelfEnrollPage, :using => :self_enroll)
  on(SelfEnrollPage).enroll_with 'f4k3@55.email'
end
When(/^I apply for enrollment$/) do
  on(SelfEnrollPage).next_button
end
Then(/^The system tells me my email format is invalid$/) do
  on(SelfEnrollPage).error_validation('Please enter a valid email address')
end
Given(/^I input my email$/) do
  warn('Enrollment status of NOT ENROLLED has yet to be validated')
  navigate_to(SelfEnrollPage, :using => :self_enroll)
  on(SelfEnrollPage).email_id = 's.sandberg@netjets.com'
end
When(/^My email matches an email in IJet2$/) do
  #currently unable to validate, assumed validation
end
When(/^I submit my email$/) do
  on(SelfEnrollPage).next_button
end
Then(/^The message "([^"]*)" appears$/) do |arg|
  on(SelfEnrollConfirmPage).validate_text_box('Please check your email box for your enrollment link.
If you do not receive an email shortly, please call your Owner Services Team to complete setup with this email address.')
end
When(/^An email is sent to my inbox to continue the self enrollment process$/) do
  on(NetjetsWebmailLoginPage) do |page|
    page.open_webmail
    page.webmail_login
  end
  on(NetjetsWebmailInboxPage).open_complete_self_enrollment_page @email_address
  on(CompleteSelfEnrollPage).verify_on_complete_self_enroll_page
end
Given(/^I enroll with a (.*)$/) do |account_identifier|
  @account_identifier = account_identifier
end

When(/^I submit my enrollment$/) do
  Session[:user_email] = 'kat@redrobin.com'
  Session[:user_id] = '1488654'
  navigate_to(AccountSearchPage, :using => :css_admin_individual)
  on(AccountSearchPage) do |page|
    page.search_for('red robin')
    page.wait_until { page.result_text_element.visible? }
    page.open_account ('Red Robin Gourmet Restaurants')
  end

  on(IndividualPage) do |page|
    page.individual_search_field = 'Scherping'
    page.individual_search_button
    page.clean_up_enrollment Session[:user_id]
    sleep 5 #wait for the system to cleanup the enrollment
  end

  navigate_to(CompleteSelfEnrollPage, :using => :self_enroll)

  case @account_identifier

    when 'Personal Telephone Number'

      on(CompleteSelfEnrollPage).set_identifier '6145558888'

    when 'Toll Free #'
      on(CompleteSelfEnrollPage) do |page|
        page.toll_free_radio_element.when_visible.click
        page.set_identifier '8666789088'
      end

    when 'A/R #'
      on(CompleteSelfEnrollPage) do |page|
        page.ar_number_radio_element.when_visible.click
        page.set_identifier '17676'
      end

    else
      nil

  end

  on(CompleteSelfEnrollPage).populate_self_enroll_data(key = 'enroll_with_ar_num')
  on(CompleteSelfEnrollPage).submit_button
end

When(/^my enrollment status is (.*)$/) do |status|
  #case status
  #  when 'ACTIVE'
  #    navigate_to(HomePage, :using => :self_enroll)
  #  when 'DISABLED'
  #    TODO: add logic to disable account
  #navigate_to(HomePage, :using => :self_enroll)
  #when 'EXPIRED'
  #  navigate_to(CompleteSelfEnrollPage, :using => :self_enroll)
  #  3.times do
  #    on(CompleteSelfEnrollPage).populate_self_enroll_data :enroll_with_invalid_id_num
  #    on(CompleteSelfEnrollPage).submit_button
  #  end
  #when 'PENDING'
  #  navigate_to(SelfEnrollConfirmPage, :using => :self_enroll)
  #end

  #needs to be refactored
  navigate_to(IndividualPage, using: :css_admin_individual)
  enrollment_status = on(IndividualPage).get_enrollment_status_of_user '2247847'
  enrollment_status.should == status
  #@browser.goto 'http://securityserviceqa.webservice.netjets.com/css-admin-web/login'
  #@browser.text_field(:id => 'j_username').set 'qatest1'
  #@browser.text_field(:id => 'j_password').set 'Alt1tud3!'
  #@browser.button(:id => 'loginButton').click
  #@browser.text_field(:id => 'accountName').set 'Facebook'
  #@browser.button(:id => 'searchButton').click
  #@browser.table(:class => 'table').tr.click
  #t = @browser.div(:id => 'individualsZone').table
  #t.trs.each do |row|
  #  if row.attribute_value('emailaddress') == 'sheri@gmail.com'
  #    row.td(:index => 1).p(:index => 1).text.should include(status)
  #  end
  #end

end
Given(/^I input the email of a deceased individual$/) do
  @email_address = '1090900@netjets.com'
  navigate_to(SelfEnrollPage, :using => :self_enroll)
  on(SelfEnrollPage).enroll_with @email_address
end
When (/^the email is not shared by a valid individual$/) do
  #REFACTOR
  trusted_data = true
  trusted_data
end
Then(/^no email is sent to my inbox$/) do
  on(NetjetsWebmailLoginPage).login_to_webmail
  data = on(NetjetsWebmailInboxPage).find_enrollment_link Session[:user_email]
  expect(data).to eq false
end


Given(/^I input the email of an account's inactive individual$/) do
  navigate_to(SelfEnrollPage, :using => :self_enroll)
  @email_address = 'walsh@juma.com'
  on(SelfEnrollPage).enroll_with @email_address
end
When(/^the individual is not active on any other accounts$/) do
  #REFACTOR
  trusted_data = true
  trusted_data
end
Given(/^My email does not match an email in IJet2$/) do
  #REFACTOR
  trusted_data = true
  trusted_data
  navigate_to(SelfEnrollPage, :using => :self_enroll)
  @email_address = 'michaeljgraf@hotmail.com'
  on(SelfEnrollPage).enroll_with @email_address
end

#account live oak
#Virginia Moens
#future inactive date

Given(/^I have the email of an account's individual that will be inactive in the future$/) do
  Session[:user_email] = '1008802@netjets.com'
  Session[:user_id] = '1008802'
  Session[:toll_num]= '(866)689-4374'

  navigate_to(AccountSearchPage, :using => :css_admin_individual)
  on(AccountSearchPage) do |page|
    page.search_for('Live Oak')
    page.wait_until { page.result_text_element.visible? }
    page.open_account ('Live Oak Aviation, Inc.')
  end

  on(IndividualPage) do |page|
    page.individual_search_field = 'Moens'
    page.individual_search_button
    page.clean_up_enrollment Session[:user_id]
  end


end
Given(/^I have an enrollment email$/) do
  navigate_to(SelfEnrollConfirmPage, :using => :self_enroll)
end
Given(/^my security question is not designated$/) do
  Session[:email] = 'kat@redrobin.com'
  Session[:user_id] = '1488654'
  navigate_to(AccountSearchPage, :using => :css_admin_individual)
  on(AccountSearchPage) do |page|
    page.search_for('red robin')
    page.wait_until { page.result_text_element.visible? }
    page.open_account ('Red Robin Gourmet Restaurants')
  end

  on(IndividualPage) do |page|
    page.individual_search_field = 'Scherping'
    page.individual_search_button sleep 5 #wait for the system to cleanup the enrollment
  end

  navigate_to(CompleteSelfEnrollPage, :using => :self_enroll)
  on(CompleteSelfEnrollPage).set_identifier '6145558888'
  on(CompleteSelfEnrollPage).populate_self_enroll_data('enroll_with_no_security_question')
end
When(/^the rest of my inputs are valid$/) do
  #TODO: add data validation logic
  true
end
Then(/^I am unable to submit my enrollment$/) do
  data = on(CompleteSelfEnrollPage).submit_button_element.enabled?
  expect(data).to eq false
end
Given(/^my security answer is not designated$/) do
  Session[:email] = 'kat@redrobin.com'
  Session[:user_id] = '1488654'
  navigate_to(AccountSearchPage, :using => :css_admin_individual)
  on(AccountSearchPage) do |page|
    page.search_for('red robin')
    page.wait_until { page.result_text_element.visible? }
    page.open_account ('Red Robin Gourmet Restaurants')
  end

  on(IndividualPage) do |page|
    page.individual_search_field = 'Scherping'
    page.individual_search_button
    page.clean_up_enrollment Session[:user_id]

  end
  navigate_to(CompleteSelfEnrollPage, :using => :self_enroll)
  on(CompleteSelfEnrollPage).set_identifier '6145558888'

  on(CompleteSelfEnrollPage).populate_self_enroll_data('enroll_with_no_security_answer')
end
Given(/^my terms and conditions are not accepted$/) do
  Session[:email] = 'kat@redrobin.com'
  Session[:user_id] = '1488654'

  navigate_to(AccountSearchPage, :using => :css_admin_individual)

  on(AccountSearchPage) do |page|
    page.search_for('red robin')
    page.wait_until { page.result_text_element.visible? }
    page.open_account ('Red Robin Gourmet Restaurants')
  end

  on(IndividualPage) do |page|
    page.individual_search_field = 'Scherping'
    page.individual_search_button
    page.clean_up_enrollment Session[:user_id]

  end
  navigate_to(CompleteSelfEnrollPage, :using => :self_enroll)
  on(CompleteSelfEnrollPage).set_identifier '6145558888'

  on(CompleteSelfEnrollPage).populate_self_enroll_data('enroll_with_ar_num')
  on(CompleteSelfEnrollPage).uncheck_eula_checkbox
end
Given(/^I self enroll$/) do
  # step is for context only
  true
end
Then(/^my enrollment status includes a 'Self Enroll' notification$/) do
  t = @browser.div(:id => 'individualsZone').table
  t.trs.each do |row|
    if row.attribute_value('emailaddress') == 'sheri@gmail.com'
      row.td(:index => 1).p(:index => 2).text.should include('Self Enrolled')
    end
  end
end

Given(/^I have a shared email of a deceased individual$/) do
  Session[:user_email] = 'rehan@juma.com'
  Session[:user_id] = '2389337' #Rehan Juma
  Session[:toll_num] = '351214543015'
end


Given(/^I have a email with both active and inactive account$/) do
  Session[:user_email] = '1082996@netjets.com'
  Session[:user_id] = '1082996'
  Session[:toll_num]= '8666896526'
  navigate_to(AccountSearchPage, :using => :css_admin_individual)
  on(AccountSearchPage) do |page|
    page.search_for('Clark Estates')
    page.wait_until { page.result_text_element.visible? }
    page.open_account ('The Clark Estates, Inc.')
  end

  on(IndividualPage) do |page|
    page.individual_search_field = 'weber'
    page.individual_search_button
    page.clean_up_enrollment Session[:user_id]

  end
end

When(/^I self enroll with toll free number$/) do

  navigate_to(SelfEnrollPage, :using => :self_enroll)
  on(SelfEnrollPage) do |page|
    page.enroll_with Session[:user_email]
    page.next_button
  end
  on(NetjetsWebmailLoginPage) do |page|
    page.login_to_webmail
  end
  on(NetjetsWebmailInboxPage).open_complete_self_enrollment_page(email_address = Session[:user_email])

  on(CompleteSelfEnrollPage) do |page|
    page.set_self_enroll_info_toll_free Session[:toll_num]
    sleep 20 #wait for completion of enrollment.
  end
end

Then(/^the individual can only see the account they are active on$/) do

  on(LoginPage).verify_on_login_page
  on(LoginPage).login_as Session[:user_email]
  on(HomePage) do |page|
    page.verify_on_home_page
    data = page.gather_access_account_name
    expect(data).not_to include 'Live Oak'
  end
end

When(/^I request for self enrollment$/) do
  navigate_to(SelfEnrollPage, :using => :self_enroll)
  on(SelfEnrollPage) do |page|
    page.enroll_with Session[:user_email]
    page.next_button
  end
end

#account: Live Oak
#name: Greenlaw Grupe
#email:1287595@netjets.com

Given(/^I have a email without Ijet2 permission$/) do
  Session[:user_email] = '1287595@netjets.com'
end

Then(/^I am able to log in with the new login information$/) do
  sleep 10
  if on(LoginPage).verify_on_login_page
    on(LoginPage).login_as @duplicate_phone_num[:Lindsey_email]
    on(HomePage).verify_on_home_page
  else
    on(HomePage).verify_on_home_page
  end

end

#setup two individuals have the same personal phone number but unique email address.
#account live oak
#individual:Lilly Wolfington and Lindsey Wolfington
#email address: 1553824@netjets.com (Lindsey)
#email_address: 1675931@netjets.com (Lilly)
#personal phone :6145559078

When(/^an owner enrolls with a phone number used by another owner$/) do
  @duplicate_phone_num ={:Lindsey_email => '1553824@netjets.com', :Lindsey_id => '1553824', :account => 'Live Oak Aviation, Inc.',
                         :user_lastname => 'Wolfington', :user_phone_num => '6145559078', :Lilly_user_email => '1675931@netjets.com',
                         :Lilly_id => '1675931'}

#Going to the account search page
#making sure the phone number is duplicate
  navigate_to(AccountSearchPage, :using => :css_admin_individual)
  on(AccountSearchPage) do |page|
    page.search_for @duplicate_phone_num[:account]
    page.wait_until { page.result_text_element.visible? }
    page.open_account @duplicate_phone_num[:account]
  end
#cleanup previous enrollment
  on(IndividualPage) do |page|
    page.individual_search_field = @duplicate_phone_num[:user_lastname]
    page.individual_search_button
    page.clean_up_enrollment @duplicate_phone_num[:Lilly_id]

    page.clean_up_enrollment @duplicate_phone_num[:Lindsey_id]

  end
#request a self enrollment
  navigate_to(SelfEnrollPage, :using => :self_enroll)
  on(SelfEnrollPage) do |page|
    page.enroll_with @duplicate_phone_num[:Lilly_user_email]
    page.next_button
  end
  on(NetjetsWebmailLoginPage) do |page|
    page.login_to_webmail
  end
  sleep 5
  on(NetjetsWebmailInboxPage).open_complete_self_enrollment_page @duplicate_phone_num[:Lilly_user_email]
  sleep 2
#fill in the enrollment form
  on(CompleteSelfEnrollPage).set_identifier @duplicate_phone_num[:user_phone_num]
  on(CompleteSelfEnrollPage).populate_self_enroll_data(key = 'enroll_with_ar_num')
  on(CompleteSelfEnrollPage).submit_button


#Going to account search page
  navigate_to(AccountSearchPage, :using => :css_admin_individual)
  on(AccountSearchPage) do |page|
    page.search_for @duplicate_phone_num[:account]
    page.wait_until { page.result_text_element.visible? }
    page.open_account @duplicate_phone_num[:account]
  end

  on(IndividualPage) do |page|
    page.individual_search_field = @duplicate_phone_num[:user_lastname]
    page.individual_search_button
    #valid the duplicate phone has been used for enrollment
    data = page.collect_user_details_of_user @duplicate_phone_num[:Lilly_id]
    expect(data).to include 'Enrollment Status: ACTIVE'

  end
#self enrollment
  navigate_to(SelfEnrollPage, :using => :self_enroll)
  on(SelfEnrollPage) do |page|
    page.enroll_with @duplicate_phone_num[:Lindsey_email]
    page.next_button
  end
  on(NetjetsWebmailLoginPage) do |page|
    page.login_to_webmail
  end
  sleep 2
  on(NetjetsWebmailInboxPage).open_complete_self_enrollment_page @duplicate_phone_num[:Lindsey_email]
  sleep 2

  on(CompleteSelfEnrollPage).set_identifier @duplicate_phone_num[:user_phone_num]
  on(CompleteSelfEnrollPage).populate_self_enroll_data(key = 'enroll_with_ar_num')
  on(CompleteSelfEnrollPage).submit_button

end

Then(/^I can login with my new account$/) do
  sleep 10
  if on(LoginPage).verify_on_login_page == true
    on(LoginPage).login_as Session[:user_email]
    on(HomePage).verify_on_home_page
  else
    on(HomePage).verify_on_home_page
  end

end

Then(/^the owner gets an email about the duplicate email address$/) do
  on(NetjetsWebmailLoginPage) do |page|
    page.login_to_webmail
  end
  sleep 2
  email = on(NetjetsWebmailInboxPage).gather_email_body
  expect(email[3]).to eq 'The email you provided is currently shared by more than one person.'
end

#account live oak
#individual:Nancy Wood,Courtney Wolfington
#email address: 1553826@netjets.com (Courtney)
#personal phone :6145559078
#set both owner has the same email address

When(/^I enroll with an email address used by another owner$/) do
  Session[:user_email] = '1553826@netjets.com'
  Session[:user_id] = '1553826'
  navigate_to(AccountSearchPage, :using => :css_admin_individual)
  on(AccountSearchPage) do |page|
    page.search_for('Live Oak')
    page.wait_until { page.result_text_element.visible? }
    page.open_account ('Live Oak Aviation, Inc.')
  end

  on(IndividualPage) do |page|
    page.individual_search_field = 'Wolfington'
    page.individual_search_button
    page.clean_up_enrollment Session[:user_id]
  end

  #request a self enrollment
  navigate_to(SelfEnrollPage, :using => :self_enroll)
  on(SelfEnrollPage) do |page|
    page.enroll_with Session[:user_email]
    page.next_button
  end


end