Given(/^I am at the login page$/) do
 visit(LoginPage)
 end


When(/^I enter a bogus username and logon$/) do

  # (LoginPage).verify_on_login_page
  n=100
  (1..n).each do
      name = Time.now.sec
    on(LoginPage) do |page|
    page.userName = "Joe.#{name}@gmail.com"
    page.userPassword= 'abc123ABC'
    page.select_sign_in_button
    end

   end

  end

When(/^I signin without username$/) do

  on(LoginPage) do |page|
   page.userPassword = 'abc123ABC'
   page.select_sign_in_button
  end

end

Then(/^I get an username error message$/) do

  on(LoginPage) do |page|
  msg = page.error_msg_element.text
   expect(msg).to eq 'Please enter your user name'
  end


end

And(/^sucessfully signin with username$/) do
  on(LoginPage) do |page|
    page.wait_for_ajax
    page.userName = 'adler@redrobin.com'
    page.userPassword= 'abc123ABC'
    page.select_sign_in_button
  end
  on(HomePage).verify_on_home_page

end

When(/^I signin without password$/) do

  on(LoginPage) do |page|
   @username = page.userName = 'adler@redrobin.com'
    page.select_sign_in_button
  end
end

Then(/^I get an password error message$/) do

  on(LoginPage) do |page|
    msg = page.error_msg_element.text
    expect(msg).to eq 'Please enter your password'
  end

end

When(/^I signin without password and username$/) do
  on(LoginPage) do |page|
  page.select_sign_in_button
  end
end

Then(/^I get an password and username error message$/) do
  on(LoginPage) do |page|
    msg = page.error_msg_element.text
    expect(msg).to include 'Please enter your password'
    expect(msg).to include 'Please enter your user name'
  end
end