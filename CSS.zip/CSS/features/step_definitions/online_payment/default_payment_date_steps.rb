Given(/^today is not a Friday, Saturday, or day before a holiday$/) do
  pending 'Payments may not be submitted tomorrow' \
    if Date.today.friday? || Date.today.saturday? || Date.tomorrow.is_a_holiday?
end

When(/^the individual makes a payment before the (\d+) PM EST cutoff$/) do |arg|
  login_as(Login::USERWITHUNPAIDINVOICES)
  Session[:default_payment_date] = payment_date
  pending 'Current time is after 8PM EST' if Time.now > Time.parse("8:00 PM EST")
end

Then(/^the payment date will be tomorrow$/) do
  expect(Session[:default_payment_date]).to eq Date.tomorrow
end

Given(/^today is not a Thursday, Friday, or (\d+) days before a holiday$/) do |arg|
  pending 'Payments may not be submited the day after tomorrow' \
    if Date.today.thursday? || Date.today.friday? || (Date.today + 2.days).is_a_holiday?
end

When(/^the individual makes a payment after the (\d+) PM EST cutoff$/) do |arg|
  login_as(Login::USERWITHUNPAIDINVOICES)
  Session[:default_payment_date] = payment_date
  pending 'Current time is before 8PM EST' if Time.now < Time.parse("8:00 PM EST")
end

Then(/^the payment date will be the day after tomorrow$/) do
  expect(Session[:default_payment_date]).to eq (Date.tomorrow + 1.day)
end

Given(/^today is Friday, Saturday, or Sunday before 8PM EST$/) do
  pending 'The current date time is not on the weekend before cutoff'\
    unless Date.today.friday? || Date.today.saturday? || (Date.today.sunday? && Time.now < Time.parse('8:00 PM EST'))
end

Given(/^today is the day before a holiday$/) do
  pending 'It is not before cutoff on the day before a holiday'\
    if Date.tomorrow.is_a_holiday? && Time.now < Time.parse('8:00 PM EST')
end

When(/^the individual makes a payment$/) do
  login_as(Login::USERWITHUNPAIDINVOICES)
  Session[:default_payment_date] = payment_date
end

Then(/^the payment date will be the next available business day$/) do
  expect(Session[:default_payment_date]).to eq next_available_payment_date
end