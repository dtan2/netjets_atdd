When(/^a user without Financial permissions uses Owner Portal$/) do
  login_as(Login::NONFINANCIALUSER)
end

Then(/^the user is unable to view invoices$/) do
  expect(on(HomePage).view_invoices?).to eq false
end

Given(/^a user has unpaid invoices$/) do
  login_as(Login::USERWITHUNPAIDINVOICES)
end

When(/^a user views their unpaid invoices$/) do
  on(HomePage).select_account_invoice
end

And(/^the invoices are sorted from oldest to newest$/) do
  invoice_dates = Array.new
  on(UnpaidInvoicePage).invoices.each { |i| invoice_dates << Date.parse(i.date) }
  expect(invoice_dates).to eq(invoice_dates.sort)
end

Then(/^the invoices appear with the following information$/) do |table|
  page = on(UnpaidInvoicePage)
  valid_invoice_types = ['Activity', 'Monthly', 'Miscellaneous', 'Demo', 'Service']
  valid_invoice_statuses = ['', 'Paid', 'Autopay', 'Pending']
  expect(Date.parse(page.date_elements[0].text)).to be_a(Date)
  expect(page.contract_or_card_elements[0].text.to_i).to be_an(Integer).and((have(7).characters).or(have(10).characters))
  expect(page.invoice_number_elements[0].text.to_i).to be_an(Integer).and(have(9).characters)
  expect(page.invoice_type_elements[0].text).to satisfy { |actual| valid_invoice_types.include? actual }
  expect(page.aircraft_elements[0].text).to be_a(String).and have_at_least(2).characters
  expect(page.tail_number_elements[0].text).to have_at_least(5).characters
  expect(page.total_amount_elements[0].text).to be > 0
  expect(page.amount_due_elements[0].text).to be > 0
  expect(page.status_elements[0].text).to satisfy { |actual| valid_invoice_statuses.include? actual }
end

Given(/^a user has no unpaid invoices available$/) do
  login_as(Login::USERWITHNOUNPAIDINVOICES)
end

Then(/^no invoices display$/) do
  no_invoices_message = 'No data available in table'
  expect(on(UnpaidInvoicePage).invoice_table_element[1..-2].text).to eq no_invoices_message
end

When(/^a user views their unpaid invoices in Owner Portal$/) do
  on(HomePage).select_account_invoice
end

Then(/^all invoices have an outstanding balance$/) do
  #each invoice has a balance greater than zero
  due_amounts = Array.new
  on(UnpaidInvoicePage).invoices.each { |invoice| due_amounts << Monetize.parse(invoice.due).to_f }
  expect(due_amounts).not_to include 0

end

Then(/^the invoices appear with the following information in the order below$/) do |table|
  # table is a table.hashes.keys # => [:Date]
  invoice_columns = on(UnpaidInvoicePage).invoice_headers
  expect(invoice_columns).to eq(table.raw.flatten)
end

Then(/^the unpaid prepaid invoice information is displayed$/) do
  expect(on(UnpaidInvoicePage).invoices_element['123456789']).to be visible?
end

Given(/^an invoice is in (.*) status$/) do |status|
  status = '' unless status == 'Autopay'
  Session[:status] = status
  login_as(Login::USERWITHUNPAIDINVOICES)
end

Then(/^that invoice displays its status$/) do
  expect(on(UnpaidInvoicePage).invoices_element[1][9].text).to eq Session[:status]
end

Given(/^I have invoices of the following types$/) do |table|
  # table is a table.hashes.keys # => [:InvoiceTypes]
  Session[:invoice_types] = table.raw.flatten
  login_as(Login::USERWITHUNPAIDINVOICES)
  on(HomePage).view_invoices
  Session[:invoice_types].each { |invoice_type| partially_pay_invoice_type(invoice_type) }
end

When(/^I view my unpaid invoices$/) do
  on(HomePage).select_account_invoice
end


Then(/^those invoice types display$/) do
  @invoice_types_displayed = on(UnpaidInvoicePage).all_invoice_types()
  expect(@invoice_types_displayed).to eq Session[:invoice_types].sort
  delete_unprocessed_payments
end

Given(/^I create an internal Miscellaneous invoice with an outstanding balance$/) do
  Session[:invoice_num] = 1234009
  pending 'validation needs added to verify invoice number exists in the database'
  login_as(Login::USERWITHUNPAIDINVOICES)
end

When(/^I view unpaid Invoices$/) do
  on(HomePage).select_account_invoice
end

Then(/^that invoice is not visible$/) do
  @invoices_on_page = on(UnpaidInvoicePage).all_invoice_numbers
  expect(@invoices_on_page).not_to include Session[:invoice_num]
end

When(/^An NJE user with financial permissions uses Owner Portal$/) do
  login_as(Login::NJEUSERWITHINVOICES)
end

Then(/^that user is unable to view invoice information$/) do
  expect(on(HomePage).invoices?).to be false
end

When(/^I do stuff$/) do
  account_invoices = BillingArchiveFile.where(ar_number: '4051')
  account_invoices2 = BillingEntity.find_by_sql("SELECT "\
  "BIM.BILLING_MONTH, "\
  "BAF.CONTRACT_NUMBER, "\
  "BAF.INVOICE_NUMBER, "\
  "BIM.INVOICE_TYPE, "\
  "BAF.AIRCRAFT_TYPE, "\
  "BAF.TAIL_NUMBER, "\
  "BIM.INVOICE_TOTAL, "\
  "BIPS.OUTSTANDING_BALANCE "\
"FROM BLNG_OWNER.BLNG_ARCHIVE_FILE BAF "\
  "JOIN BLNG_OWNER.BLNG_INVOICE_METADATA BIM ON BAF.ARCHIVE_FILE_ID = BIM.ARCHIVE_FILE_ID "\
  "LEFT JOIN BLNG_OWNER.BLNG_INVOICE_PAYMENT_STATUS BIPS ON BAF.INVOICE_NUMBER = BIPS.INVOICE_NBR "\
  "WHERE BAF.AR_NUMBER = '4051' "\
";")
end


When(/^I sort the invoice columns in ascending order$/) do |table|
  # table is a table.hashes.keys # => [:columns]
  Session[:columns] = table.rows
end

Then(/^the invoice data is displayed in ascending order$/) do
  exceptions = Hash.new
  Session[:columns].each do |column|
    begin
      expect(Session[column.gsub(/\s+/, "_").to_sym]).to eq Session[column.gsub(/\s+/, "_").to_sym].sort
    rescue ExpectationNotMetError => e
      exceptions[column.gsub(/\s+/, "_").to_sym] = e
    end
  end
  unless exceptions == {}
    exceptions.keys.each do |key|
      puts key.to_sym
      puts exceptions[key.to_sym]
    end
    fail 'Not all expectations met'
  end
end