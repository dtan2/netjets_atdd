require_relative '../../models/billing_invoice_payment'

Given(/^I have an unpaid invoice$/) do
  @invoice_number = 000
end

When(/^I make a partial payment on that invoice$/) do
  @payment_amount = 0.00
end

Then(/^that partial invoice payment appears in the billing system$/) do
  list_of_payments = BillingInvoicePayment.where(invoice_nbr: @invoice_number)
  expect(list_of_payments).to have(1).items
  expect(list_of_payments[0].amount).to eq @payment_amount
end

When(/^I make a full payment on that invoice$/) do
  @payment_amount = 0.00
end

Then(/^that full invoice payment appears in the billing system$/) do
  list_of_payments = BillingInvoicePayment.where(invoice_nbr: @invoice_number)
  expect(list_of_payments).to have(1).items
  expect(list_of_payments[0].amount).to eq @payment_amount
end

When(/^I make a full payment on those invoices$/) do
  @payment_amounts = [1.00, 2.00]
end

Then(/^those full invoice payments appear in the billing system$/) do
  list_of_payments = BillingInvoicePayment.where(invoice_nbr: @invoice_numbers)
  @amounts_paid = list_of_payments.collect { |payment| payment.amount }
  expect(list_of_payments).to have(@invoice_numbers.count).items
  expect(@amounts_paid.sort).to eq @payment_amounts.sort
end

When(/^I make a payment covering one invoice in full and part of the other invoice$/) do
  @payment_amounts = [1.00, 2.00]
end

Then(/^that full invoice payment and that partial invoice payment appear in the billing system$/) do
  list_of_payments = BillingInvoicePayment.where(invoice_nbr: @invoice_numbers)
  @amounts_paid = list_of_payments.collect { |payment| payment.amount }
  expect(list_of_payments).to have(@invoice_numbers.count).items
  expect(@amounts_paid.sort).to eq @payment_amounts.sort
end

When(/^I make a payment for more than the invoice's amount$/) do
  @invoice_number = 000
  @payment_amount = 2.00
  @amount_due = 1.00
end

Then(/^only the full invoice payment appears in the billing system$/) do
  list_of_payments = BillingInvoicePayment.where(invoice_nbr: @invoice_number)
  @amounts_paid = list_of_payments.collect { |payment| payment.amount }
  expect(@amounts_paid).to include @amount_due
end

But(/^that overpaid amount does not appear in the billing system$/) do
  expect(@amounts_paid).not_to include (@payment_amount - @amount_due)
end

Given(/^I made a partial payment on an invoice$/) do
  @invoice_number = 000
  @payment_amount = 0.00
end

Then(/^that payment does not appear in the billing system$/) do
  list_of_payments = BillingInvoicePayment.where(invoice_nbr: @invoice_number)
  @amounts_paid = list_of_payments.collect { |payment| payment.amount }
  expect(@amounts_paid).not_to include @payment_amount
end

Given(/^I made a full payment amount on an invoice$/) do
  @invoice_number = 000
  @payment_amount = 0.00
end


Given(/^I made a payment that's more than the invoice amount$/) do
  @invoice_number = 000
  @payment_amount = 1.00
end

Given(/^I make a full payment that's for multiple invoices$/) do
  @invoice_numbers = [1, 2]
  @payment_amounts = [1.00, 2.00]
end

Then(/^those payments do not appear in the billing system$/) do
  list_of_payments = BillingInvoicePayment.where(invoice_nbr: @invoice_numbers)
  @amounts_paid = list_of_payments.collect { |payment| payment.amount }
  @payment_amount.each do |payment|
    expect(@amounts_paid).not_to include payment
  end
end