When(/^an owner makes a partial payment on an invoice$/) do
  login_as(Login::USERWITHUNPAIDINVOICES)
  Session[:payment_details] = apply_partial_payment(1)
end

When(/^an owner makes a partial payment without accepting terms and conditions$/) do
  partial_payment_without_terms(0.01)

end

When(/^an owner makes partial payment on an invoice for (\d+[.]\d+)$/) do |minimum_partial_payment_amt|
  login_as(Login::USERWITHUNPAIDINVOICES)
  Session[:payment_details] = apply_partial_payment minimum_partial_payment_amt
end

When(/^an owner makes a partial payment on a (.*) invoice$/) do |type|
  login_as(Login::USERWITHUNPAIDINVOICES)
  on(HomePage).view_invoices
  Session[:payment_details] = partially_pay_invoice_type(type)
end