When(/^an owner makes a full payment on multiple invoices$/) do
  login_as(Login::USERWITHUNPAIDINVOICES)
  Session[:payment_details] = make_a_full_payment_on_multiple_invoices
end


When(/^the owner makes a payment without accepting the terms and conditions on multiple invoices$/) do
  login_as(Login::USERWITHUNPAIDINVOICES)
  submit_payment_without_terms_on_multiple_invoices
end


When(/^an owner does not designate a bank account while making a payment on multiple invoices$/) do
  login_as(Login::USERWITHOUTBANKACCT)
  pay_multiple_invoices_without_bank_acct
end
Then(/^the owner cannot pay$/) do
  expect(on(EnterPaymentDetailsPage).continue_element.disabled?).to be true
end


