When(/^an owner makes a full payment on an invoice$/) do
  login_as(Login::USERWITHUNPAIDINVOICES)
  Session[:payment_details] = make_a_full_payment_on_a_single_invoice
end

Then(/^owner gets a payment confirmation number$/) do
  confirmation_details = payment_confirmation_details
  expect(confirmation_details.account).to include Session[:payment_details][:account]
  expect(confirmation_details.amount.to_f).to eq Session[:payment_details][:amount].delete('$,').to_f
  expect(confirmation_details.date).to eq Session[:payment_details][:date]
  expect(confirmation_details.confirmation_number).to match /NETJET[0-9]{9}/
end

And(/^the invoice is paid$/) do
  invoice_numbers = Session[:payment_details][:invoices]
  on(PaymentConfirmationPage).select_account_invoice
  found_invoices = invoice_numbers.collect do |invoice_number|
    invoice_number if on(UnpaidInvoicePage).invoice_numbers.include? invoice_number
  end
  expect(found_invoices.uniq).to eq [nil]

  view_paid_invoices
  due = Session[:payment_details][:due].delete('$,').to_f
  remaining_due = due - Session[:payment_details][:amount].to_f
  expected = {:number => Session[:payment_details][:invoices][0], :due => (remaining_due)}
  actual = on(PaidInvoicesPage).invoice_numbers_and_amounts
  expect(actual).to include(expected)
  delete_unprocessed_payments
end

And(/^the invoice will be displayed in the payment history tab in pending status$/) do
  # invoice_numbers = Session[:payment_details][:invoices]
  # view_paid_invoices
  # found_invoices = invoice_numbers.collect do |invoice_number|
  #   invoice_number if on(UnpaidInvoicePage).invoice_numbers.include? invoice_number
  # end
  # expect(on(PaidInvoicePage).invoice_numbers.sort).to eq found_invoices.sort
  view_paid_invoices
  due = Session[:payment_details][:due].delete('$,').to_f
  remaining_due = due - Session[:payment_details][:amount].to_f
  expected = {:number => Session[:payment_details][:invoices][0], :due => (remaining_due)}
  actual = on(PaidInvoicesPage).invoice_numbers_and_amounts
  expect(actual).to include(expected)
end

def view_paid_invoices
  on(PaidInvoicesPage).payment_history
end

When(/^an owner makes a payment on an invoice less than or equal to $1/) do
  login_as(Login::USERWITHUNPAIDINVOICES)
  continue_status = [1.00, 0.99, 0.50, 0.00].collect do |amount|
    ensure_nothing_is_selected()
    select_not_payable_invoice(amount)

  end
  Session[:continue_status] = continue_status
end
Then(/^the owner cannot pay while the outstanding balance is less than or equal to $1$/) do
  expect(Session[:continue_status]).to_not include true
end

Given(/^an owner does not designate a bank account while making a payment$/) do
  pay_invoice_without_bank_acct
end


Given(/^an owner has multiple bank accounts available$/) do
  login_as(Login::USERWITHMULTIPLEBANKACCTS)
end

When(/^an owner makes a payment$/) do
  view_enter_payment_details_page

end

When(/^the owner makes a payment without accepting the terms and conditions$/) do
  submit_payment_without_terms
end

Then(/^the owner cannot confirm the payment$/) do
  expect(on(ConfirmSubmitPaymentPage).continue_element.disabled?).to be true
end

When(/^an owner makes more than a full payment on an invoice$/) do
  pay_more_than_full_balance
end

Then(/^the owner cannot pay while the payment exceeds the invoice amount$/) do
  expected_error = "!\nSorry, but the following errors occurred\nThe amount entered may not exceed "\
  "the selected invoice balance - $#{Session[:invoice_amount]}.Please enter a different amount."
  actual_error = on(EnterPaymentDetailsPage).error_container_element.text
  expect(actual_error).to eq expected_error
end