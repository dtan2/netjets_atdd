When(/^the owner adds a new bank account from view accounts$/) do
  login_as(Login::USERWITHUNPAIDINVOICES)
  add_account_from_manage_account()

end
Then(/^the owner will receive a message that account information was successfully added$/) do
  message = on(ManageAccountsPage).account_added_message
  expect(message).to equal 'something'
end
When(/^the bank account is added to payment accounts$/) do
  accounts = on(ManageAccountsPage).payment_account_numbers
  last_four_of_account = Session[:bank_account_details][:bank_account_number][-4..-1]
  expect(accounts).to include("Account Ending in ...#{last_four_of_account}")

end


When(/^the owner adds a new bank account from auto pay$/) do
  login_as(Login::USERWITHUNPAIDINVOICES)
  add_account_from_auto_pay()

end
Then(/^the owner receives a message that account information was successfully added$/) do
  message = on(AutoPayPage).account_added_message
  expect(message).to equal 'something'
end


When(/^the bank account can be used to make a payment$/) do
  account_nickname = Session[:bank_account_details]['bank_account_nickname'][0..19]
  on(EnterPaymentDetailsPage).added_bank_accounts = /#{account_nickname}/
  expect(on(EnterPaymentDetailsPage).added_bank_accounts).to include account_nickname
end

When(/^the owner adds a new bank account from make single payment$/) do
  login_as(Login::USERWITHUNPAIDINVOICES)
  add_accounts_single_payment

end


When(/^the same bank account is added to multiple owners$/) do
  login_as(Login::USERWITHUNPAIDINVOICES)
  bank_account_details = add_accounts_single_payment

  login_as(Login::USERWITHUNPAIDINVOICES2)
  add_accounts_single_payment(bank_account_details)

end

def navigate_from_home_to_enter_payment_details
  on(HomePage) do |page|
    page.select_account_invoice
    page.payments_and_invoices
  end
  on(UnpaidInvoicePage) do |page|
    page.select_payable_invoice
    page.continue
  end
end

Then(/^the bank account is added to the payment accounts$/) do
  account_nickname = Session[:bank_account_details]['bank_account_nickname'][0..19]

  login_as(Login::USERWITHUNPAIDINVOICES)
  navigate_from_home_to_enter_payment_details
  # Dustin and Otto commented this out because we don't think these are needed
  #matching_account = find_account_with_nickname(account_nickname)
  #on(EnterPaymentDetailsPage).added_bank_accounts = /#{account_nickname}/
  #expect(on(EnterPaymentDetailsPage).added_bank_accounts).to include matching_account
  expect(on(EnterPaymentDetailsPage).added_bank_accounts).to include account_nickname

  login_as(Login::USERWITHUNPAIDINVOICES2)
  navigate_from_home_to_enter_payment_details
  # Dustin and Otto commented this out because we don't think these are needed
  #matching_account = find_account_with_nickname(account_nickname)
  #on(EnterPaymentDetailsPage).added_bank_accounts = /#{account_nickname}/
  #expect(on(EnterPaymentDetailsPage).added_bank_accounts).to include matching_account
  expect(on(EnterPaymentDetailsPage).added_bank_accounts).to include account_nickname
end


When(/^the same bank account is added multiple times for an owner$/) do
  login_as(Login::USERWITHUNPAIDINVOICES)
  add_identical_accounts_from_manage_account
end
Then(/^the owner will not receive a message that account information was successfully added$/) do
  on(BankAccountDetailsPage).wait_for_ajax
  message = on(BankAccountDetailsPage).page_error
  expect(message).to eq 'Account already exists'
end


When(/^multiple bank accounts are added to a single account$/) do
  login_as(Login::USERWITHUNPAIDINVOICES)
  Session[:bank_account_details] = add_accounts_single_payment
  Session[:bank_account_details2] = add_account_from_enter_payment_details
end
Then(/^each bank account is added to the payment accounts$/) do
  nickname = Session[:bank_account_details]['bank_account_nickname'][0..19]
  on(EnterPaymentDetailsPage).added_bank_accounts = /#{nickname}/
  expect(on(EnterPaymentDetailsPage).added_bank_accounts).to include nickname

  nickname2 = Session[:bank_account_details2]['bank_account_nickname'][0..19]
  on(EnterPaymentDetailsPage).added_bank_accounts = /#{nickname2}/
  expect(on(EnterPaymentDetailsPage).added_bank_accounts).to include nickname2

end


When(/^the owner cancels adding a bank account$/) do
  login_as(Login::USERWITHUNPAIDINVOICES)
  cancel_add_accounts_from_manage_account()
end
Then(/^the bank account is not added to the payment accounts$/) do
  # accounts = on(ManageAccountsPage).payment_account_numbers
  # last_four_of_account = Session[:bank_account_details][:bank_account_number][-4..-1]
  # expect(accounts2).to !include("Account Ending in ...#{last_four_of_account}")

  account_nickname = Session[:bank_account_details]['bank_account_nickname'][0..19]
  added_bank_accounts = on(EnterPaymentDetailsPage).added_bank_accounts_options.join('|')

  expect(added_bank_accounts).not_to include account_nickname

end

Then(/^the bank account details include the nickname and last four account number digits$/) do
  account_nickname = Session[:bank_account_details]['bank_account_nickname']
  last_four_of_account = Session[:bank_account_details]['bank_account_number'].to_s[-4..-1]
  matching_account = format_matching_bank_acount(account_nickname, last_four_of_account)

  expect(on(EnterPaymentDetailsPage).added_bank_accounts_options).to include(matching_account)
end

When(/^the owner cancels adding a bank account\]$/) do
  login_as(Login::USERWITHUNPAIDINVOICES)
  Session[:bank_account_details] = cancel_add_bank_account
end