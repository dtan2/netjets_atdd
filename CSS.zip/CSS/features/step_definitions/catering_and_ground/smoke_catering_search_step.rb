Given(/^the user is in the catering page$/) do
  navigate_to(CateringPage)
end

When(/^The booker search for the catering items (.*)$/) do |catering_item|
  on_page CateringPage do |page|
    page.verify_on_catering_page
    page.select_add_link 1
    page.select_search_link 1
    page.set_search_item catering_item, 1
    page.select_go_link 1
  end
end

Then(/^a error (.*) should be displayed$/) do |message|
  on_page CateringPage do |page|
    page.verify_on_catering_page
    page.verify_search_results_message message, 1
  end
end

Then(/^a list of (.*) showing up.$/) do |items|
  on_page CateringPage do |page|
    page.verify_on_catering_page
    page.verify_catering_item_exists items, 1
    page.select_catering_item items, 1
  end
end

When(/^The booker search for the catering item and gets the error message:$/) do |table|
  # table is a | zoo           | Sorry, there's no catering items that match 'zoo'                                                             |

  on_page(CateringPage) do |page|
    page.verify_on_catering_page
    page.select_add_link 1
    page.select_search_link 1

    table.hashes.each do |data|
      page.set_search_item data['catering item'], 1
      page.select_go_link 1
      page.wait_for_ajax
      page.verify_search_results_message data['message'], 1
    end
  end
end

#Given(/^the user is in the catering pages$/) do
#  steps %{
#  Given the user is in the catering page
#  }
#end




