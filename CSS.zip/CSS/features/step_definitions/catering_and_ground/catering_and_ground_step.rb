#Given(/^I am in the catering page$/) do
#
#
#  #48 hours departure time
#  on_page ResPage do |page|
#
#    page.dep_date
#    #storing the result to use in rental page
#    page.arr_time
#  end
#
#
#
#end


Given(/^I have a reservation depart from "([^"]*)" to "([^"]*)" at (\d+) hours from now with "([^"]*)" as passenger$/) do |dep_airport, arr_airport, dephr, passenger|

  #visit LogIn
  # visit(LoginPage)
  # on(LoginPage).login_application_with
  # on(LoginPage).login_application_with(:red_robin_account)

  on(HomePage).bookFlight
  on(HomePage).wait_for_ajax

  #Enter the departure,arrival page and select air_craft

  on(FlightsPage) do |page|

    page.set_departure_airport(dep_airport, legNumber=1)
    page.set_arrival_airport(arr_airport, legNumber=1)
    page.select_aircraft_type('CITATION ENCORE')
    page.select_departure_date_time_link(legNumber=1)
    page.wait_for_ajax
    page.set_flight_date_time dephr
    page.select_calendar_save_link
    @dep_time = dephr.to_i
    @flight_time = page.get_estimated_flight_time
    page.wait_until{page.addReturnFlight_element.visible?}
    page.wait_for_ajax
    page.select_add_passengers_button
    page.wait_for_ajax
  end

  on(PassengersPage) do |page|

    page.verify_on_passengers_page
    page.set_passenger_name passenger
    page.select_add_to_flight_button
    @lead_passenger = page.get_default_lead_passenger
    page.wait_for_ajax

  end


end


When(/^I wanted to create departure chauffeured ground with different billing$/) do |table|

  on(GroundPage).wait_for_loading_overlay
  #on(GroundTransport).wait_ajax

  table.hashes.each do |items|


    case items['billing']


      when 'enrollment_number'

        on_page GroundPage do |grd|
          grd.wait_for_ajax
          grd.create_dep_chauffeured_enrollment_num '12 Passenger Van', @lead_passenger
          grd.save_chauffeured_order

        end

      when 'credit_card'
        on_page GroundPage do |grd|
          grd.wait_for_ajax
          grd.create_dep_chauffeured_credit_card '12 Passenger Van', 'XXXXXXXXXXXX1410', @lead_passenger
          grd.save_chauffeured_order

        end


      when 'bill_nj'
        on_page GroundPage do |grd|
          grd.wait_for_ajax
          grd.create_dep_chauffeured_NJ '12 Passenger Van', @lead_passenger
          grd.save_chauffeured_order
        end

    end


  end
end


Then(/^I wanted to create arrival chauffeured ground with different billing$/) do |table|

  on(GroundPage).wait_for_loading_overlay

  on(GroundPage).add_taxi

  table.hashes.each do |items|

    case items['billing']

      when 'enrollment_number'
        on_page GroundPage do |grd|

          grd.wait_for_ajax_loader
          grd.create_arr_chauffeured_enrollment_num '12 Passenger Van', @lead_passenger
          grd.save_chauffeured_order
        end

      when 'credit_card'

        on_page GroundPage do |grd|

          grd.wait_for_ajax_loader
          grd.create_arr_chauffeured_credit_crd '12 Passenger Van', 'XXXXXXXXXXXX1410', @lead_passenger
          grd.save_chauffeured_order
        end

      when 'bill_nj'
        on_page GroundPage do |grd|

          grd.wait_for_ajax_loader
          grd.create_arr_chauffeured_NJ '12 Passenger Van', @lead_passenger
          grd.save_chauffeured_order
        end

       taxi = on(GroundPage).gather_taxi

        taxi.should include 'Taxi'


    end


  end
end

Then(/^I want to create a rental ground order and return in (\d+) days with different billing$/) do |return_days, table|

  on(GroundPage).wait_for_loading_overlay


  table.hashes.each do |items|


    case items['billing']


      when 'enrollment_number'

        on_page GroundPage do |grd|
          grd.wait_for_ajax_loader

          grd.create_arr_rental_enrollment_num "Mid Size", @lead_passenger
          grd.set_rental_return_date return_days,@dep_time, @flight_time
          grd.save_rental_order
        end

      when 'credit_card'
        on_page GroundPage do |grd|

          grd.wait_for_ajax_loader

          grd.create_arr_rental_credit_card "Mid Size", 'XXXXXXXXXXXX1410', @lead_passenger
          grd.set_rental_return_date return_days, @dep_time, @flight_time
          grd.save_rental_order
        end

    end

  end


end
When(/^I want to go to the catering order page$/) do

  on(PassengersPage) do |page|
    page.wait_for_ajax
    page.nextCatering_element.when_present.click
    page.wait_for_ajax
    end

  on(CateringPage) do |page|
    page.verify_on_catering_page
    page.wait_for_ajax
    page.edit_catering
    page.wait_for_ajax
    page.wait_until{page.catering_legs_elements[0].link_element(:class=>'btn add').visible?}
  end

end


When(/^I am in the ground page.$/) do

  # @browser.span(:class => 'fancy-select-general-value', :index => 1).wait_until_present

  on(PassengersPage) do |page|

    page.skipToGroundTransportation

  end

end

Then(/^the booker search for the catering item and gets the error message:$/) do |table|

  @browser.link(:class => 'btn add').wait_until_present

  @browser.link(:class => 'btn btn17 catering-select-switch-mode', :text => 'Search').when_present.click

  table.hashes.each do |items|

    on(AddCatering).catering_search items['catering_item'], items['message']


  end

end

Given(/^I have a submitted reservation depart from "([^"]*)" to "([^"]*)" at (\d+) hours from now with "([^"]*)" as passenger$/) do |dep_airport, arr_airport, dephr, passenger|

  #visit LogIn
  visit(LoginPage)
  on(LoginPage).login_application_with(:red_robin_account)
  on(HomePage).bookFlight
  on(FlightsPage).wait_for_ajax

  #Enter the departure,arrival page and select air_craft

  on(FlightsPage) do |page|

    page.set_departure_airport(dep_airport, legNumber=1)
    page.set_arrival_airport(arr_airport, legNumber=1)
    page.select_aircraft_type('CITATION ENCORE')
    page.select_departure_date_time_link
    page.wait_for_ajax
    page.set_flight_date_time dephr
    page.select_calendar_save_link
    @dep_time = dephr.to_i #in hrs
    @flight_time = page.get_estimated_flight_time #in hrs
    page.addReturnFlight_element.when_visible
    page.wait_for_ajax
    page.select_add_passengers_button
    page.wait_for_ajax
  end

  on(PassengersPage) do |page|

    page.verify_on_passengers_page
    page.wait_for_ajax
    page.set_passenger_name passenger
    page.select_add_to_flight_button
    @lead_passenger = page.get_default_lead_passenger
    page.skipToReviewAndRequest
    page.wait_for_ajax

  end

  #send to Ijet2
  on(ReviewAndRequest) do |page|

    page.verify_on_review_and_request_page
    page.requestReservation

  end


end


When(/^I am in the submitted catering page$/) do

  on(ConfirmationPage) do |page|
   page.verify_on_confirmation_page
   page.viewPrintItinerary
  end

  on(RequestedReservationPage) do |page|
    page.verify_on_requested_reservation_page
    page.select_edit_catering
  end

  on(CateringPage) do |page|
    page. verify_on_catering_page
    page.edit_catering

  end

end
When(/^I am at the submitted edit ground page$/) do
  on(ConfirmationPage) do |page|
    page.verify_on_confirmation_page
    page.viewPrintItinerary
  end

  on(RequestedReservationPage) do |page|
    page.verify_on_requested_reservation_page
    page.select_edit_ground
  end

end

!Given(/^I have a NJE reservation depart from "([^"]*)" to "([^"]*)" at (\d+) hours from now with "([^"]*)" as passenger$/) do |dep_airport, arr_airport, dephr, passenger|

  #visit LogIn
  visit(LoginPage)
  on(LoginPage).login_application_with(:juma_account)
  on(HomePage).bookFlight
  on(FlightsPage).wait_for_ajax
  #Enter the departure,arrival page and select air_craft

  on(FlightsPage) do |page|
    page.set_departure_airport(dep_airport, legNumber=1)
    page.set_arrival_airport(arr_airport, legNumber=1)
    page.select_aircraft_type('FALCON 2000')
    page.select_departure_date_time_link(legNumber=1)
    page.wait_for_ajax
    # page.set_departure_time_from_now(dephr, leg_number=1, "NJE")
    page.set_flight_date_time dephr,"NJE"
    page.select_calendar_save_link
    @dep_time = (dephr.to_i)
    @flight_time = page.get_estimated_flight_time
    page.addReturnFlight_element.when_visible
    page.wait_for_ajax
    page.select_add_passengers_button
    page.wait_for_loading_overlay
  end

  on(PassengersPage) do |page|

    page.verify_on_passengers_page
    page.wait_for_ajax
    page.set_passenger_name passenger
    page.select_add_to_flight_button
    @lead_passenger = page.get_default_lead_passenger
  end
end

Then(/^I wanted to create NJE departure chauffeured ground with billing$/) do

  on(GroundPage).create_nje_dep_chauffeured "Luxury Minibus (16 + Driver)", @lead_passenger
  on(GroundPage).save_chauffeured_order

end

When(/^I want to add NJE arrival chauffeured ground transportation with billing$/) do
  on(GroundPage).create_nje_arr_chauffeured "Taxi (3 + Driver)",@lead_passenger
  on(GroundPage).save_chauffeured_order
end


Then(/^I want to add NJE rental ground order, return in (\d+) days.$/) do |pick_days|
  on(GroundPage).create_nje_arr_rental_credit_card "Large SUV (6-7 Passengers)", 'none', @lead_passenger
  on(GroundPage).set_rental_return_date pick_days, @dep_time, @flight_time, "NJE"
  on(GroundPage).save_rental_order
end


Then(/^I want to add two departure chauffeured ground orders.$/) do
  on(GroundPage).wait_for_ajax

  on_page GroundPage do |grd|
    grd.create_dep_chauffeured_enrollment_num '12 Passenger Van', @lead_passenger
    grd.save_chauffeured_order

    grd.wait_for_ajax_loader

    grd.create_dep_chauffeured_NJ '12 Passenger Van', @lead_passenger
    grd.save_chauffeured_order
  end
end

When(/^I want to add more passenger to the flight.$/) do |table|

  on(GroundPage).wait_for_ajax
  on(HeaderMenu).passengers_element.when_present.click
  on(PassengersPage).wait_for_ajax
  table.hashes.each do |items|
  on(PassengersPage).set_passenger_name items['passenger']
  on(PassengersPage).select_add_to_flight_button

  end

  #gather the reservation passenger list

  @passenger_list_res = on(PassengersPage).get_res_passenger_list

end


Then(/^the new passenger added to the first ground order.$/) do

  on(GroundPage) do |page|
    page.wait_for_loading_overlay
    #Going to the ground page
    page.skip_to_ground
    page.wait_for_ajax
    #Verify passenger added to the ground order
    page.get_dep_ground_passenger_list @passenger_list_res

  end
end


When(/^I want to add two arrival chauffeured ground orders.$/) do

  on(GroundPage).wait_for_ajax

  on_page GroundPage do |page|

    page.create_arr_chauffeured_NJ '12 Passenger Van', @lead_passenger
    page.save_chauffeured_order

    page.wait_for_ajax_loader

    page.chauffeured_form_element.link_element(:class=>'btn btn3 btn3-smaller').when_not_visible (timeout=10)

    page.create_arr_chauffeured_enrollment_num '12 Passenger Van', @lead_passenger
    page.save_chauffeured_order

  end
end


When(/^I want to add two rental ground orders and return in (\d+) days.$/) do |return_days|

  on_page GroundPage do |page|
    page.wait_for_loading_overlay
    page.create_arr_rental_enrollment_num "Mid Size", @lead_passenger
    page.set_rental_return_date return_days, @dep_time, @flight_times
    page.save_rental_order

    page.wait_for_ajax_loader
    page.rental_form_element.link_element(:class=>'btn btn3 btn3-smaller').when_not_visible (timeout=30)

    page.create_arr_rental_credit_card "Mid Size", 'none', @lead_passenger
    page.set_rental_return_date return_days, @dep_time, @flight_times
    page.calendar_element.when_not_visible
    page.save_rental_order
  end
end
When(/^I want to edit the submitted ground order.$/) do


  on(GroundPage) do |page|

  page.wait_for_ajax_loader
  page.reviewAndRequest
  end
  on(RequestedReservationPage).verify_on_requested_reservation_page
  on(RequestedReservationPage).edit_passenger
  on(PassengersPage).wait_for_ajax
 end

When(/^I am in the departure chauffeured page.$/) do

  @browser.wait_until(30, "Ground page not ready") do

    @browser.url.include? '/Book/Ground'

  end

  #Open the departure chauffeured page
  on(GroundPage).add_dep_chauffeured

end


Then(/^prefer ground vendor "([^"]*)" is selected for ground order.$/) do |pref_vendor|

  on(GroundPage) do |page|
    page.wait_for_ajax_loader
    msg = page.gather_chauffeured_vendor
  expect(msg[0].strip).to eq pref_vendor
  end

end

When(/^I am in the arrival chauffeured page.$/) do

  @browser.wait_until(20, "Ground page not ready") do

    @browser.url.include? '/Book/Ground'
  end

  on(GroundPage).add_arr_chauffeured

end


When(/^I am in the rental order page.$/) do

  on(GroundPage).wait_for_ajax_loader

  @browser.wait_until(20, "Ground page not ready") do

    @browser.url.include? '/Book/Ground'
  end

  on(GroundPage).add_arr_rental
end


When(/^I want to see the catering menu.$/) do
  on(AddCatering).in_catering_page
  @browser.link(:class, 'edit btn').when_present.click
end

When(/^I want to see the "([^"]*)" menu.$/) do |menu|
  # on(CateringPage).wait_for_ajax
  on(CateringPage).select_menu menu
end


When(/^I want to see the sub menu$/) do
  on(CateringPage) do |page|
  page.wait_for_ajax
  page.wait_until{page.main_menu_element.link_element(:text=>'Breakfast').visible?}
  page.sub_menu_element.click
  end
end

Then(/^I am seeing  "([^"]*)" food is server per cabin size$/) do |food_temp|
    on(CateringPage).verify_food_per_cabin food_temp
  end


When(/^I want to upgrade my aircraft to large cabin$/) do
  on(PassengersPage).nextCatering
  on(PassengersPage).wait_for_ajax
  on(CateringPage).verify_on_catering_page
  on(HeaderMenu).flights_element.when_present.click
  on(FlightsPage) do |page|
    #Timewait until you are in the ground page
    page.wait_for_ajax
    page.verify_on_flights_page
    #Upgrade aircraft
    page.upgrade_aircraft_type "GULFSTREAM V/550", 1
    page.wait_for_ajax
    page.select_add_passengers_button
  end

end


When(/^I want to verify "([^"]*)" is not the catering order$/) do |passenger_asi|

  on(CateringPage).verify_on_catering_page
  on(CateringPage).wait_for_ajax
  ordered_item_temp = on(CateringPage).get_catering_items

  expect(ordered_item_temp).not_to include passenger_asi

  # asi_status = @browser.div(:class => 'orders').text.include? passenger_asi
  #
  # if asi_status == true
  #
  #   fail "#{passenger_asi} added to the catering order"
  # end
end


When(/^I want to verify "([^"]*)" is in the catering order$/) do |asi|

  on(CateringPage).verify_catering_ordered_item asi

  # ordered_item_temp = on(CateringPage).get_catering_items
  #
  # ordered_item = ordered_item_temp.map{|x|x.downcase}
  #
  # expect(ordered_item).to include "1x#{asi.downcase.delete(' ')}"
 end

When(/^I want to add "([^"]*)" to the reservation$/) do |passenger|

  on(HeaderMenu).select_passenger
  # @browser.span(:class => 'passengers').click

  on(PassengersPage) do |page|
    page.wait_for_ajax
    page.verify_on_passengers_page
    page.set_passenger_name passenger
    page.select_add_to_flight_button

  end
end

When(/^I want to down grade my aircraft.$/) do

  on(CateringPage).wait_for_ajax_loader
  @browser.li(:class => 'first done').click
  on(FlightsPage).wait_for_loading_overlay
  #Timewait until you are in the ground page
  @browser.link(:class => 'btn primary delete').click
  on(FlightsPage).addReturnFlight_element.when_visible
  on(FlightsPage).wait_for_ajax
  on(FlightsPage).select_add_passengers_button
end


When(/^I want to verify "([^"]*)","([^"]*)" and "([^"]*)" are in the catering order$/) do |catering1, catering2, catering3|

   ordered_item = on(CateringPage).get_catering_items

  expect(ordered_item).to include "1x#{catering1.delete(' ')}"
  expect(ordered_item).to include "50x#{catering2.delete(' ')}"
  expect(ordered_item).to include "1x#{catering3.delete(' ')}"

end

Then(/^I want to add "([^"]*)" and "([^"]*)" to catering order$/) do |catering1, catering2|

  on(CateringPage) do |page|
    page.wait_for_ajax
    page.add_catering_item catering1
    page.add_catering_item catering2
    @array_catering = page.get_catering_items
    page.save_catering
    page.wait_for_ajax
    page.edit_catering_element.when_visible
    page.wait_for_ajax
    page.verify_order_summary_catering_items @array_catering

  end


end


When(/^I want to delete "([^"]*)" from catering order$/) do |rm_catering|

  on(CateringPage) do |page|
    page.edit_catering
    page.delete_catering_item rm_catering
    @array_catering = page.get_catering_items
    page.wait_for_ajax_loader
    page.save_catering
    page.wait_for_ajax
    page.edit_catering_element.when_visible
    page.verify_order_summary_catering_items @array_catering

  end


end


When(/^I want to change "([^"]*)" to  quantity of "([^"]*)"$/) do |cateringItem, num|
   on(CateringPage) do |page|
    page.wait_for_ajax
    page.edit_catering
    page.change_catering_quantity cateringItem, num
    @array_catering = page.get_catering_items
    page.save_catering
    page.wait_for_loading_overlay
    page.edit_catering_element.when_visible(timeout=10)
    page.wait_for_ajax
    page.verify_order_summary_catering_items @array_catering
  end

end

When(/^I want to change the departure airport to "([^"]*)"$/) do |dep_airport|

 on(Flights).wait_for_ajax

  @browser.li(:class => 'first done').click

  #makesure in flight page

  on(ResPage).in_flight_page

  on(ResPage).dep_input (dep_airport)

  @browser.link(:class => 'radius-search', :index => 0).wait_until_present

  sleep 2
  @browser.link(:class => 'btn btn3 next-step add-passengers').click

end


Then(/^warning message pops up listing "([^"]*)" has been removed$/) do |catering_item|

  sleep 2

  fail "#{catering_item} not showing in the message" unless @browser.div(:class => 'catering-changes').text.include? catering_item

end
When(/^I want to depart at "([^"]*)" "([^"]*)"$/) do |time, meridian|

  on(CateringPage).verify_on_catering_page
  on(HeaderMenu).select_flights
  # @browser.link(:class => 'btn add').wait_until_present
  # @browser.li(:class => 'first done').click
  on(FlightsPage) do |page|
  page.wait_for_ajax
  page.verify_on_flights_page
  page.select_existing_departure_date_time_link
  page.wait_for_ajax
  page.set_exact_departure_time time, meridian
  page.wait_for_ajax
  page.select_add_passengers_button
  end
end


When(/^I want to remove "([^"]*)" from my reservation.$/) do |passenger|
  on(CateringPage).wait_for_ajax
  on(HeaderMenu).passengers_element.click
   on(PassengersPage) do |page|
   page.wait_for_ajax
   page.verify_on_passengers_page
   page.select_remove_passenger_from_this_flight passenger, 1
   end
end

Then(/^the new passenger added to the first submitted ground order.$/) do
     on(PassengersPage).wait_for_loading_overlay
  # @browser.link(:class => 'btn btn3 next-step').click
     on(RequestedReservationPage).verify_on_requested_reservation_page
     on(RequestedReservationPage).edit_ground_element.click
  # @browser.link(:class => 'btn edit').click
     on(GroundPage).get_dep_ground_passenger_list @passenger_list_res


end

# Given(/^I have a NJE_card reservation depart from "([^"]*)" to "([^"]*)" at (\d+) hours from now with "([^"]*)" as passenger$/) do |arg1, arg2, arg3, arg4|
#   visit LogIn
#
#   on(LogIn).login_to_site_nje_card
#
#   on(PlanBook).forward_reservation
#
#   on(ResPage) do |page|
#
#     page.dep_input dep_airport
#     page.arr_input arr_airport
#     page.select_air_craft_NJE
#
#   end

# end
When(/^no catering item ordered$/) do

  on(CateringPage) do |page|
  page.wait_for_loading_overlay
  page.verify_on_catering_page
  msg=page.gather_catering_summary_msg
  expect(msg[0]).to eq 'No catering'
  page.wait_for_ajax
  page.BacktoReservationSum_element.when_present.click
  page.wait_for_ajax
  end
   on(RequestedReservationPage).select_edit_passengers
  on(RequestedReservationPage).wait_for_ajax
end


When(/^I want to add more passenger to the submitted flight.$/) do |table|

  on(PassengersPage).verify_on_passengers_page

  table.hashes.each do |items|
    on(PassengersPage).set_passenger_name items['passenger']
    on(PassengersPage).select_add_to_flight_button
  end
    #gather the reservation passenger list
    @passenger_list_res = on(PassengersPage).get_res_passenger_list

  on(PassengersPage).savePassenger

  on(PassengersPage).wait_for_loading_overlay

end

When(/^"([^"]*)" is added to the edit catering order.$/) do |catering_item|

  on(CateringPage) do |page|
  page.wait_for_loading_overlay
  page.verify_on_catering_edit_page
  page.wait_for_ajax
  msg =page.get_catering_items
  expect(msg[1]).to include "1x#{catering_item.delete(' ')}"
  page.BacktoReservationSum
 end
end

Given(/^I have a submitted reservation with passenger's ASI catering order$/) do

  # visit(LoginPage)
  on(LoginPage).login_application_with(:red_robin_account)
  on(HomePage).bookFlight

  #Enter the departure,arrival page and select air_craft

  on(FlightsPage) do |page|
    page.wait_for_ajax
    page.set_departure_airport(dep_airport='CLE', legNumber=1)
    page.set_arrival_airport(arr_airport = 'LNK', legNumber=1)
    page.select_aircraft_type('CITATION ENCORE')
    page.select_departure_date_time_link(legNumber=1)
    page.wait_for_ajax
    page.set_flight_date_time '100'
    page.select_calendar_save_link
    page.wait_for_ajax
    page.addReturnFlight_element.when_visible
    page.wait_for_ajax
    page.select_add_passengers_button
    page.wait_for_loading_overlay
  end

  on(PassengersPage) do |page|

    page.verify_on_passengers_page
    page.wait_for_ajax
    page.set_passenger_name(passenger = 'Dennis')
    page.select_add_to_flight_button
    page.set_passenger_name(passenger = 'Eric Houseman')
    page.select_add_to_flight_button
    @lead_passenger = page.get_default_lead_passenger
    page.wait_for_loading_overlay
    page.skipToReviewAndRequest
  end
  #send to Ijet2
  on(ReviewAndRequest) do |page|
    page.verify_on_review_and_request_page
    page.requestReservation
  end

end


When(/^I remove "([^"]*)" from the reservation$/) do |passenger|

  on(RequestedReservationPage).verify_on_requested_reservation_page
  on(RequestedReservationPage).wait_for_ajax
  on(RequestedReservationPage).select_edit_passengers

  on(PassengersPage) do |page|
      page.verify_on_passengers_page
      page.wait_for_ajax
      page.select_remove_passenger_from_this_flight passenger, 1
      page.wait_for_ajax
      page.select_lead_passenger_list 'Eric Houseman', 1
      page.wait_for_ajax
   end
end
Then(/^"([^"]*)" is still in the catering order$/) do |passenger_ASI|


  on(PassengersPage).savePassenger
  on(PassengersPage).wait_for_ajax
  on(RequestedReservationPage).verify_on_requested_reservation_page
  on(RequestedReservationPage).verify_catering_item_submitted passenger_ASI


end

Then(/^I should see"([^"]*)" and his dietary restriction of "([^"]*)","([^"]*)","([^"]*)","([^"]*)"$/) do |passenger, arg2, arg3, arg4, arg5|
  #building an array
  on(CateringPage) do |page|
      page.verify_on_catering_page
      page.wait_for_ajax
      page.select_dietary
      page.wait_for_ajax
      name,dietary = page.gather_passenger_dietary_restrictions
      expect(name).to eq passenger
      expect(dietary[0]).to eq arg5
      expect(dietary[1]).to eq arg4
      expect(dietary[2]).to eq arg3
      expect(dietary[3]).to eq arg2
  end

end

Given(/^I have a passenger with dietary restriction of Vegan,Hindu,Diabetic,Peanuts$/) do
#visit LogIn
  navigate_to(LoginPage)
  on(LoginPage).login_application_with(:red_robin_account)
  on(HomePage).bookFlight
  on(FlightsPage).wait_for_ajax
  #Enter the departure,arrival page and select air_craft

  on(FlightsPage) do |page|

    page.set_departure_airport(dep_airport='CMH', legNumber=1)
    page.set_arrival_airport(arr_airport = 'MIA', legNumber=1)
    page.select_aircraft_type('CITATION ENCORE')
    page.select_departure_date_time_link(legNumber=1)
    page.wait_for_ajax
    page.set_flight_date_time '100'
    page.select_calendar_save_link
    page.addReturnFlight_element.when_visible
    page.wait_for_ajax
    page.select_add_passengers_button
    page.wait_for_loading_overlay
  end

  on(PassengersPage) do |page|

    page.verify_on_passengers_page
    page.wait_for_ajax
    page.set_passenger_name "Jeff Neely"
    page.select_add_to_flight_button

  end
end

Given(/^I have a submitted reservation with catering and ground order$/) do

  visit(LoginPage)
  on(LoginPage).login_application_with(:red_robin_account)
  on(HomePage).bookFlight

  #Enter the departure,arrival page and select air_craft

  on(FlightsPage) do |page|
    page.wait_for_ajax
    page.set_departure_airport('CLE', legNumber=1)
    page.set_arrival_airport('LNK', legNumber=1)
    page.select_aircraft_type('CITATION ENCORE')
    page.select_departure_date_time_link
    page.wait_for_ajax
    page.set_flight_date_time dephr ='100'
    page.select_calendar_save_link
    page.wait_for_ajax
    @dep_time = dephr.to_i
    @flight_time = page.get_estimated_flight_time
    page.addReturnFlight_element.when_visible
    page.wait_for_ajax
    page.select_add_passengers_button
    page.wait_for_ajax
  end

  on(PassengersPage) do |page|

    page.verify_on_passengers_page
    page.set_passenger_name 'Dennis'
    page.select_add_to_flight_button
    @lead_passenger = page.get_default_lead_passenger
    page.wait_for_loading_overlay
    page.skipToGroundTransportation
    page.wait_for_ajax
  end
  #ASI catering has been created, moves on to the ground page
  on(GroundPage) do |page|
    #Creates departure ground
    page.create_dep_chauffeured_enrollment_num '12 Passenger Van', @lead_passenger
    page.save_chauffeured_order
  end

  #Creates a arrival ground
  on(GroundPage) do |grd|
    grd.create_arr_chauffeured_enrollment_num '12 Passenger Van', @lead_passenger
    grd.save_chauffeured_order
  end

  #Creates rental arrival ground
  on(GroundPage) do |grd|
    grd.wait_for_ajax_loader
    grd.create_arr_rental_enrollment_num "Mid Size", @lead_passenger
    grd.set_rental_return_date '3', @dep_time, @flight_time
    grd.save_rental_order
    grd.rental_form_element.link_element(:class=>'btn btn3 btn3-smaller').when_not_visible (timeout=20)
    grd.reviewAndRequest
  end

  on(ReviewAndRequest).verify_on_review_and_request_page
  on(ReviewAndRequest).requestReservation
end


When(/^I want to cancel my submitted reservation$/) do


  on(ConfirmationPage) do |page|

    page.verify_on_confirmation_page

    page.viewPrintItinerary

  end

  on(RequestedReservationPage) do |page|
    page.select_cancel_flight_button
    page.wait_for_ajax
    page.yes_cancel

  end
end

Then(/^My reservation, catering and ground order should also be cancel.$/) do


  on(RequestedReservationPage) do |page|
  page.wait_for_ajax_loader
  catering = page.gather_catering_order
  expect(catering[1]).to eq 'No catering'
  dep_ground = page.gather_departure_ground_order
  expect(dep_ground[0]).to eq  'No ground orders'
  arr_ground =page.gather_arrival_ground_order
  expect(arr_ground[0]).to eq  'No ground orders'
  end

  # fail "catering is not cancel" unless @browser.div(:class => 'section catering clear').text.include? 'No catering'
  #
  # fail "arrival chauffeured is not cancel" unless @browser.span(:class => 'noground', :index => 0).text.include? 'No ground orders'
  #
  # fail "arrival rental is not cancel" unless @browser.span(:class => 'noground', :index => 1).text.include? 'No ground orders'


end
When(/^I want to delete the catering order$/) do

  on(CateringPage).verify_on_catering_page
  on(CateringPage).select_delete_order
  on(CateringPage).confirm_del
end


Then(/^my submitted catering order is cancelled$/) do

  on(CateringPage) do |page|
   page.wait_for_loading_overlay
   page.wait_until do
   page.catering_msg_element.visible?
   end
    expect(page.catering_msg_element.text).to include 'No catering'
  end
end

When(/^I want to delete the ground order$/) do

  on(GroundPage).delete_all_ground
  on(GroundPage).wait_for_ajax_loader
  on(GroundPage).reviewAndRequest


end

When(/^I want to change the departure airport$/) do

   on(ConfirmationPage) do |page|
   page.verify_on_confirmation_page
   page.viewPrintItinerary
   end

  on(RequestedReservationPage) do |page|

    page.verify_on_requested_reservation_page
    page.wait_for_ajax
    page.edit_flight
  end

  on(FlightsPage) do |page|

    page.verify_on_flights_page
    page.wait_for_loading_overlay
    page.wait_for_ajax
    # sleep 2
    page.set_departure_airport 'FDY'
    #Set departure time
    page.select_departure_date_time_link
    page.select_calendar_save_link
    page.wait_until do
    page.addOnwardFlight_element.visible?
    end
    page.save_exit

  end

end

Then(/^the catering warning message pops up$/) do

  on(FlightsPage) do |page|
  page.wait_for_loading_overlay
  msg = page.gather_pop_catering_warning_msg
 link = page.gather_pop_links_msg
  expect(msg[0]).to eq 'New catering vendor selected'
  expect(msg[2]).to eq 'Sake'
  expect(link).to include 'REVIEW CATERING ORDER'
  end
end

When(/^I want to add departure chauffeured ground order$/) do

  on(GroundPage) do |page|
    page.verify_on_ground_page
    page.create_dep_chauffeured_NJ '12 Passenger Van', @lead_passenger
    page.save_chauffeured_order
    page.chauffeured_form_element.link_element(:class=>'btn btn3 btn3-smaller').when_not_visible (timeout=20)
    page.wait_for_ajax
    page.reviewAndRequest
  end
end

Then(/^the ground warning message pops up$/) do

  on(FlightsPage) do |page|
  page.wait_for_loading_overlay
  msg = page.gather_pop_ground_warning_msg
  link = page.gather_pop_links_msg
  expect(msg[1]).to eq 'Departure ground transport has been affected.'
  expect(link[2]).to eq 'REVIEW GROUND ORDER'
  end



end
When(/^I want to review my ground order$/) do

  on(FlightsPage) do |page|
  page.wait_for_ajax_loader
  page.review_ground
  end
  on(GroundPage).verify_on_ground_page
  end

When(/^I want to add arrival chauffeured ground order$/) do

  on(GroundPage) do |page|
    page.verify_on_ground_page
    page.create_arr_chauffeured_NJ '12 Passenger Van', @lead_passenger
    page.wait_for_ajax
    page.save_chauffeured_order
    page.chauffeured_form_element.link_element(:class=>'btn btn3 btn3-smaller').when_not_visible (timeout=20)
    page.reviewAndRequest
  end

end
When(/^I want to change the arrival airport$/) do

  on(RequestedReservationPage) do |page|
    page.verify_on_requested_reservation_page
    page.wait_for_ajax
    page.edit_flight

  end

  on(FlightsPage) do |page|
    page.verify_on_flights_page
    page.wait_for_loading_overlay
    page.wait_for_ajax
    page.set_arrival_airport(dep_airport='FDY', legNumber=1)
    page.wait_for_ajax_loader
    page.wait_for_ajax
    page.save_exit
  end


end
When(/^I want to add arrival rental ground order$/) do


  on(GroundPage) do |page|
    page.verify_on_ground_page
    page.wait_for_ajax
    page.create_arr_rental_enrollment_num "Mid Size", @lead_passenger
    page.set_rental_return_date 3,@dep_time, @flight_time
    page.wait_for_ajax
    page.save_rental_order
    page.rental_form_element.link_element(:class=>'btn btn3 btn3-smaller').when_not_visible (timeout=20)
    page.reviewAndRequest
  end

end

#Add 'Organic Crudites' as asi to either Dennis or Eric
When(/^I want to review my warning message$/) do

  on(FlightsPage) do |page|
  page.wait_for_loading_overlay
  msg = page.gather_pop_warning_msg
  expect(msg[5]).to eq 'New catering vendor selected'
  expect(msg).to include 'Sake'
  expect(msg).to include 'REVIEW CATERING ORDER'
  expect(msg).to include 'Departure ground transport has been affected.'
  expect(msg).to include 'REVIEW GROUND ORDER'
  end

end


Given(/^I have Live Oak submitted reservation depart from "([^"]*)" to "([^"]*)" at (\d+) hours from now with "([^"]*)" as passenger$/) do |dep_airport, arr_airport, dephr, passenger|

  #visit LogIn
  visit(LoginPage)
  on(LoginPage).login_application_with(:live_oak_account)
  on(HomePage).bookFlight

  #Enter the departure,arrival page and select air_craft

  on(FlightsPage) do |page|
    page.wait_for_ajax
    page.set_departure_airport(dep_airport, legNumber=1)
    page.set_arrival_airport(arr_airport, legNumber=1)
    page.select_aircraft_type('CITATION EXCEL/XLS')
    page.select_departure_date_time_link
    page.wait_for_ajax
    page.set_flight_date_time dephr
    page.select_calendar_save_link
    @dep_time = dephr.to_i*60*60
    @flight_time = page.get_estimated_flight_time
    page.addReturnFlight_element.when_visible
    page.wait_for_ajax
    page.select_add_passengers_button
    page.wait_for_loading_overlay
  end

  on(PassengersPage) do |page|

    page.verify_on_passengers_page
    page.wait_for_ajax
    page.set_passenger_name passenger
    page.select_add_to_flight_button
    @lead_passenger = page.get_default_lead_passenger
    page.skipToReviewAndRequest
    page.wait_for_ajax

  end

  #send to Ijet2
  on(ReviewAndRequest) do |page|

    page.verify_on_review_and_request_page
    page.requestReservation

  end


end

When(/^I want to delete my catering order.$/) do

  on(AddCatering).in_catering_page

  @browser.link(:class => 'delete btn').click
  sleep 1
  @browser.link(:class => 'btn btn1 confirm').click

  sleep 1
  fail "Catering order is not deleted" unless @browser.div(:class => 'grid g5 gmp3').text.include? 'No catering'


end

When(/^I want to add "([^"]*)"$/) do |passenger|

  on(PassengersPage).wait_for_loading_overlay

  on(PassengersPage).set_passenger_name passenger
  on(PassengersPage).wait_for_ajax_loader
  on(PassengersPage).select_add_to_flight_button
  on(PassengersPage).wait_for_ajax_loader
  # on(PassengersPage).savePassenger
end

Then(/^I want to see approved vendor as the catering vendor$/) do |table|

  on(CateringPage).wait_for_ajax_loader

  on(CateringPage).add_catering_item 'Crudites'

  on(CateringPage).wait_for_ajax

  approve_vendor = []

  table.hashes.each do |items|
      approve_vendor << items["Vendors"]
     end

  gui_vendor = on(CateringPage).gather_catering_vendor(leg_num =1)
   catering_vendor = gui_vendor.gsub('Fulfilled by ','')
   expect(approve_vendor).to include catering_vendor
end

Then(/^I want to see "([^"]*)" as the catering vendor$/) do |vendor|

  on(CateringPage) do |page|
  page.wait_for_ajax
  msg =page.gather_catering_vendor
  expect(msg).to eq "Fulfilled by #{vendor}"
  end
 end

Given(/^I am at the submitted reservation passenger page$/) do

  navigate_to(PlanBook).forward_reservation

  #Enter the departure,arrival page and select air_craft
  on(ResPage) do |page|

    page.dep_input "CMH"
    page.arr_input "MIA"
    page.select_air_craft_NJA

  end

  on_page ResPage do |page|

    page.dep_date "48"
    #storing the result to use in rental page
    page.arr_time
  end

  on(ResPage).wait_spinner
  on(AddPassenger).add_passenger "Eric"
  on(ResPage).wait_spinner
  on(ResPage).send_to_ijet2

  on(Review).in_confirmation_page

  #Gets to summary page
  @browser.span(:class => 'center-txt').click

  #Gets to Passenger page
  @browser.link(:class => 'edit btn', :index => 1).click

end

When(/^I enter NPA of "([^"]*)" and NXX of "([^"]*)"$/) do |arg1, arg2|

  on(AddPassenger).in_passenger_page
  on(ResPage).wait_spinner
  @browser.radio(:id => 'contact-lead-0').set
  @browser.text_field(:id => 'area-10').set arg1
  @browser.text_field(:id => 'number-10').set arg2

  on(AddPassenger).save_passenger

end


Then(/^NPA "([^"]*)" and NXX "([^"]*)" are saved$/) do |arg1, arg2|

  @browser.link(:class => 'edit btn', :index => 1).click

  fail "#{arg1} in not in the NPA text field" unless  @browser.text_field(:id => 'area-10').include? arg1

  fail "#{arg2} in not in the NXX text field" unless  @browser.text_field(:id => 'number-10').include? arg2
end

And(/^I want to verify empty catering order$/) do
  on(CateringPage) do |page|
  page.verify_on_catering_page
  page.wait_for_ajax
  msg =page.gather_catering_order_msg
 expect(msg).to eq "No items ordered"
 end
end


Given(/^I have a reservation depart from departure to "([^"]*)" at (\d+) hours from now with "([^"]*)" as passenger$/) do |arr_airport, dephr, passenger, table|

  navigate_to(LoginPage)
  on(LoginPage).login_application_with(:red_robin_account)
  on(HomePage).bookFlight

  #Enter the departure,arrival page and select air_craft

  table.hashes.each do |items|

    on(FlightsPage) do |page|
      page.set_departure_airport items['airport'], 1
      page.set_arrival_airport(arr_airport, legNumber=1)
      page.select_aircraft_type('CITATION ENCORE')
      page.select_departure_date_time_link(legNumber=1)
      page.wait_for_ajax
      page.set_flight_date_time dephr
      page.select_calendar_save_link
      @dep_time = dephr.to_i
      @flight_time = page.get_estimated_flight_time
      page.addReturnFlight_element.when_visible
      page.wait_for_ajax
      page.select_add_passengers_button
      page.wait_for_loading_overlay
    end
    on(PassengersPage) do |page|

      page.verify_on_passengers_page
      page.set_passenger_name passenger
      page.select_add_to_flight_button
      @lead_passenger = page.get_default_lead_passenger
    end

  end


end

Given(/^Create a reservation depart from (.*) to "([^"]*)" at (\d+) hours from now with "([^"]*)" as passenger$/) do |departure, arr_airport, dephr, passenger|

  navigate_to(LoginPage)
  on(LoginPage).login_application_with(:red_robin_account)
  on(HomePage).bookFlight
  #Enter the departure,arrival page and select air_craft

  on(FlightsPage) do |page|
    page.set_departure_airport departure, 1
    page.set_arrival_airport(arr_airport, legNumber=1)
    page.select_aircraft_type('CITATION ENCORE')
    page.select_departure_date_time_link(legNumber=1)
    page.wait_for_ajax
    page.set_flight_date_time dephr
    page.select_calendar_save_link
    page.addReturnFlight_element.when_visible
    page.wait_for_ajax
    page.select_add_passengers_button
    page.wait_for_loading_overlay
  end

  on(PassengersPage) do |page|

    page.verify_on_passengers_page
    page.set_passenger_name passenger
    page.select_add_to_flight_button
    page.skipToReviewAndRequest
    page.wait_for_loading_overlay
  end

  on(ReviewAndRequest).verify_on_review_and_request_page

  on(ReviewAndRequest).requestReservation

end


Given(/^Create a reservation depart from "([^"]*)" to (.*) at (\d+) hours from now with "([^"]*)" as passenger$/) do |dep_airport, arrival, dephr, passenger|

  navigate_to(LoginPage)
  on(LoginPage).login_application_with(:red_robin_account)
  on(HomePage).bookFlight
  #Enter the departure,arrival page and select air_craft

  on(FlightsPage) do |page|
    page.set_departure_airport dep_airport, 1
    page.set_arrival_airport(arrival, legNumber=1)
    page.select_aircraft_type('CITATION ENCORE')
    page.select_departure_date_time_link(legNumber=1)
    page.wait_for_ajax
    page.set_flight_date_time dephr
    page.select_calendar_save_link
    page.addReturnFlight_element.when_visible
    page.wait_for_ajax
    page.select_add_passengers_button
    page.wait_for_loading_overlay
  end

  on(PassengersPage) do |page|

    page.verify_on_passengers_page
    page.set_passenger_name passenger
    page.select_add_to_flight_button
    page.skipToReviewAndRequest
    page.wait_for_loading_overlay
  end

  on(ReviewAndRequest).verify_on_review_and_request_page

  on(ReviewAndRequest).requestReservation


end


Given(/^Depart from airport to "([^"]*)" at (\d+) hours from now$/) do |arrival, dephr, table|
  navigate_to(LoginPage)
  on(LoginPage).login_application_with(:red_robin_account)
  on(HomePage).bookFlight
  #Enter the departure,arrival page and select air_craft
  on(FlightsPage) do |page|
    page.set_departure_airport 'YQX', 1
    page.set_arrival_airport(arrival, legNumber=1)
    page.select_aircraft_type('HAWKER 800XP - Collins')
    page.select_departure_date_time_link(legNumber=1)
    page.wait_for_ajax
    page.set_flight_date_time dephr
    page.select_calendar_save_link
    page.select_add_passengers_button
    no_error_msg_airport =[]
    table.hashes.each do |items|
      page.wait_for_loading_overlay
      page.set_departure_airport items['airport'], 1
      page.depart_time
      page.set_departure_time_from_now(dephr, leg_number=1)
      page.addReturnFlight_element.when_visible
      page.wait_for_ajax
      page.select_add_passengers_button
      on(FlightsPage).wait_for_ajax_loader


      if on(FlightsPage).error_msg_element.text.should include "Flights requested through Owner Portal must be booked at least 48 hours (2 days) in advance"

      else
        no_error_msg_airport << items['airport']
        on(PassengersPage).wait_for_loading_overlay
        on(PassengersPage).wait_for_ajax_loader
        on(PassengersPage).flights_element.click

      end


    end
  end

  puts "Airport with no error message #{no_error_msg_airport}"
end


Given(/^I have a Live Oak reservation depart from "([^"]*)" to "([^"]*)" at (\d+) hours from now with "([^"]*)" as passenger$/) do |dep_airport, arr_airport, dephr, passenger|

  navigate_to(LoginPage)
  on(LoginPage).login_application_with(:live_oak_account)
  on(HomePage).bookFlight

  #Enter the departure,arrival page and select air_craft

  on(FlightsPage) do |page|
    page.wait_for_ajax
    page.set_departure_airport(dep_airport, legNumber=1)
    page.wait_for_ajax
    page.set_arrival_airport(arr_airport, legNumber=1)
    page.select_aircraft_type('CITATION EXCEL/XLS')
    page.select_departure_date_time_link(legNumber=1)
    page.wait_for_ajax
    page.set_flight_date_time dephr
    page.select_calendar_save_link
    @dep_time = dephr.to_i
    @flight_time = page.get_estimated_flight_time
    page.addReturnFlight_element.when_visible
    page.wait_for_ajax
    page.select_add_passengers_button
    page.wait_for_ajax
  end

  on(PassengersPage) do |page|

    page.verify_on_passengers_page
    page.set_passenger_name passenger
    page.select_add_to_flight_button
    @lead_passenger = page.get_default_lead_passenger

  end

end


And(/^I want to add "([^"]*)" to the flight.$/) do |passenger|

  on(PassengersPage) do |page|
    page.wait_for_loading_overlay
    page.set_passenger_name passenger
    page.select_add_to_flight_button
  end

end

And(/^I have a departure chauffeured order$/) do

  @browser.span(:class => 'fancy-select-general-value', :index => 1).wait_until_present

  on_page PassengersPage do |page|

    page.wait_for_loading_overlay
    page.skipToGroundTransportation
    page.wait_for_loading_overlay

  end

  on_page GroundPage do |page|
    page.wait_for_ajax_loader
    page.create_dep_chauffeured_NJ '12 Passenger Van', @lead_passenger
    page.save_chauffeured_order
    page.wait_for_ajax
    page.wait_until{page.ground_leg_elements[0].link_element(:class=>'btn').visible?}
  end

end

When(/^I want to delete lead passenger "([^"]*)" from wip reservation$/) do |passenger|


   on(HeaderMenu).select_passenger

  on_page PassengersPage do |page|
    page.wait_for_ajax
    page.verify_on_passengers_page
    page.select_remove_passenger_from_this_flight passenger, 1
    page.wait_for_ajax
    page.select_default_lead_passenger
    page.wait_for_ajax
  end

end

Then(/^departure chauffeured has"([^"]*)" as ground vendor$/) do |ground_vendor|

  on(PassengersPage) do |page|
    #Going to the ground page
    page.skipToGroundTransportation_element.when_present.click
    page.wait_for_loading_overlay
  end

  on(GroundPage).verify_on_ground_page

  fail "#{ground_vendor} is not the departure chauffeured ground vendor" unless @browser.div(:class => 'ground-order-column ground-order-vehicle').text.include? ground_vendor


end

And(/^I have a arrival chauffeured order$/) do

  @browser.span(:class => 'fancy-select-general-value', :index => 1).wait_until_present

  on_page PassengersPage do |page|

    page.wait_for_loading_overlay
    page.skipToGroundTransportation
    page.wait_for_loading_overlay

  end

  on_page GroundPage do |page|
    page.wait_for_ajax_loader
    page.create_arr_chauffeured_NJ '12 Passenger Van', @lead_passenger
    page.save_chauffeured_order
    page.wait_for_ajax
    page.wait_until{page.ground_leg_elements[0].link_element(:class=>'btn').visible?}
  end

end

And(/^I have a arrival rental order$/) do

  @browser.span(:class => 'fancy-select-general-value', :index => 1).wait_until_present

  on_page PassengersPage do |page|

    page.wait_for_ajax
    page.skipToGroundTransportation
    page.wait_for_ajax

  end

  on_page GroundPage do |page|
    page.wait_for_ajax
    #'XXXXXXXXXXXX1410'
    page.create_arr_rental_credit_card "Mid Size",'none', @lead_passenger
    page.set_rental_return_date 3, @dep_time, @flight_time
    page.save_rental_order
    page.wait_for_ajax
  end


end

Then(/^arrival rental has"([^"]*)" as ground vendor$/) do |ground_vendor|

  on(PassengersPage) do |page|
    #Going to the ground page
    page.wait_for_ajax
    page.wait_for_loading_overlay
    page.skipToGroundTransportation_element.when_present.click
    page.wait_for_ajax
  end

  on(GroundPage).verify_on_ground_page

  fail "#{ground_vendor} is not the rental ground vendor" unless @browser.div(:class => 'ground-order-column ground-order-vehicle').text.include? ground_vendor

end

And(/^I want to add "([^"]*)" to submitted reservation.$/) do |passenger|

  on(GroundPage).wait_for_ajax
  on(ConfirmationPage).verify_on_confirmation_page
  on(ConfirmationPage).viewPrintItinerary
  on(RequestedReservationPage).verify_on_requested_reservation_page

  on(RequestedReservationPage).select_edit_passengers 1

  on(PassengersPage) do |page|

    page.wait_for_ajax
    page.verify_on_passengers_page
    page.set_passenger_name passenger
    page.select_add_to_flight_button
    page.wait_for_ajax
    page.select_save_button
    page.wait_for_ajax
  end

end

And(/^I want to add departure ground order my submitted reservation.$/) do

  on(RequestedReservationPage).verify_on_requested_reservation_page
  on(RequestedReservationPage).select_edit_ground 1
  on_page GroundPage do |page|
    page.wait_for_ajax
    page.create_dep_chauffeured_NJ '12 Passenger Van', @lead_passenger
    page.save_chauffeured_order
    page.wait_for_ajax
    page.wait_until{page.reviewAndRequest_element.visible?}
  end

end

When(/^I want to delete lead passenger "([^"]*)" from reservation$/) do |passenger|


  #Goes back to reservation
  on(GroundPage).reviewAndRequest_element.when_present.click
  on(RequestedReservationPage).select_edit_passengers 1

  on_page PassengersPage do |page|
    page.wait_for_ajax
    page.select_remove_passenger_from_this_flight passenger, 1
    page.wait_for_ajax
    page.select_default_lead_passenger
    page.wait_for_ajax
    page.savePassenger
  end
end

Then(/^departure chauffeured has"([^"]*)" as ground vendor in summary page$/) do |ground_vendor|

  on(RequestedReservationPage) do |page|
      page.verify_on_requested_reservation_page
      msg = page.gather_departure_ground_order
      expect(msg[3]).to eq ground_vendor
  end
end

And(/^I want to add arrival ground order my submitted reservation.$/) do

  on(RequestedReservationPage).verify_on_requested_reservation_page
  on(RequestedReservationPage).select_edit_ground 1
  on_page GroundPage do |page|
    page.wait_for_ajax
    page.create_arr_chauffeured_NJ '12 Passenger Van', @lead_passenger
    page.save_chauffeured_order
    page.wait_for_ajax
    page.wait_until{page.reviewAndRequest_element.visible?}
  end


end

Then(/^arrival ground has "([^"]*)" as ground vendor in summary page$/) do |ground_vendor|

  on(RequestedReservationPage) do |page|
  page.verify_on_requested_reservation_page
  msg = page.gather_arrival_ground_order
  expect(msg[3]).to eq ground_vendor
  end

end

And(/^I want to add rental ground order my submitted reservation.$/) do

  on(RequestedReservationPage).verify_on_requested_reservation_page
  on(RequestedReservationPage).select_edit_ground 1

  on_page GroundPage do |page|
    page.wait_for_ajax_loader
    page.create_arr_rental_credit_card "Mid Size", 'XXXXXXXXXXXX1410', @lead_passenger
    page.set_rental_return_date 3, @dep_time, @flight_time
    page.save_rental_order
    page.wait_for_ajax
    page.wait_until(10){!page.neg_reviewAndRequest_element.visible?}
  end


end


Given(/^A reservation with two passengers,chauffeured and rental orders will credit card billing$/) do

  navigate_to(PassengersPage)

  on(PassengersPage) do |page|
    page.verify_on_passengers_page
    page.set_req_data_for_passenger_manifest ('red_robin_reservation_credit_card')
    page.wait_for_loading_overlay
  end

  on(CateringPage).groundTransportation
  on(CateringPage).wait_for_loading_overlay

  on(GroundPage) do |page|
  page.verify_on_ground_page
  page.create_dep_chauffeured_credit_card '12 Passenger Van','XXXXXXXXXXXX8945','Stuart Brown',1
  page.wait_for_ajax_loader
  page.save_chauffeured_order
  page.wait_for_ajax_loader
  page.create_arr_rental_credit_card 'Mid Size','XXXXXXXXXXXX8945','Stuart Brown',1
  page.wait_for_ajax_loader
  page.save_rental_order
  page.wait_for_ajax_loader
  page.passengers_element.click

  end


end

When(/^I delete the lead passenger$/) do

  on_page PassengersPage do |page|

    page.wait_for_loading_overlay
    page.select_remove_passenger_from_this_flight 'Stuart Brown', 1
    page.wait_for_ajax_loader
    page.select_lead_passenger_list 'James Roy McCarron',1
    page.wait_for_loading_overlay
    page.skipToGroundTransportation
    page.wait_for_loading_overlay
  end

end


Then(/^The chauffeured order changed to bill NJ and rental ground orders get the next lead rider's credit card number$/) do

    on(GroundPage) do |page|

    page.verify_on_ground_page
    page.edit_ground_order
    page.wait_for_ajax_loader
    fail "Bill NJ not checked" unless on(GroundPage).chauffeured_form_element.label_element(:class => 'fancy-check fancy-checked', :text => 'Bill through NetJets').visible?
    page.save_chauffeured_order
    page.wait_for_ajax_loader
    page.edit_ground_order
    page.wait_for_ajax_loader
    fail "Wrong credit card is selected" unless on(GroundPage).rental_form_element.span_element(:class=>'fancy-select-general select-creditcard').text[0..16].strip == 'XXXXXXXXXXXX8634'

    end



end

Then(/^"([^"]*)" is added to the submitted catering order\.$/) do |arg|

  on(RequestedReservationPage) do |page|

  page.verify_on_requested_reservation_page
  page. verify_catering_item_submitted arg

  end

end

When(/^I want to add "([^"]*)" to Ijet2 reservation\.$/) do |passenger|

  on(PassengersPage).wait_for_ajax

  on(PassengersPage).set_passenger_name passenger
  on(PassengersPage).wait_for_ajax
  on(PassengersPage).select_add_to_flight_button
  on(PassengersPage).wait_for_ajax
  on(PassengersPage).savePassenger


end

Given(/^I have a catering order$/) do
   navigate_to(CateringPage)
end

When(/^I change the quantity to "([^"]*)"$/) do |arg|

   on(CateringPage) do |page|
     page.wait_for_loading_overlay
     page.select_add_button
     page.add_catering_item 'Crudites',5
     page.select_save_catering
     page.wait_for_ajax
     page.select_edit_button
     page.change_catering_quantity 'Crudites',51
     page.select_save_catering
   end
end

Then(/^I get a maximum quantity error message$/) do

     sleep 2
     @browser.alert.text.should include '0 limitted by 50'

end

Given(/^I have a passenger with ASI quantity over fifty$/) do
  navigate_to(PassengersPage)

  on(PassengersPage) do |page|
      page.wait_for_ajax
      page.set_passenger_name 'Dennis'
      page.wait_for_ajax_loader
      page.select_add_to_flight_button
      page.wait_for_ajax_loader
      page.savePassenger
      page.wait_for_loading_overlay
      page.wait_for_ajax_loader
   end
end

Then(/^the catering item quantity reduce to (\d+)$/) do |arg|

  on(CateringPage) do |page|
  page.edit_catering_element.visible?
  result = page.gather_ordered_catering_items
  expect(result).to include "#{arg} x Sliced Fruit"
  end

end

Given(/^I want to select departure airport with \- \/$/) do |table|
  navigate_to(FlightsPage)
  on(FlightsPage).verify_on_flights_page
  on(FlightsPage).wait_for_ajax
  table.hashes.each do |items|

  on(FlightsPage).set_departure_airport items['airport']
  end
end

Given(/^I want to select arrival airport with \- \/$/) do |table|
  navigate_to(FlightsPage)
  on(FlightsPage).verify_on_flights_page
  on(FlightsPage).wait_for_ajax
  table.hashes.each do |items|
    on(FlightsPage).set_arrival_airport items['airport']
  end
end

Given(/^as a owner I have a wip reservation$/) do
  navigate_to(CateringPage)
end

When(/^I create another leg earlier departure time than previous$/) do
     on(CateringPage).verify_on_catering_page
     on(HeaderMenu).flights_element.click
     on(FlightsPage) do |page|
       page.wait_for_ajax
       page.verify_on_flights_page
       page.select_add_return_flight_link
       page.wait_for_ajax
       page.select_departure_date_time_link 3
       page.wait_for_ajax
       page.set_flight_date_time 25
       page.select_calendar_save_link
      end
end

Then(/^I get a pops up message\.$/) do
  on(FlightsPage) do  |page|
  expect(page.pop_msg_element.text).to include 'The flight you have added is scheduled to occur earlier than a previous flight'
  end
end

When(/^I create a another leg with earlier arrival time than previous$/) do
  on(CateringPage).verify_on_catering_page
  on(HeaderMenu).flights_element.click
  on(FlightsPage) do |page|
    page.wait_for_ajax
    page.verify_on_flights_page
    page.select_add_return_flight_link
    page.wait_for_ajax
    page.select_arrival_date_time_link 3
    page.wait_for_ajax
    page.set_flight_date_time 25
    page.select_calendar_save_link
  end

end

And(/^I catering item is removed from the catering order$/) do
  on(FlightsPage) do |page|
  page.warning_msg_element.visible?
  page.review_catering
  end
  on(CateringPage) do |page|
  page.verify_on_catering_page
  msg =page.gather_ordered_catering_items
  expect(msg).not_to include 'Sake'
  end
end

And(/^I want to update the departure airport$/) do

  on(RequestedReservationPage) do |page|
    page.verify_on_requested_reservation_page
    page.wait_for_ajax
    page.edit_flight
  end
  on(FlightsPage) do |page|

    page.verify_on_flights_page
    page.wait_for_loading_overlay
    page.wait_for_ajax
    # sleep 2
    page.set_departure_airport(dep_airport='FDY', legNumber=1)
    page.wait_for_ajax_loader
    #Set departure time
    page.select_departure_date_time_link
    page.select_calendar_save_link
    page.wait_until do
    page.addOnwardFlight_element.visible?
    end
    page.save_exit

  end
end

When(/^I am in the catering page$/) do
  on(ConfirmationPage) do |page|
    page.verify_on_confirmation_page
    page.viewPrintItinerary
  end

  on(RequestedReservationPage) do |page|
    page.verify_on_requested_reservation_page
    page.select_edit_catering
  end
end

Then(/^prefer rental ground vendor "([^"]*)" is selected for ground order\.$/) do |pref_vendor|
  on(GroundPage) do |page|
    page.wait_for_ajax_loader
    msg = page.gather_rental_vendor
    expect(msg[0].strip).to eq pref_vendor
  end
end

And(/^I am adding "([^"]*)" as passenger$/) do |passenger|

  on(PassengersPage)do |page|
    page.set_passenger_name passenger
    page.select_add_to_flight_button
    page.wait_for_ajax
  end
end

Given(/^I am login into OP$/) do
  on(LoginPage).login_application_with(:red_robin_account)
end