Given(/^I login into OP$/) do
  on(LoginPage).login_application_with(:adam_blitz_account)
end



Then(/^I submit a reservation to Ijet$/) do
  on(CateringPage).verify_on_catering_page
  continue_navigation_to(ReviewAndRequest)
  on(ReviewAndRequest).select_request_reservation_button
end

Then(/^I add a catering item$/) do
  on(CateringPage).verify_on_catering_page
end

Given(/^I have a wip reservation with return flight$/) do
  on(HomePage).verify_on_home_page
  on(HomePage).bookFlight

  on(FlightsPage) do |page|
    page.set_req_data_for_reservation('reservation_flight_adam_blitz', account_type='NJA')
    page.wait_for_ajax
  end

  on(PassengersPage) do |page|
    page.verify_on_passengers_page
    page.set_req_data_for_passenger_manifest('reservation_flight_adam_blitz')
    end

end