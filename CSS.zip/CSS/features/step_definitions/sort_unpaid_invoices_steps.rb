Given(/^I have multiple unpaid invoices$/) do
  login_as(Login::USERWITHUNPAIDINVOICES)
  on(HomePage).select_account_invoice
end

When(/^I sort (Date) in ascending order$/) do |invoice_data_element|
  on(UnpaidInvoicePage).sort_by(invoice_data_element)
  dates = on(UnpaidInvoicePage).collect_data_for(invoice_data_element)
  dates.collect! do |date|
    Date.parse(date)
  end
  Session[:column_data] = dates
end

When(/^I sort (Contract #|Invoice #|Amount|Due) in ascending order$/) do |invoice_data_element|
  on(UnpaidInvoicePage).sort_by(invoice_data_element)
  numbers = on(UnpaidInvoicePage).collect_data_for(invoice_data_element)
  numbers.collect! do |number|
    # number.delete('$,').to_f
    # number = number.delete('()').reverse.concat('-').reverse if number.include?('(') && number.include?(')')
    Monetize.parse(number).to_f
  end
  Session[:column_data] = numbers
end

When(/^I sort (Invoice Type|Aircraft|Tail #|Status) in ascending order$/) do |invoice_data_element|
  on(UnpaidInvoicePage).sort_by(invoice_data_element)
  Session[:column_data] = on(UnpaidInvoicePage).collect_data_for(invoice_data_element)
end

When(/^I sort (Date) in descending order$/) do |invoice_data_element|
  2.times {on(UnpaidInvoicePage).sort_by(invoice_data_element)}
  dates = on(UnpaidInvoicePage).collect_data_for(invoice_data_element)
  dates.collect! do |date|
    Date.parse(date)
  end
  Session[:column_data] = dates
end

When(/^I sort (Contract #|Invoice #|Amount|Due) in descending order$/) do |invoice_data_element|
  2.times {on(UnpaidInvoicePage).sort_by(invoice_data_element)}
  numbers = on(UnpaidInvoicePage).collect_data_for(invoice_data_element)
  numbers.collect! do |number|
    # number.delete('$,').to_f
    # number.delete('()').reverse.concat('-').reverse if number.include?('(') && number.include?(')')
    Monetize.parse(number).to_f
  end
  Session[:column_data] = numbers
end

When(/^I sort (Invoice Type|Aircraft|Tail #|Status) in descending order$/) do |invoice_data_element|
  2.times {on(UnpaidInvoicePage).sort_by(invoice_data_element)}
  Session[:column_data] = on(UnpaidInvoicePage).collect_data_for(invoice_data_element)
end

Then(/^the invoice data is displayed in ascending order for (.*)$/) do |invoice_data_element|
  pending 'Not enough invoice data available' unless Session[:column_data].count > 1
  expect(Session[:column_data]).to eq Session[:column_data].sort
end

Then(/^the invoice data is displayed in descending order for (.*)$/) do |invoice_data_element|
  pending 'Not enough invoice data available' unless Session[:column_data].count > 1
  expect(Session[:column_data]).to eq Session[:column_data].sort.reverse
end


