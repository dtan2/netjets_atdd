Given(/^my credit memo balance exceeds my amount due$/) do
   @invoices = {old: 0003, older: 0002, oldest: 0001, big: 0001, bigger: 0002, biggest: 0003}
   @credit_memos = {old: 0033, older: 0022, oldest: 0011, big: 0033, bigger: 0022, biggest: 0011}

end

When(/^I apply those credits$/) do
  pay_invoices(invoices)
  @unpaid_invoices = on(PaymentsInvoicesPage).collect_data_for('Invoice #')
  paid_invoice_data = on(PaidInvoicesPage).invoice_numbers_and_amounts
  @invoice_balances = paid_invoice_data.collect {|invoice| invoice[:due]}
  @paid_invoices = paid_invoice_data.collect {|invoice| invoice[:number]}
end

Then(/^the oldest credit will get applied first$/) do
  expect(@payment1[:credit_memos][:oldest].amount).to eq 0
  expect(@payment2[:credit_memos][:oldest].amount).to eq 0
end

And(/^the invoices will get paid in full$/) do
  #TODO: Dustin needs to review this
  all_zeroes = @invoice_balances.collect {0}
  expect(@invoice_balances).to eq all_zeroes
end

Then(/^the remaining credit balance will be (\d+)$/) do
  #TODO: Dustin needs to review this
  exceptions = Array.new
  @credit_memos.each do |credit_memo|
    begin
      expect(@unpaid_invoices).not_to include credit_memo
    rescue Exception => e
      exceptions << e
    end
    begin
      expect(@paid_invoices).not_to include credit_memo
    rescue Exception => e
      exceptions << e
    end
  end
  unless exceptions.empty?
    failure_message = exceptions.collect do |exception|
      exception.message
    end
    fail failure_message
  end
end

Given(/^my credit memo balance is equal to my amount due$/) do
  login_as(Login::USERWITHCREDITMEMOS)
end