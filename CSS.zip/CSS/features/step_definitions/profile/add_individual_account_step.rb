Given(/^I am adding a person to an account$/) do
  on(LoginPage).login_application_with(:red_robin_account)
  on(HomePage).verify_on_home_page
  on(AccountPeoplePage).select_account_people
  on(AccountPeoplePage).wait_for_ajax
  on(AccountPeoplePage).addnew_individual
 end

When(/^I add an individual both first name or last name are require$/) do

  on(AccountPeoplePage) do |page|

  page.wait_for_ajax_loader
  page.confirm

  error_last = "Please fill in the last name"
  error_first = "Please fill in the first name"

  fail "#{error_last} is not in the GUI" unless page.error_msg_element.text.should include error_last
  fail "#{error_first} is not in the GUI" unless page.error_msg_element.text.should include error_first
  min =Time.now.min
  sec = Time.now.sec

  page.people_firstname = "First Name #{min}"
  page.confirm
  fail "#{error_last} is not in the GUI" unless page.error_msg_element.text.should include error_last
  page.people_firstname_element.clear
  page.people_lastname = "Last Name #{sec}"
  page.confirm
  page.wait_for_ajax_loader
  fail "#{error_first} is not in the GUI" unless page.error_msg_element.text.should include error_first

  end


end

Given(/^I am creating a multi-flight reservation$/) do
  navigate_to(PassengersPage)



end

When(/^I add a New person from the passenger page$/) do
  min =Time.now.min
  sec = Time.now.sec
  on(PassengersPage) do |page|
  @new_passenger = page.add_new_passenger_to_account "Nat #{min}#{sec}"
  page.wait_for_loading_overlay
  page.wait_for_ajax_loader

  end



end

Then(/^the newly created person is added to each flight$/) do

  on(PassengersPage) do |page|

   page.validate_passenger_in_list(@new_passenger, leg_number='all')
   end
end

Given(/^I have submitted a multi-flight reservation$/) do
  navigate_to(ReviewAndRequest)
  on(ReviewAndRequest).select_request_reservation_button
  on(ReviewAndRequest).wait_for_ajax_loader
  on(ConfirmationPage).viewPrintItinerary
  on(ConfirmationPage).wait_for_ajax_loader
  on(RequestedReservationPage).verify_on_requested_reservation_page
  on(RequestedReservationPage).edit_passenger
  on(RequestedReservationPage).wait_for_ajax_loader
  end

