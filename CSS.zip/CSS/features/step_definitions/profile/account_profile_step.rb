Given(/^I am on the Account Basic Details page$/) do
  navigate_to(LoginPage)
  on(LoginPage).login_application_with(:red_robin_account)
  on(HomePage).verify_on_home_page
  on(AccountBasicDetailsPage).select_account_basic_details
  on(AccountBasicDetailsPage).verify_in_account_page
end

When(/^I view the Principal "([^"]*)" and account name "([^"]*)"$/) do |principal_name, account_name|

  fail " Principal name #{principal_name} not showing in the basic detail page" unless @browser.div(:class => 'field', :index => 1).text.downcase.include? principal_name.downcase

  fail "Account name #{account_name}not showing in the basic detail page" unless @browser.div(:class => 'field', :index => 0).text.downcase.include? account_name.downcase

end
When(/^I view "([^"]*)" is "([^"]*)"$/) do |acc_role, nj_name|


  fail "#{acc_role} is not showing in the basic detail page" unless @browser.div(:class => 'preview-mode clear', :index => 0).text.downcase.include? acc_role.downcase

  fail "#{nj_name} is not showing in the basic detail page" unless @browser.div(:class => 'preview-mode clear', :index => 0).text.downcase.include? nj_name.downcase


end
When(/^I also view "([^"]*)" is "([^"]*)"$/) do |acc_role, nj_name|

  fail "#{acc_role} is not showing in the basic detail page" unless @browser.div(:class => 'preview-mode clear', :index => 1).text.downcase.include? acc_role.downcase

  fail "#{nj_name} is not showing in the basic detail page" unless @browser.div(:class => 'preview-mode clear', :index => 1).text.downcase.include? nj_name.downcase

end

#When(/^The address listed under the header matches the following from IJ2$/) do
#
#   on(AccountBasicDetailsPage).account_address
#   on(AccountBasicDetailsPage).verify_account_address
#
#end

Then(/^The address listed under the header matches the following from IJ2$/) do |table|

  table.hashes.each do |items|

    on(AccountBasicDetailsPage).compare_account_address items['Type_Addresses']

  end

end

When(/^I add my Emergency contact$/) do |table|

  on(AccountBasicDetailsPage).emergency_contact
  on(AccountBasicDetailsPage).verify_text_exists 'In case of emergency'

  table.hashes.each do |items|
    on(AccountBasicDetailsPage).wait_for_loading_overlay
    on(AccountBasicDetailsPage).add_new
    on(AccountBasicDetailsPage).contact_name = items['name']
    on(AccountBasicDetailsPage).contact_country_code = items['country_code']
    on(AccountBasicDetailsPage).contact_area_code = items['area_code']
    on(AccountBasicDetailsPage).contact_tel_num = items['tel_number']
    on(AccountBasicDetailsPage).contact_ext = items['ext']

    #set the type
    on(AccountBasicDetailsPage).wait_for_loading_overlay
    on(AccountBasicDetailsPage).select_emergency_type items['type']


    @name = items['name']
    @tel = items['country_code'] +"."+ items['area_code']+"."+items['tel_number']+"."+items['ext']

    on(AccountBasicDetailsPage) do |page|
      page.wait_for_loading_overlay
      page.save_elements[1].click
      page.wait_for_loading_overlay
      entered_data = page.emergency_data_element.text.split("\n")

      expect(entered_data[1]).to eq @name
      expect(entered_data[5]).to eq @tel
    end
  end

end

Then(/^my emergency contact is added$/) do

  on(AccountBasicDetailsPage).wait_for_loading_overlay

  entered_data = @browser.div(:class => 'preview-mode clear', :index => 5).text.split("\n")


  fail "Name is not #{@name}" unless entered_data.include? @name
  fail "Tel is not #{@tel}" unless entered_data.include? @tel


end
When(/^I edit an Emergency Contact$/) do

  on(AccountBasicDetailsPage).emergency_contact

  if on(AccountBasicDetailsPage).edit_element.visible?

    on(AccountBasicDetailsPage) do |page|

      page.verify_text_exists 'In case of emergency'
      page.wait_for_ajax_loader
      page.edit
    end
  else

    fail "No emergency contact to be edited"
  end
end
Then(/^The following fields has been edited$/) do |table|

  if @browser.link(:class => 'btn btn2 delete', :text => 'Delete').exist?


    on(AccountBasicDetailsPage) do |page|
      page.contact_name.clear
      page.contact_country_code.clear
      page.contact_area_code.clear
      page.contact_tel_num.clear
      page.contact_ext.clear
      page.wait_for_ajax_loader
    end

    table.hashes.each do |items|

      on(AccountBasicDetailsPage).contact_name = items['name']
      on(AccountBasicDetailsPage).contact_country_code = items['country_code']
      on(AccountBasicDetailsPage).contact_area_code = items['area_code']
      on(AccountBasicDetailsPage).contact_tel_num = items['tel_number']
      on(AccountBasicDetailsPage).contact_ext = items['ext']

      on(AccountBasicDetailsPage).select_emergency_type items['type']


      @name = items['name']
      @tel = items['country_code'] +"."+ items['area_code']+"."+items['tel_number']+"."+items['ext']

    end


    on(AccountBasicDetailsPage).save_element.when_present.click
    on(AccountBasicDetailsPage).wait_for_loading_overlay
    on(AccountBasicDetailsPage).wait_for_ajax_loader

    entered_data = @browser.div(:class => 'preview-mode clear', :index => 5).text.split("\n").map { |x| x.strip }


    fail "Name is not #{@name}" unless entered_data.include? @name
    fail "Tel is not #{@tel}" unless entered_data.include? @tel

  else

    fail "There is no existing emergency contact to be edited"

  end


end

When(/^I delete an Emergency Contact$/) do

  on(AccountBasicDetailsPage).emergency_contact
  on(AccountBasicDetailsPage).verify_text_exists 'In case of emergency'

  if on(AccountBasicDetailsPage).contact_delete_element.visible?

    count = @browser.spans(:text => 'Delete').count

    for i in 0..count-1

      on(AccountBasicDetailsPage) do |page|
        page.wait_for_ajax_loader
        page.contact_delete
        page.wait_for_ajax_loader
        page.delete_continue

      end
    end

  else

    fail "No Emergency Contact exist"

  end
end

Then(/^My deleted contact is no longer present$/) do

  on(AccountBasicDetailsPage).wait_for_ajax_loader

  if on(AccountBasicDetailsPage).contact_delete_element.visible?


    fail "Emergency contact was not deleted"

  end


end
Then(/^I want to change the emergency type$/) do |table|

  on(AccountBasicDetailsPage).wait_for_ajax_loader
  table.hashes.each do |items|

    on(AccountBasicDetailsPage) do |page|
      page.wait_for_ajax
      page.select_emergency_type items['type']
      page.save_element.when_present.click
      page.wait_for_ajax
      emergency_type = page.gather_emergency_type
      expect(emergency_type).to eq items['type']
      page.wait_for_ajax
      page.edit_element.when_present.click
    end
  end
end

Given(/^I am viewing the Aircraft & Balance screen$/) do

  navigate_to(HomePage)
  on(HomePage).verify_on_home_page
  on(AccountBasicDetailsPage).select_aircraft_balance
  on(AccountBasicDetailsPage).wait_for_ajax_loader

end

When(/^I want  to view the Account Addresses$/) do

  on(AccountBasicDetailsPage).account_address

  on(AccountBasicDetailsPage).verify_text_exists 'To change account billing preferences'
end

Given(/^I am viewing the wip passenger page$/) do

  navigate_to(PassengersPage)

end


Then(/^The individual is added to the Account People page$/) do

  on(PassengersPage).select_account_people
  on(AccountPeoplePage) do |page|
    page.wait_for_ajax
    page.search = @new_passenger
    page.wait_for_ajax
    data = page.gather_search_result
    expect(data).to eq @new_passenger

  end

end

When(/^I am adding "([^"]*)" a new passenger$/) do |new_passenger|

  new_passenger = new_passenger + "#{Time.now.min}"

  on(PassengersPage) do |page|

    page.verify_on_passengers_page
    @new_passenger = page.add_new_passenger_to_account new_passenger
    page.wait_for_loading_overlay
    page.wait_for_ajax_loader

  end
end

Given(/^I am viewing the submitted passenger page$/) do

  navigate_to(ReviewAndRequest)
  on(ReviewAndRequest).select_request_reservation_button
  on(ReviewAndRequest).wait_for_ajax_loader
  on(ConfirmationPage).viewPrintItinerary
  on(ConfirmationPage).wait_for_ajax_loader
  on(RequestedReservationPage).verify_on_requested_reservation_page
  on(RequestedReservationPage).edit_passenger
  on(RequestedReservationPage).wait_for_ajax_loader


end

When(/^I am adding a new passenger$/) do

  on(PassengersPage) do |page|

    page.verify_on_passengers_page
    page.new_person


  end

end

Then(/^First and last names are required$/) do

  on(PassengersPage).Confirm

  error_last = "Please fill in the last name"
  error_first = "Please fill in the first name"

  fail "#{error_last} is not in the GUI" unless on(PassengersPage).error_msg_element.text.should include error_last
  fail "#{error_first} is not in the GUI" unless on(PassengersPage).error_msg_element.text.should include error_first

  on(PassengersPage) do |page|

    page.first_name = "First Name"
    page.Confirm
    fail "#{error_last} is not in the GUI" unless page.error_msg_element.text.should include error_last
    page.first_name_element.clear
    page.last_name = "Last Name"
    page.Confirm
    page.wait_for_ajax_loader
    fail "#{error_first} is not in the GUI" unless page.error_msg_element.text.should include error_first

  end

end


Then(/^birth date and manifest name are optional$/) do
  min =Time.now.min
  sec = Time.now.sec
  on(PassengersPage) do |page|
    page.wait_for_ajax_loader
    first_name = "Kim #{min}"
    last_name = "Lee #{sec}"

    page.first_name = first_name
    page.last_name = last_name
    page.Confirm
    page.wait_for_ajax_loader
    fail "#{first_name} #{last_name} not in the GUI" unless page.passenger_list_element.text.should include "#{first_name} #{last_name}"

  end


end

When(/^I am viewing contract "([^"]*)" in the Owner Portal$/) do |contract_num, table|

  @index = on(AccountBasicDetailsPage).select_contract contract_num

  table.hashes.each do |items|

    # fail "#{items['data']} is not in the GUI" unless @browser.div(:class => 'contract-details clear', :index => @index).text.include? items['data']
  end

end

When(/^I am adding a duplicate passenger$/) do

  on(PassengersPage) do |page|

    page.verify_on_passengers_page
    page.new_person
    page.wait_for_ajax_loader
    first_name = "Smith"
    last_name = "Lee9"

    page.first_name = first_name
    page.last_name = last_name
    page.Confirm
    page.wait_for_ajax_loader

  end


end

Then(/^error message stating duplication$/) do


  fail "Duplicate passenger message is not in the GUI" unless on(PassengersPage).duplicate_error_element.text.should include "Duplicate passenger"

end

Given(/^I am on the People screen$/) do

  navigate_to(LoginPage)
  on(LoginPage).login_application_with(:red_robin_account)
  on(AccountPeoplePage).select_account_people
end


When(/^I am logged in as an individual with fly permissions$/) do
  navigate_to(LoginPage)
  on(LoginPage).login_application_with(:red_robin_account_fly)

end

Then(/^I am unable to view the Account screen link$/) do

  fail "Flyer able to access the account page" unless on(AccountBasicDetailsPage).account_element.visible?.should == false


end

And(/^I am unable to open the Account pages$/) do

  url = @browser.url

  account_url ="#{url}/Account/BasicDetails"

  @browser.goto account_url

  fail "Flyer able to access the account page" unless on(AccountBasicDetailsPage).account_element.visible?.should == false


end

Given(/^I am viewing an account with multiple principals$/) do
  navigate_to(LoginPage)
  on(LoginPage).login_application_with(:user_with_single_account)
end

When(/^I view the Account screen$/) do
  on(AccountBasicDetailsPage).select_account_basic_details
end

Then(/^Spaces exist between commas separating the principal names.$/) do
  fail "No comma between the principal's name" unless on(AccountBasicDetailsPage).principals_element.text.include? 'g,'
end

Given(/^I am at the profile phone number page$/) do
  on(ProfilePage) do |page|
    page.select_personal_details
    page.phoneNumbers
  end

end

When(/^I select (.*) the state or region of birth showing$/) do |country_of_birth|
  on(ProfilePage) do |page|
    page.basic_international
    page.wait_for_ajax_loader
    page.edit_international_elements[0].click
    page.wait_for_ajax_loader
    page.set_country_birth country_of_birth
  end
end

Then(/^the (.*) shown$/) do |state_of_birth|

  on(ProfilePage) do |page|
    state = page.passport_state_elements[1].text
    expect(state).to eq state_of_birth
    page.save_elements[4].click
    page.wait_for_ajax_loader
  end
end


When(/^I have two primary emails$/) do

  on(ProfilePage) do |page|

    @pre_count = page.count_primary_email
    page.basic_email
    page.wait_for_ajax_loader
    page.addnew_elements[1].click
    page.wait_for_ajax_loader
    page.set_email
    page.check_primary_email
    page.save_elements[2].click
  end
end

Then(/^only one email is designated as primary$/) do
  post_count = on(ProfilePage).count_primary_email
  expect(@pre_count).to eq post_count
end

When(/^I unassign a primary email$/) do
  on(ProfilePage) do |page|
    page.basic_email
    page.wait_for_ajax_loader
    page.select_primary_email
    page.wait_for_ajax_loader
  end
end

Then(/^the email remain the primary$/) do

  on(ProfilePage) do |page|
    page.check_primary_email
    expect(page.checked_primary_email_element).to exist
  end
end


When(/^I creating a passport record$/) do

  on(ProfilePage) do |page|
    page.basic_passport
    page.wait_for_ajax_loader
    page.addnew_elements[3].click
    page.wait_for_ajax_loader
    page.save_elements[5].click
    page.wait_for_ajax_loader
    error_msg = page.gather_error_message
    expect(error_msg[10]).to eq 'Please enter your last name'
    expect(error_msg[9]).to eq 'Please enter your first name'
    expect(error_msg[3]).to eq 'Issued Day must be between 1 and 31'
    expect(error_msg[4]).to eq 'Issued Month must be between 1 and 12'
    expect(error_msg[5]).to eq 'Issued Year must be greater than 1800'
    expect(error_msg[6]).to eq 'Expiration Day must be between 1 and 31'
    expect(error_msg[7]).to eq 'Expiration Month must be between 1 and 12'
    expect(error_msg[8]).to eq 'Expiration Year must be greater than 1800'
    expect(error_msg[2]).to eq 'Please enter a passport number'
  end


end

Then(/^the following fields are require$/) do |table|

  table.hashes.each do |data|

    case data['require_fields']

      when 'last_name'
        on(ProfilePage) do |page|
          page.passport_lastname = 'Smith'
          page.save_elements[5].click
          page.wait_for_ajax_loader
          error_msg = page.gather_error_message
          expect(error_msg).not_to include 'Please enter your last name'
        end
      when 'first_name'
        on(ProfilePage) do |page|
          page.passport_firstname = 'Smith'
          page.save_elements[5].click
          error_msg = page.gather_error_message
          expect(error_msg).not_to include 'Please enter your first name'
        end
      when 'issued_date'
        on(ProfilePage) do |page|
          page.issue_month = '7'
          page.issue_day = '4'
          page.issue_year = '2010'
          page.save_elements[5].click
          error_msg = page.gather_error_message
          expect(error_msg).not_to include 'Issued Day must be between 1 and 31'
          expect(error_msg).not_to include 'Issued Month must be between 1 and 12'
          expect(error_msg).not_to include 'Issued Year must be greater than 1800'
          page.wait_for_ajax_loader
        end

      when 'expire_date'
        on(ProfilePage) do |page|
          page.exp_month = '12'
          page.exp_day = '31'
          page.exp_year = '2014'
          page.save_elements[5].click
          error_msg = page.gather_error_message
          expect(error_msg).not_to include 'Expiration Day must be between 1 and 31'
          expect(error_msg).not_to include 'Expiration Month must be between 1 and 12'
          expect(error_msg).not_to include 'Expiration Year must be greater than 1800'
        end

      when 'passport_number'
        on(ProfilePage) do |page|
          page.passport_lastname = ' '
          page.passport_num = 'A834739747'
          page.save_elements[5].click
          error_msg = page.gather_error_message
          expect(error_msg).not_to include 'Please enter a passport number'
        end

      else
        nil

    end
  end
end

When(/^I creating a visa record$/) do

  on(ProfilePage) do |page|
    page.basic_passport
    page.wait_for_ajax_loader
    page.addnew_elements[3].click
    page.wait_for_ajax_loader
    page.set_passport
    page.save_elements[5].click
    page.wait_for_loading_overlay
    page.wait_for_ajax_loader
    page.add_visa
    page.wait_for_ajax_loader
    page.save_elements[6].click
    page.wait_for_ajax_loader
    error_msg = page.gather_error_message
    expect(error_msg[5]).to eq 'Issue Day must be between 1 and 31'
    expect(error_msg[6]).to eq 'Issue Month must be between 1 and 12'
    expect(error_msg[7]).to eq 'Issue Year must be greater than 1800'
    expect(error_msg[2]).to eq 'Expiration Day must be between 1 and 31'
    expect(error_msg[3]).to eq 'Expiration Month must be between 1 and 12'
    expect(error_msg[4]).to eq 'Expiration Year must be greater than 1800'
    expect(error_msg[8]).to eq 'The Visa number must be provided'

  end
end

Then(/^the these fields are require$/) do |table|

  table.hashes.each do |data|

    case data['require_fields']

      when 'visa_number'
        on(ProfilePage) do |page|
          page.visa_num = 'A4553475'
          page.save_elements[6].click
          error_msg = page.gather_error_message
          expect(error_msg).not_to include 'The Visa number must be provided'
        end

      when 'issued_date'
        on(ProfilePage) do |page|
          page.visa_issue_month = '7'
          page.visa_issue_day = '4'
          page.visa_issue_year = '2010'
          page.save_elements[6].click
          error_msg = page.gather_error_message
          expect(error_msg).not_to include 'Issue Day must be between 1 and 31'
          expect(error_msg).not_to include 'Issue Month must be between 1 and 12'
          expect(error_msg).not_to include 'Issue Year must be greater than 1800'
          page.wait_for_ajax_loader
        end

      when 'expire_date'
        on(ProfilePage) do |page|
          page.visa_num = ' '
          page.visa_exp_month = '12'
          page.visa_exp_day = '31'
          page.visa_exp_year = '2014'
          page.save_elements[6].click
          error_msg = page.gather_error_message
          expect(error_msg).not_to include 'Expiration Day must be between 1 and 31'
          expect(error_msg).not_to include 'Expiration Month must be between 1 and 12'
          expect(error_msg).not_to include 'Expiration Year must be greater than 1800'
        end

      else
        nil

    end
  end
end

Given(/^I am viewing the People screen$/) do
  navigate_to(LoginPage)
  on(LoginPage).login_application_with(:juma_account)
  on(AccountPeoplePage).select_account_people

end

When(/^I search for an individual that is deceased$/) do

  on(AccountPeoplePage).people_search 'Mohammed Juma'
  # @browser.send_keys :enter
  on(AccountPeoplePage).wait_for_ajax
end

And(/^The deceased individual is not returned$/) do
  search_result = on(AccountPeoplePage).gather_search_error_msg
  expect(search_result).to eq 'No results found'

end

And(/^I search for an individual that is inactive$/) do
  on(AccountPeoplePage).people_search 'Justin Thomas'

  # @browser.send_keys :enter
  on(AccountPeoplePage).wait_for_ajax

end

Then(/^The inactive individual is not returned$/) do
  search_result = on(AccountPeoplePage).gather_search_error_msg
  expect(search_result).to eq 'No results found'
end

When(/^as a booker I want to edit my basic information$/) do

  on(AccountPeoplePage) do |page|
    page.select_personal_details
    page.edit_elements[0].click
    @name, @manifest_name, @gender, @date = page.set_basic_information
    page.save_elements[0].click
    page.wait_for_loading_overlay
    page.wait_for_ajax_loader

  end

end

Then(/^my basic information is changed$/) do
  on(AccountPeoplePage) do |page|
    page.edit_elements[0].when_visible
    info = page.info_elements[0].text.split(/\n/)
    expect(info[1]).to eq @name
    expect(info[3]).to eq @manifest_name
    expect(info[7]).to eq @gender
    expect(info[5]).to eq @date
  end
end

When(/^as a booker I want to edit my phone number$/) do

  on(AccountPeoplePage) do |page|
    page.select_personal_details
    page.basic_phone
    page.wait_for_ajax_loader
    if page.save_elements[1].visible? == true
      page.set_phone_number
      page.save_elements[1].click
      page.wait_for_loading_overlay
    end
    page.wait_for_ajax_loader
    page.edit_phone_elements[0].click
    @phone_type, @phone_num = page.set_phone_number
    page.save_elements[1].click
  end
end

Then(/^my phone number has changed$/) do
  on(AccountPeoplePage) do |page|
    page.edit_phone_elements[0].when_visible
    phone_info = page.phone_data_elements[0].text.split(/\n/)
    expect(phone_info[1]).to eq @phone_type
    expect(phone_info[3]).to eq @phone_num
  end
end

When(/^as a booker I want to edit email address$/) do
  step 'as a booker I want to add a profile email address'
  on(ProfilePage) do |page|
    page.basic_email
    page.wait_for_ajax_loader
    page.edit_email_elements[0].click
    page.wait_for_ajax_loader
    @email_type, @email = page.set_email
    page.save_elements[2].click
    page.wait_for_ajax_loader
  end
end

Then(/^my email address has been changed$/) do

  on(ProfilePage) do |page|
    page.edit_email_elements[0].when_visible
    email_info = page.email_data_elements[1].text.split(/\n/)
    expect(email_info[1]).to eq @email_type
    expect(email_info[3]).to eq @email
  end
end

When(/^as a booker I want to edit my mailing address$/) do

  on(ProfilePage) do |page|
    page.select_personal_details
    page.basic_address
    page.wait_for_ajax_loader
    if page.save_elements[3].visible? == true
      page.set_address
      page.save_elements[3].click
      page.wait_for_loading_overlay
    end
    page.wait_for_ajax_loader
    page.edit_address_elements[0].click
    page.wait_for_ajax_loader
    @address_type, @address = page.set_address
    page.save_elements[3].click
    page.wait_for_ajax_loader
  end
end

Then(/^my mailing address has been changed$/) do

  on(ProfilePage) do |page|
    page.edit_address_elements[0].when_visible
    address_info = page.address_data_elements[0].text.split(/\n/)
    expect(address_info[1]).to eq @address_type
    expect(address_info[3]).to eq @address

  end
end

When(/^as a booker I want to edit my international information$/) do
  on(ProfilePage) do |page|
    page.select_personal_details
    page.basic_international
    page.wait_for_ajax_loader
    page.edit_international_elements[0].click
    page.wait_for_ajax_loader
    @country, @state, @city, @citizenship, @residence = page.set_international
    page.save_elements[4].click
    page.wait_for_ajax_loader
    page.wait_for_loading_overlay
  end
end

Then(/^my international information has been changed$/) do

  on(ProfilePage) do |page|
    page.edit_international_elements[0].when_visible
    international_info = page.international_data_elements[0].text.split(/\n/)
    expect(international_info[1]).to eq @country
    expect(international_info[3]).to eq @state
    expect(international_info[5]).to eq @city
    expect(international_info[7]).to eq @citizenship
    expect(international_info[9]).to eq @residence
  end
end

When(/^as a booker I want to edit my passport & visa$/) do
  # step 'as a booker I want to add passport & visa'
  on(ProfilePage) do |page|
    page.select_personal_details
    page.basic_passport
    page.wait_for_ajax_loader
    if page.save_elements[5].visible? == true
      page.set_passport
      page.save_elements[5].click
      page.wait_for_loading_overlay
      page.wait_for_ajax_loader
      page.add_visa
      page.wait_for_ajax_loader
      page.set_visa
      page.save_elements[6].click
      page.wait_for_ajax_loader
      page.wait_for_loading_overlay
    end
    page.wait_for_ajax_loader
    page.edit_passport_elements[0].click
    page.wait_for_ajax_loader
    @country_issue, @name, @expiration_date, @passport_num, @primary_checked, @missing_checked = page.set_passport
    page.save_elements[5].click
    page.wait_for_ajax_loader
    page.wait_for_loading_overlay
    page.edit_visa_elements[0].click
    page.wait_for_ajax_loader
    @issue_country, @visa_type, @issued_date, @expiration_date, @visa_num = page.set_visa
    page.save_elements[6].click
    page.wait_for_ajax_loader
    page.wait_for_loading_overlay

  end
end

Then(/^my passport and visa have changed$/) do
  on(ProfilePage) do |page|
    page.edit_passport_elements[0].when_visible
    passport_info = page.passport_data_elements[0].text.split(/\n/)
    expect(passport_info[1]).to eq @country_issue[0, 3].upcase
    expect(passport_info[3]).to eq @name
    # expect(passport_info[5]).to include expiration_date
    expect(passport_info[7]).to eq @passport_num

    page.wait_for_ajax_loader

    if @primary_checked == true

      expect(passport_info[11]).to eq 'Yes'
    end

    if @missing_checked == true

      expect(passport_info[9]).to eq "This passport is missing"
    end
    visa_info = page.gather_visa_info
    expect(visa_info[1]).to eq @issue_country[0, 3].upcase
    expect(visa_info[3]).to eq @visa_type
    expect(visa_info[5]).to eq "#{@issued_date} - #{@expiration_date}"
    expect(visa_info[7]).to eq @visa_num
  end

end

Given(/^as a booker I want to add a profile phone number$/) do
  on(ProfilePage) do |page|
    page.select_personal_details
    page.basic_phone
    page.wait_for_ajax_loader
    page.addnew_elements[0].click
    @phone_type, @phone_num = page.set_phone_number
    page.save_elements[1].click
    page.wait_for_ajax_loader

  end
end

Then(/^the profile phone number is added$/) do
  on(ProfilePage) do |page|
    page.edit_phone_elements[0].when_visible
    phone_info = page.gather_phone_info
    expect(phone_info[1]).to eq @phone_type
    expect(phone_info[3]).to eq @phone_num
  end
end


Given(/^as a booker I want to add a profile email address$/) do
  on(ProfilePage) do |page|
    page.select_personal_details
    page.basic_email
    page.wait_for_ajax_loader
    page.addnew_elements[1].click
    page.wait_for_ajax_loader
    @email_type, @email = page.set_email
    page.save_elements[2].click
    page.wait_for_ajax_loader

  end
end

Then(/^the profile email address is added$/) do
  on(ProfilePage) do |page|
    page.edit_email_elements[0].when_visible
    email_info = page.gather_email_info
    expect(email_info[1]).to eq @email_type
    expect(email_info[3]).to eq @email
  end
end

Given(/^as a booker I want to add profile mailing address$/) do
  on(ProfilePage) do |page|
    page.select_personal_details
    page.basic_address
    page.wait_for_ajax_loader
    page.addnew_elements[2].click
    page.wait_for_ajax_loader
    @address_type, @address = page.set_address
    page.save_elements[3].click
    page.wait_for_ajax_loader
    page.wait_for_loading_overlay

  end
end

Then(/^the profile mailing address is added$/) do
  on(ProfilePage) do |page|
    page.edit_address_elements[0].when_visible
    mailing_info = page.gather_mailing_info
    expect(mailing_info[1]).to eq @address_type
    expect(mailing_info[3]).to eq @address
  end
end

Given(/^as a booker I want to add passport & visa$/) do
  on(ProfilePage) do |page|
    page.select_personal_details
    page.basic_passport
    page.wait_for_ajax_loader
    page.addnew_elements[3].click
    page.wait_for_ajax_loader
    @country_issue, @name, @issued_date, @passport_num, @primary_checked, @missing_checked = page.set_passport
    page.save_elements[5].click
    page.wait_for_ajax_loader
    page.wait_for_loading_overlay
    page.edit_passport_elements[0].when_visible
    page.add_visa
    page.wait_for_ajax_loader
    @issue_country, @visa_type, @visa_issued_date, @visa_expiration_date, @visa_num = page.set_visa
    page.save_elements[6].click
    page.wait_for_ajax_loader
    page.wait_for_loading_overlay

  end
end

Then(/^the profile passport & visa are added$/) do
  on(ProfilePage) do |page|
    passport_info = page.gather_passport_info
    expect(passport_info[1]).to eq @country_issue[0, 3].upcase
    expect(passport_info[3]).to eq @name
    expect(passport_info[5]).to eq @issued_date
    expect(passport_info[7]).to eq @passport_num

    if @primary_checked == true
      expect(passport_info[11]).to eq 'Yes'
    end

    if @missing_checked == true
      expect(passport_info[9]).to eq "This passport is missing"
    end
    @browser.refresh
    page.basic_passport
    visa_info = page.gather_visa_info
    expect(visa_info[1]).to eq @issue_country[0, 3].upcase
    expect(visa_info[3]).to eq @visa_type
    expect(visa_info[5]).to eq "#{@visa_issued_date} #{@visa_expiration_date}"
    expect(visa_info[7]).to eq @visa_num

  end


end

Given(/^I am at the profile basic information page$/) do
  on(ProfilePage).select_personal_details
end

When(/^as a booker I want to delete profile phone number$/) do
  step 'as a booker I want to add a profile phone number'
  on(AccountPeoplePage) do |page|
    page.wait_for_ajax_loader
    page.basic_phone
    page.wait_for_ajax_loader
    @count = page.delete_phone_elements.size
    page.delete_phone_elements[0].click
    page.continue_element.click
    page.wait_for_ajax_loader
  end

end

Then(/^the profile phone number is deleted$/) do
  next_count = on(ProfilePage).delete_phone_elements.size
  expect(@count-1).to eq next_count
end

When(/^as a booker I want to delete email address$/) do
  step 'as a booker I want to add a profile email address'
  on(AccountPeoplePage) do |page|
    page.basic_email
    page.wait_for_ajax_loader
    @count = page.delete_email_elements.size
    page.wait_for_ajax_loader
    page.delete_email_elements[0].click
    page.wait_for_ajax_loader
    page.continue_element.click
    page.wait_for_ajax_loader
    page.wait_for_loading_overlay
  end


end

Then(/^the profile email address is deleted$/) do
  next_count = on(ProfilePage).delete_email_elements.size
  expect(@count-1).to eq next_count
end

When(/^as a booker I want to delete profile mailing address$/) do
  step 'as a booker I want to add profile mailing address'
  on(AccountPeoplePage) do |page|
    page.basic_address
    page.wait_for_ajax_loader
    @count = page.delete_address_elements.size
    page.wait_for_ajax_loader
    page.delete_address_elements[0].click
    page.wait_for_ajax_loader
    page.continue_element.click
    page.wait_for_ajax_loader
    page.wait_for_loading_overlay
  end
end

Then(/^the profile mailing address is deleted$/) do
  next_count = on(ProfilePage).delete_address_elements.size
  sleep 1
  expect(@count-1).to eq next_count

end

When(/^as a booker I want to delete profile passport & visa$/) do
  step 'as a booker I want to add passport & visa'
  on(AccountPeoplePage) do |page|
    page.basic_passport
    page.wait_for_ajax_loader
    @count = page.delete_passport_elements.size
    @visa_count = page.delete_visa_elements.size
    page.wait_for_loading_overlay
    page.wait_for_ajax_loader
    page.delete_visa_elements[0].when_present.click
    page.wait_for_ajax_loader
    page.continue_element.click
    page.delete_passport_elements[0].when_present.click
    page.wait_for_ajax_loader
    page.continue_element.click
    page.wait_for_loading_overlay
    page.wait_for_ajax_loader
  end
end

Then(/^the profile passport & visa is deleted$/) do
  next_count = on(ProfilePage).delete_passport_elements.size
  next_visa_count = on(ProfilePage).delete_visa_elements.size
  sleep 3
  expect(@count-1).to eq next_count
  expect(@visa_count-1).to eq next_visa_count
end

Given(/^I have another person profile open$/) do
  navigate_to(LoginPage)
  on(LoginPage).login_application_with(:red_robin_account)
  on(AccountPeoplePage).select_account_people
  on(AccountPeoplePage) do |page|
    page.people_search 'Chris Allen'
    page.wait_for_ajax
    page.editBasic_alt_element.when_present.click
    page.edit_elements[0].when_visible
    page.wait_for_ajax_loader
  end
end

When(/^as a booker I want to edit another people's basic information$/) do
  on(AccountPeoplePage) do |page|
    page.edit_elements[0].click
    @name, @manifest_name, @gender, @date = page.set_basic_information
    page.save_elements[0].click
    page.wait_for_loading_overlay
    page.wait_for_ajax_loader

  end
end

Then(/^another people's basic information is changed$/) do
  on(AccountPeoplePage) do |page|
    page.edit_elements[0].visible?
    info = page.info_elements[0].text.split(/\n/)
    expect(info[3]).to eq @manifest_name
    expect(info[7]).to eq @gender
    expect(info[5]).to eq @date
  end
end

When(/^as a booker I want to edit another people's phone number$/) do
  step 'as a booker I want to add another person phone number'
  on(AccountPeoplePage) do |page|
    page.basic_phone
    page.wait_for_ajax_loader
    page.edit_elements[1].click
    @phone_type, @phone_num = page.set_phone_number
    page.save_elements[1].click
    page.wait_for_ajax_loader

  end
end

Then(/^another people's phone number is changed$/) do
  on(AccountPeoplePage) do |page|
    page.edit_elements[1].when_visible
    phone_info = page.gather_phone_info
    expect(phone_info[1]).to eq @phone_type
    expect(phone_info[3]).to eq @phone_num
  end

end

When(/^as a booker I want to edit another people's email address$/) do

  step 'as a booker I want to add another person email address'
  on(AccountPeoplePage) do |page|
    page.basic_email
    page.wait_for_ajax_loader
    page.edit_email_elements[0].click
    page.wait_for_ajax_loader
    @email_type, @email = page.set_email
    page.save_elements[2].click
    page.wait_for_ajax_loader

  end
end

Then(/^another people's email address is changed$/) do
  on(AccountPeoplePage) do |page|
    page.edit_email_elements[0].when_visible
    email_info = page.gather_email_info
    expect(email_info[1]).to eq @email_type
    expect(email_info[3]).to eq @email
  end

end

When(/^as a booker I want to edit another people's mailing address$/) do
  step 'as a booker I want to add another person mailing address'
  on(AccountPeoplePage) do |page|
    page.wait_for_ajax
    page.basic_address
    page.wait_for_ajax_loader
    page.edit_address_elements[0].click
    page.wait_for_ajax_loader
    @address_type, @address = page.set_address
    page.save_elements[3].click
    page.wait_for_ajax_loader
    page.wait_for_loading_overlay
  end

end

Then(/^another people's mailing address is changed$/) do
  on(AccountPeoplePage) do |page|
    page.edit_address_elements[0].when_visible
    mailing_info = page.gather_mailing_info
    expect(mailing_info[1]).to eq @address_type
    expect(mailing_info[3]).to eq @address
  end
end

When(/^as a booker I want to edit another people's international information$/) do

  on(AccountPeoplePage) do |page|
    page.basic_international
    page.wait_for_ajax_loader
    page.edit_international_elements[0].click
    page.wait_for_ajax_loader
    @country, @state, @city, @citizenship, @residence = page.set_international
    page.save_elements[4].click
    page.wait_for_ajax
    end
end

Then(/^another people's international information is changed$/) do
  on(AccountPeoplePage) do |page|
    page.edit_international_elements[0].when_visible
    @browser.refresh
    page.basic_international
    international_info = page.international_data_elements[0].text.split(/\n/)
    expect(international_info[1]).to eq @country
    expect(international_info[3]).to eq @state
    expect(international_info[5]).to eq @city
    expect(international_info[7]).to eq @citizenship
    expect(international_info[9]).to eq @residence
  end

end

When(/^as a booker I want to edit another people's passport & visa$/) do

  step 'as a booker I want to add another person passport & visa'
  on(ProfilePage) do |page|
    page.basic_passport
    page.wait_for_ajax_loader
    page.edit_passport_elements[0].click
    page.wait_for_ajax_loader
    @country_issue, @name, @expiration_date, @passport_num, @primary_checked, @missing_checked = page.set_passport
    page.save_elements[5].click
    page.wait_for_ajax_loader
    page.wait_for_loading_overlay
    page.edit_visa_elements[0].click
    page.wait_for_ajax_loader
    @issue_country, @visa_type, @issued_date, @expiration_date, @visa_num = page.set_visa
    page.save_elements[6].click
    page.wait_for_ajax_loader
    page.wait_for_loading_overlay
  end
end

Then(/^another people's passport & visa is changed$/) do
  on(ProfilePage) do |page|
    page.edit_passport_elements[0].when_visible
    passport_info = page.gather_passport_info
    expect(passport_info[1]).to eq @country_issue[0, 3].upcase
    expect(passport_info[3]).to eq @name
    # expect(passport_info[5]).to include expiration_date
    expect(passport_info[7]).to eq @passport_num

    page.wait_for_ajax_loader

    if @primary_checked == true

      expect(passport_info[11]).to eq 'Yes'
    end

    if @missing_checked == true

      expect(passport_info[9]).to eq "This passport is missing"
    end
    @browser.refresh
    page.basic_passport
    visa_info = page.gather_visa_info
    expect(visa_info[1]).to eq @issue_country[0, 3].upcase
    expect(visa_info[3]).to eq @visa_type
    expect(visa_info[5]).to eq "#{@issued_date} #{@expiration_date}"
    expect(visa_info[7]).to eq @visa_num
  end
end

When(/^as a booker I want to add another person phone number$/) do
  on(ProfilePage) do |page|
    page.basic_phone
    page.wait_for_ajax_loader
    page.addnew_elements[0].click
    @phone_type, @phone_num = page.set_phone_number
    page.save_elements[1].click
    page.wait_for_ajax_loader

  end
end

Then(/^another person phone number is added$/) do
  on(ProfilePage) do |page|
    page.edit_phone_elements[0].when_visible
    phone_info = page.gather_phone_info
    expect(phone_info[1]).to eq @phone_type
    expect(phone_info[3]).to eq @phone_num
  end
end

When(/^as a booker I want to add another person email address$/) do
  on(ProfilePage) do |page|
    # page.select_personal_details
    page.basic_email
    page.wait_for_ajax_loader
    page.addnew_elements[1].click
    page.wait_for_ajax_loader
    @email_type, @email = page.set_email
    page.save_elements[2].click
    page.wait_for_ajax_loader
  end
end

Then(/^another person phone email address is added$/) do
  on(ProfilePage) do |page|
    page.edit_email_elements[0].when_visible
    email_info = page.gather_email_info
    expect(email_info[1]).to eq @email_type
    expect(email_info[3]).to eq @email
  end
end

When(/^as a booker I want to add another person mailing address$/) do

  on(ProfilePage) do |page|
    # page.select_personal_details
    page.basic_address
    page.wait_for_ajax_loader
    page.addnew_elements[2].click
    page.wait_for_ajax_loader
    @address_type, @address = page.set_address
    page.save_elements[3].click
    page.wait_for_ajax_loader
    page.wait_for_loading_overlay

  end
end

Then(/^another person phone mailing address is added$/) do
  on(ProfilePage) do |page|
    page.edit_address_elements[0].when_visible
    mailing_info = page.gather_mailing_info
    expect(mailing_info[1]).to eq @address_type
    expect(mailing_info[3]).to eq @address
  end
end

When(/^as a booker I want to add another person passport & visa$/) do

  on(ProfilePage) do |page|
    page.select_personal_details
    page.basic_passport
    page.wait_for_ajax_loader
    page.addnew_elements[3].click
    page.wait_for_ajax_loader
    @country_issue, @name, @date_issued, @passport_num, @primary_checked, @missing_checked = page.set_passport
    page.save_elements[5].click
    page.wait_for_ajax
    page.wait_until do
      page.edit_passport_elements[0].visible?
    end
    sleep 1
    page.add_visa
    page.wait_for_ajax_loader
    @issue_country, @visa_type, @issued_date, @expiration_date, @visa_num = page.set_visa
    page.save_elements[6].click
    page.wait_for_ajax
  end

end

Then(/^another person passport & visa is added$/) do
  on(ProfilePage) do |page|
    passport_info = page.gather_passport_info
    expect(passport_info[1]).to eq @country_issue[0, 3].upcase
    expect(passport_info[3]).to eq @name
    expect(passport_info[5]).to eq @date_issued
    expect(passport_info[7]).to eq @passport_num

    if @primary_checked == true
      expect(passport_info[11]).to eq 'Yes'
    end

    if @missing_checked == true
      expect(passport_info[9]).to eq "This passport is missing"
    end
    @browser.refresh
    page.basic_passport
    visa_info = page.gather_visa_info
    expect(visa_info[1]).to eq @issue_country[0, 3].upcase
    expect(visa_info[3]).to eq @visa_type
    expect(visa_info[5]).to eq "#{@issued_date} #{@expiration_date}"
    expect(visa_info[7]).to eq @visa_num

  end
end

When(/^as a booker I want to delete other person phone number$/) do
  step 'as a booker I want to add another person phone number'
  on(AccountPeoplePage) do |page|
    page.wait_for_ajax_loader
    page.basic_phone
    page.wait_for_ajax_loader
    @count = page.delete_phone_elements.size
    page.delete_phone_elements[0].click
    page.continue_element.click
    page.wait_for_ajax_loader
  end
end


Then(/^another person phone number is deleted$/) do
  next_count = on(ProfilePage).delete_phone_elements.size
  expect(@count-1).to eq next_count
end

When(/^as a booker I want to delete other person email address$/) do
  step 'When as a booker I want to add another person email address'
  on(AccountPeoplePage) do |page|
    page.basic_email
    page.wait_for_ajax_loader
    @count = page.delete_email_elements.size
    page.wait_for_ajax_loader
    page.delete_email_elements[0].click
    page.wait_for_ajax_loader
    page.continue_element.click
    page.wait_for_ajax_loader
    page.wait_for_loading_overlay
  end
end

Then(/^another person email address is deleted$/) do
  next_count = on(ProfilePage).delete_email_elements.size
  expect(@count-1).to eq next_count
end

When(/^as a booker I want to delete other person mailing address$/) do
  step 'as a booker I want to add another person mailing address'
  on(AccountPeoplePage) do |page|
    page.basic_address
    page.wait_for_ajax_loader
    @count = page.delete_address_elements.size
    page.wait_for_ajax_loader
    page.delete_address_elements[0].click
    page.wait_for_ajax_loader
    page.continue_element.click
    page.wait_for_ajax_loader
    page.wait_for_loading_overlay
  end
end

Then(/^another person mailing address is deleted$/) do
  next_count = on(ProfilePage).delete_address_elements.size
  sleep 1
  expect(@count-1).to eq next_count

end

When(/^as a booker I want to delete other person passport & visa$/) do
  step 'as a booker I want to add another person passport & visa'
  on(AccountPeoplePage) do |page|
    page.basic_passport
    page.wait_for_ajax_loader
    @count = page.delete_passport_elements.size
    @visa_count = page.delete_visa_elements.size
    page.wait_for_loading_overlay
    page.wait_for_ajax_loader
    page.delete_visa_elements[0].when_present.click
    page.wait_for_ajax_loader
    page.continue_element.click
    page.delete_passport_elements[0].when_present.click
    page.wait_for_ajax_loader
    page.continue_element.click
    page.wait_for_loading_overlay
    page.wait_for_ajax_loader
  end
end

Then(/^another person passport & visa is deleted$/) do
  next_count = on(ProfilePage).delete_passport_elements.size
  next_visa_count = on(ProfilePage).delete_visa_elements.size
  on(ProfilePage).wait_for_ajax
  expect(@count-1).to eq next_count
  expect(@visa_count-1).to eq next_visa_count
end

Given(/^I have a submitted international trip$/) do
  navigate_to(FlightsPage)

  on(FlightsPage) do |page|
    page.set_req_data_for_reservation 'red_robin_international'
    page.wait_for_ajax
  end
  on(PassengersPage) do |page|
    page.verify_on_passengers_page
    page.set_req_data_for_passenger_manifest 'red_robin_international'
    page.wait_for_ajax
  end

  on(CateringPage) do |page|
    page.verify_on_catering_page
    page.skipToReviewAndRequest
  end

  on(ReviewAndRequest) do |page|
    page.verify_on_review_and_request_page
    page.requestReservation
  end
end

When(/^I want to edit my passport & visa$/) do
  on(ConfirmationPage) do |page|
    page.verify_on_confirmation_page
    page.select_account_people
    page.wait_for_ajax
  end
  on(AccountPeoplePage) do |page|
    page.wait_for_loading
    page.verify_in_people_page
    page.select_edit_passport
  end


end

Then(/^I was not able to$/) do
  on(ProfilePage) do |page|
    expect(page.edit_passport_elements.present?).to equal false
  end

end