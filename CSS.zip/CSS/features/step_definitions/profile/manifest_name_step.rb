Given(/^I am in my profile page$/) do
  navigate_to(LoginPage)
  on(LoginPage).login_application_with(:red_robin_account)
  on(HeaderMenu).select_personal_details
  on(ProfilePage).verify_on_profile_page
end

When(/^I want to add my manifest name "([^"]*)"$/) do |manifest_name|


  on(ProfilePage).set_manifest_name manifest_name

end

Then(/^It should display  "([^"]*)" in my manifest name$/) do |manifest_name|

  on(ProfilePage).wait_for_loading_overlay

  on(ProfilePage).wait_for_ajax_loader

  fail "#{manifest_name} not added to the manifest name field" unless @browser.div(:class => 'preview-mode clear').text.include? manifest_name

end

Given(/^I am in the account page.$/) do
  navigate_to(LoginPage)
  on(LoginPage).login_application_with(:red_robin_account)
  on(HomePage).wait_for_ajax
  on(HeaderMenu).select_account_basic_details
end

And(/^I want to edit "([^"]*)" manifest name$/) do |manifest_name|

  on(AccountBasicDetailsPage).verify_in_account_page
  on(AccountBasicDetailsPage).wait_for_ajax

  on(AccountPeoplePage) do |page|
    page.select_account_people
    page.verify_in_people_page
    page.people_search manifest_name
    page.wait_for_ajax
    page.search_result_element.when_present.click
    page.verify_in_people_page
    page.wait_for_ajax
    page.select_edit_basic_information
  end


end

Given(/^I am in the passenger page.$/) do

  navigate_to(PassengersPage)

end

When(/^I enter the passenger name$/) do |table|

  on(PassengersPage).wait_for_ajax

  table.hashes.each do |items|

    on(PassengersPage).set_passenger_name items['passenger']

    on(PassengersPage).wait_for_ajax
    #Verify the search research

    @browser.div(:class => 'predictive-results', :index => 0).wait_until_present

    name = []

    on(PassengersPage).wait_for_ajax_loader

    @browser.div(:class => 'predictive-results').lis.each do |name_temp|

      name << name_temp.text

      name_found = false
    end

    if name.map { |x| x.downcase }.include? items['result'].downcase

      name_found = true

    end


    if name_found == false

      fail "#{items['result']} not found in the search result "

    end

  end
end

When(/^I want to add "([^"]*)" as lead passenger$/) do |manifest_name|

    on(PassengersPage) do |page|
    page.set_passenger_name manifest_name
    page.select_add_to_flight_button

  end

end

Then(/^verify manifest name "([^"]*)" is in the passenger list$/) do |manifest_name|

  fail "#{manifest_name} not in passenger list" unless @browser.ul(:class => 'passenger-list').text.include? manifest_name

end

And(/^verify manifest name "Mickey Mouse (\d+) \(lead passenger\)" in the summary review page.$/) do |manifest_name|
  on(PassengersPage) do |page|
    page.wait_for_loading_overlay
    page.skipToReviewAndRequest
    page.wait_for_loading_overlay
  end
  on(ReviewAndRequest).verify_on_review_and_request_page
  fail "#{arg} manifest name is not in the summary page " unless @browser.div(:class => 'details', :index => 3).text.include? manifest_name


end

When(/^I am at the catering dietary page$/) do

  on(PassengersPage) do |page|
    page.wait_for_loading_overlay
    page.nextCatering
    page.wait_for_loading_overlay
  end

  on(CateringPage) do |page|
    page.verify_on_catering_page
    page.wait_for_ajax
    page.select_add_button
    page.wait_for_ajax
    page.dietary_element.when_present.click
  end

end


Then(/^verify manifest name "([^"]*)" is in the dietary page$/) do |manifest_name|

      on(CateringPage) do |page|
      dietary_info = page.gather_passenger_dietary_restrictions
      expect(dietary_info[0]).to eq manifest_name
      end
end

When(/^I am in the ground order page.$/) do

  on(PassengersPage) do |page|
    page.wait_for_loading_overlay
    page.skipToGroundTransportation
    page.wait_for_loading_overlay
  end


end


Then(/^verify departure chauffeured lead rider is "([^"]*)"$/) do |manifest_name|

  on(GroundPage) do |page|
    page.add_dep_chauffeured
    page.wait_for_ajax_loader
    lead_rider = page.gather_chauffeured_lead_rider
    expect(lead_rider).to eq manifest_name
  end
end

And(/^I want to verify "([^"]*)" is in the vendor drop down.$/) do |manifest_name|

  on(GroundPage) do |page|
  vendor = page.gather_rental_vendor
  expect(vendor[1]).to include manifest_name
  end

end

Then(/^verify arrival chauffeured lead rider is "([^"]*)"$/) do |manifest_name|

  on(GroundPage) do |page|
    page.add_arr_chauffeured
    page.wait_for_ajax_loader
    lead_rider = page.gather_chauffeured_lead_rider
    expect(lead_rider).to eq manifest_name
  end


end

Then(/^verify arrival rental lead rider is "([^"]*)"$/) do |manifest_name|

  on(GroundPage) do |page|
    page.add_arr_rental
    page.wait_for_ajax_loader
    lead_rider = page.gather_rental_lead_rider
    expect(lead_rider).to eq manifest_name
  end


end