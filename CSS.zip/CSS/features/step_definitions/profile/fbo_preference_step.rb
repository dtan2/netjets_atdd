Given(/^I am in the OP home page$/) do
  navigate_to(HomePage)
  on(HomePage).verify_on_home_page
end

Given(/^I have a rental order$/) do
  steps %{Given I am at the profile preference page
    When I add a LNK FBO preference with Always use}

  navigate_to(PassengersPage)
  on(PassengersPage) do |page|
      page.verify_on_passengers_page
      page.set_passenger_name 'John Rowe'
      page.select_add_to_flight_button
      page.wait_for_loading_overlay
      page.skipToGroundTransportation
      page.wait_for_loading_overlay
  end
    on(GroundPage) do |page|
    page.verify_on_ground_page
    page.add_arr_rental 1
    page.set_rental_vehicle
    page.save_rental_order
    page.wait_for_ajax_loader
  end
end

Then(/^the drop off is at the FBO\.$/) do

  on(GroundPage).reviewAndRequest
  on(ReviewAndRequest).verify_on_review_and_request_page
  rental_fbo = on(ReviewAndRequest).gather_rental_dropoff_FBO
  arr_fbo = on(ReviewAndRequest).gather_arrival_airport_FBO
  rental_fbo.should include 'Silverhawk Aviation'
  arr_fbo.should include 'Silverhawk Aviation'
end

Given(/^I am at the profile preference page$/) do

  on(ProfilePage) do |page|
    page.select_personal_preference
  end

end

And(/^I select a FBO$/) do
  on(ProfilePage) do |page|
    page.select_fbo 'Lane Aviation'
  end
end


Given(/^I have a wip reservation with known fbo preference$/) do

  steps %{Given I am at the profile preference page
    When I add a LNK FBO preference with Always use}

  navigate_to(PassengersPage)
  on(PassengersPage) do |page|
    page.verify_on_passengers_page
    page.set_passenger_name 'John Rowe'
    page.select_add_to_flight_button
    page.wait_for_loading_overlay
    page.skipToGroundTransportation
    page.wait_for_loading_overlay
  end

  on(GroundPage) do |page|
    page.verify_on_ground_page
    page.add_arr_rental 1
    page.set_rental_vehicle
    page.save_rental_order
    page.wait_for_ajax_loader
    page.reviewAndRequest
  end
  on(ReviewAndRequest).verify_on_review_and_request_page
  rental_fbo = on(ReviewAndRequest).gather_rental_dropoff_FBO
  arr_fbo = on(ReviewAndRequest).gather_arrival_airport_FBO
  rental_fbo.should include 'Silverhawk Aviation'
  arr_fbo.should include 'Silverhawk Aviation'
end

When(/^I change a lead passenger$/) do
  on(HeaderMenu).select_passenger
  on(PassengersPage) do |page|
  page.verify_on_passengers_page
  page.set_passenger_name 'Alysa Levine'
  page.select_add_to_flight_button
  page.validate_passenger_in_list 'Alysa Levine'
  page. select_lead_passenger_list 'Alysa Levine'
  page.wait_for_loading_overlay
  page.skipToReviewAndRequest
  page.wait_for_loading_overlay
  end
  on(ReviewAndRequest).verify_on_review_and_request_page
end

Then(/^the rental drop off fbo is netjets prefer$/) do
  rental_fbo = on(ReviewAndRequest).gather_rental_dropoff_FBO
  arr_fbo = on(ReviewAndRequest).gather_arrival_airport_FBO
  rental_fbo.should include 'Duncan Aviation'
  arr_fbo.should include 'Duncan Aviation'
end

Given(/^I have a submitted reservation with known fbo preference$/) do
  navigate_to(PassengersPage)
  on(PassengersPage) do |page|
    page.verify_on_passengers_page
    page.set_passenger_name 'John Rowe'
    page.select_add_to_flight_button
    page.wait_for_loading_overlay
    page.skipToReviewAndRequest
    page.wait_for_loading_overlay
  end
  on(ReviewAndRequest).verify_on_review_and_request_page
  on(ReviewAndRequest).requestReservation
  on(ConfirmationPage).verify_on_confirmation_page
  on(ConfirmationPage).viewPrintItinerary
  on(RequestedReservationPage).verify_on_requested_reservation_page
  on(RequestedReservationPage).edit_ground

  on(GroundPage) do |page|
    page.verify_on_ground_page
    page.add_arr_rental 1
    page.set_rental_vehicle
    page.save_rental_order
    page.wait_for_ajax_loader
    page.reviewAndRequest
  end
  on(RequestedReservationPage).verify_on_requested_reservation_page
  rental_fbo = on(RequestedReservationPage).gather_rental_dropoff_FBO
  arr_fbo = on(RequestedReservationPage).gather_arrival_airport_FBO
  rental_fbo.should include 'Silverhawk Aviation'
  arr_fbo.should include 'Silverhawk Aviation'
 end

When(/^I change a lead passenger for submitted reservation$/) do
  on(RequestedReservationPage).verify_on_requested_reservation_page
  on(RequestedReservationPage).edit_passenger
  on(RequestedReservationPage).wait_for_loading_overlay

  on(PassengersPage) do |page|
  page.set_passenger_name 'Alysa Levine'
  page.select_add_to_flight_button
  page.validate_passenger_in_list 'Alysa Levine'
  page. select_lead_passenger_list 'Alysa Levine'
  page.wait_for_loading_overlay
  page.savePassenger
  page.wait_for_loading_overlay
  end
end

Given(/^I am at the account preference page$/) do
   on(AccountBasicDetailsPage).select_account_preference
   on(AccountBasicDetailsPage).wait_for_ajax_loader
end

Given(/^I have another rental order$/) do

  steps %{ Given I am at the account preference page
    When I add an account LNK FBO preference with Always use}

  navigate_to(PassengersPage)
  on(PassengersPage) do |page|
    page.verify_on_passengers_page
    page.set_passenger_name 'Chris Allen'
    page.select_add_to_flight_button
    page.wait_for_ajax
    page.skipToGroundTransportation
    page.wait_for_ajax
  end
  on(GroundPage) do |page|
    page.verify_on_ground_page
    page.add_arr_rental 1
    page.set_rental_vehicle
    page.save_rental_order
    page.wait_for_ajax_loader
  end
end

Given(/^the booker has a FBO preference of "([^"]*)"$/) do |arg|

  on(ProfilePage) do |page|
    page.select_personal_preference
    page.delete_all_fbo_preference
    page.wait_for_ajax_loader
    page.add_new_element.click
    page.wait_for_ajax_loader
    page.select_airport 'CMH'
    page.wait_for_ajax_loader
    page.select_fbo arg
    page.biSave
    page.wait_for_loading_overlay
    page.fbo_preference_elements[1].span_elements[0].text.should include 'COLUMBUS'
    page.fbo_preference_elements[1].span_elements[1].text.should include arg
  end



end

Then(/^the rental drop off is at "([^"]*)"$/) do |arg|

  navigate_to(FlightsPage)
  on(FlightsPage).set_req_data_for_reservation('red_robin_reservation_credit_card')

  on(PassengersPage) do |page|
    page.verify_on_passengers_page
    page.set_passenger_name 'John Rowe'
    page.select_add_to_flight_button
    page.wait_for_ajax_loader
    page.validate_passenger_in_list 'John Rowe'
    page. select_lead_passenger_list 'John Rowe'
    page.wait_for_loading_overlay
    page.skipToGroundTransportation
    page.wait_for_loading_overlay
  end

  on(GroundPage) do |page|
    page.verify_on_ground_page
    page.add_arr_rental 1
    page.set_rental_vehicle
    page.save_rental_order
    page.wait_for_ajax_loader
    end
  on(GroundPage).reviewAndRequest
  on(ReviewAndRequest).verify_on_review_and_request_page
  rental_fbo = on(ReviewAndRequest).gather_rental_dropoff_FBO
  arr_fbo = on(ReviewAndRequest).gather_arrival_airport_FBO
  expect(rental_fbo).to eq arg
  arr_fbo.should include arg
 end

When(/^I add a LNK FBO preference with Always use$/) do
  on(ProfilePage).add_fbo_preference 'LNK','Always use','Silverhawk Aviation'
  on(ProfilePage).select_bi_save_button
end

Then(/^LNK FBO pereference is added$/) do

  on(ProfilePage) do |page|
    pref = page.fbo_preference
    pref.usage.should == 'Always use'
    pref.airport.should ==  'LINCOLN'
    pref.fbo.should == 'Silverhawk Aviation'
  end

end

When(/^I add a YYZ FBO preference with Never use$/) do
  on(ProfilePage).add_fbo_preference 'YYZ','Never use','Skycharter Limited'
  on(ProfilePage).select_bi_save_button
end

Then(/^YYZ FBO pereference is added$/) do
  on(ProfilePage) do |page|
    pref = page.fbo_preference
    pref.usage.should == 'Never use'
    pref.airport.should == 'TORONTO/PEARSON INTL'
    pref.fbo.should ==  'Skycharter Limited'
  end


end

When(/^I edit the YYZ FBO preference$/) do
   on(ProfilePage) do |page|
      page.add_fbo_preference 'YYZ','Never use','Skycharter Limited'
      page.select_bi_save_button
     @index = page.edit_fbo_preference('TORONTO','CMH','Never use','Landmark Aviation')
     page.select_bi_save_button
   end



end

Then(/^the YYZ FBO preference is edited$/) do

    on(ProfilePage) do |page|
      pref = page.fbo_preference @index
      pref.usage.should == 'Never use'
      pref.airport.should == 'CMH (Columbus, OH), Port Columbus Intl'
      pref.fbo.should ==  'Landmark Aviation'
    end

end

When(/^I add an account LNK FBO preference with Always use$/) do
  on(AccountPeoplePage).add_fbo_preference 'LNK','Always use','Silverhawk Aviation'
  on(AccountPeoplePage).select_bi_save_button
 end

When(/^I add an account YYZ FBO preference with Never use$/) do
  on(AccountPeoplePage).add_fbo_preference 'YYZ','Never use','Skycharter Limited'
  on(AccountPeoplePage).select_bi_save_button
end

When(/^I edit the account YYZ fbo$/) do

  step 'I add an account YYZ FBO preference with Never use'
  on(AccountPeoplePage) do |page|
    @index = page.edit_fbo_preference('TORONTO','CMH','Never use','Landmark Aviation')
    page.select_bi_save_button
  end
end

Then(/^I want to delete all profile fbo preference$/) do

  on(ProfilePage) do |page|
    page.select_personal_preference
    page.delete_all_fbo_preference

  end


end

Then(/^I want to delete all account fbo preference$/) do
  on(ProfilePage) do |page|
    page.select_account_preference
    page.delete_all_fbo_preference

  end
end


And(/^the account has FBO preference of "([^"]*)"$/) do |arg|
  step 'I am at the account preference page'
  on(AccountPeoplePage).add_fbo_preference 'CMH','Always use','Landmark'
  on(AccountPeoplePage).select_bi_save_button

end