When(/^NJA owner scheduling a flight depart to a NJE zone$/) do
  Session[:dep_airport] ='EGLC'

  navigate_to(LoginPage)
  on(LoginPage).login_application_with(:red_robin_account)
  on(HomePage).bookFlight
  on(HomePage).wait_for_ajax
  #Enter the departure,arrival page and select air_craft
  on(FlightsPage) do |page|
  page.enter_departure_airport Session[:dep_airport]
  end

end

When(/^NJA owner scheduling a flight arrival to a NJE zone$/) do
  Session[:arr_airport] ='EGLC'

  navigate_to(LoginPage)
  on(LoginPage).login_application_with(:red_robin_account)
  on(HomePage).bookFlight
  on(HomePage).wait_for_ajax
  #Enter the departure,arrival page and select air_craft
  on(FlightsPage) do |page|
    page.enter_arrival_airport Session[:arr_airport]
    page.wait_for_ajax
    end
end

Then(/^no departure NJE zone airport can be found$/) do
  on(FlightsPage) do |page|
    airport = page.gather_drop_down_departure_airport
    expect(airport[0]).to eq 'No airports found.'
  end
end

Then(/^no arrival NJE zone airport can be found$/) do
  on(FlightsPage) do |page|
    airport = page.gather_drop_down_arrival_airport
    expect(airport[0]).to eq 'No airports found.'
  end
end

When(/^NJE owner scheduling a flight depart to a NJA zone$/) do
  Session[:dep_airport] ='CMH'

  navigate_to(LoginPage)
  on(LoginPage).login_application_with(:juma_account)
  on(HomePage).bookFlight
  on(HomePage).wait_for_ajax
  #Enter the departure,arrival page and select air_craft
  on(FlightsPage) do |page|

    page.enter_departure_airport Session[:dep_airport]
  end


end

Then(/^no departure NJA zone airport can be found$/) do

  on(FlightsPage) do |page|
    airport = page.gather_drop_down_departure_airport
    expect(airport[0]).to eq 'No airports found.'
  end
end

When(/^NJE owner scheduling a flight arrival to a NJA zone$/) do
  Session[:dep_airport] ='CMH'

  navigate_to(LoginPage)
  on(LoginPage).login_application_with(:juma_account)
  on(HomePage).bookFlight
  on(HomePage).wait_for_ajax
  #Enter the departure,arrival page and select air_craft
  on(FlightsPage) do |page|
   page.enter_arrival_airport Session[:dep_airport]
  end
end

Then(/^no arrival NJA zone airport can be found$/) do
  on(FlightsPage) do |page|
    airport = page.gather_drop_down_arrival_airport
    expect(airport[0]).to eq 'No airports found.'
  end
end

When(/^the NJA owner book a flight (\d+) hours before departure$/) do |dephr|
  
  navigate_to(FlightsPage)

  on(FlightsPage) do |page|
  page.set_departure_airport 'CMH', 1
  page.set_arrival_airport 'MIA',1
  page.select_aircraft_type('Global 5000 Signature')
  page.select_departure_date_time_link(legNumber=1)
  page.wait_for_ajax
  page.set_flight_date_time dephr
  page.select_calendar_save_link
  page.wait_for_ajax
  page.addPassengers_element.when_present.click
  page.wait_for_ajax
  end
end

Then(/^owner not able to book a flight (\d+) hours prior to departure$/) do |arg|

   msg = on(FlightsPage).error_msg_element.text
   expect(msg).to include "Flights requested through Owner Portal must be booked at least #{arg} hours in advance"
end

When(/^the NJA edit a submitted flight to (\d+) hours before departure$/) do |dephr|
   navigate_to(ReviewAndRequest)
   on(ReviewAndRequest)do |page|
   page.select_request_reservation_button
   end

    on(ConfirmationPage) do |page|
    page.verify_on_confirmation_page
    page.select_view_print_itinerary_button
    end
    on(RequestedReservationPage) do |page|
    page.verify_on_requested_reservation_page
    page.select_edit_flight
    page.wait_for_ajax
    end

    on(FlightsPage) do |page|
    page.verify_on_flights_page
    page.select_existing_departure_date_time_link
    page.set_flight_date_time dephr
    page.select_calendar_save_link
    page.wait_for_ajax
    page.save_exit
    page.wait_for_ajax
    end

end

When(/^the NJA owner book a Hawaii flight (\d+) hours before departure$/) do |dephr|

  navigate_to(FlightsPage)
 #Need to offset the departure time by 5 hrs for Hawaiian time zone.(-10 hr from GMT)
 #Calculate offset from EST
  act_dephr = dephr.to_i - 10-(-5)

  on(FlightsPage) do |page|
    page.verify_on_flights_page
    page.wait_for_ajax
    page.select_aircraft_type('Global 5000 Signature')
    page.wait_for_ajax
    page.set_departure_airport 'MIA', 1
    page.wait_for_ajax
    page.set_arrival_airport 'HNL',1
    page.select_departure_date_time_link(legNumber=1)
    page.wait_for_ajax
    page.set_flight_date_time act_dephr.to_s
    page.select_calendar_save_link
    page.wait_for_ajax
    page.addPassengers_element.when_present.click
    page.wait_for_ajax
  end
end


When(/^the NJA owner book a Alaska flight (\d+) hours before departure$/) do |dephr|
  navigate_to(FlightsPage)
  #Need to offset the departure time by 4 hrs for Alaska time zone.(-9 hr from GMT)
  act_dephr = dephr.to_i - 4

  on(FlightsPage) do |page|
    page.verify_on_flights_page
    page.wait_for_ajax
    page.select_aircraft_type('Global 5000 Signature')
    page.wait_for_ajax
    page.set_departure_airport 'ANC', 1
    page.wait_for_ajax
    page.set_arrival_airport 'MIA',1
    page.select_departure_date_time_link(legNumber=1)
    page.wait_for_ajax
    page.set_flight_date_time act_dephr.to_s
    page.select_calendar_save_link
    page.wait_for_ajax
    page.addPassengers_element.when_present.click
    page.wait_for_ajax
  end
end

When(/^NJA owner book a flight depart from (.*) (.*) (\d+) hours before departure$/) do |airport, off_set_from_utc, dephr|
  navigate_to(FlightsPage)
  #Need to offset the departure time by 4 hrs for Alaska time zone.(-9 hr from GMT)
  act_dephr = dephr.to_i+(off_set_from_utc.to_f)+5

  on(FlightsPage) do |page|
    page.verify_on_flights_page
    page.wait_for_ajax
    page.select_aircraft_type('CITATION ENCORE')
    page.wait_for_ajax
    page.set_departure_airport airport, 1
    page.wait_for_ajax
    page.set_arrival_airport 'MIA',1
    page.select_departure_date_time_link(legNumber=1)
    page.wait_for_ajax
    page.set_flight_date_time act_dephr.to_s
    page.select_calendar_save_link
    page.wait_for_ajax
    page.addPassengers_element.when_present.click
    page.wait_for_ajax
  end
end

When(/^NJA edit a submitted flight depart from (.*) (.*) (\d+) hours before departure$/) do |airport, off_set_from_utc, dephr|

  navigate_to(ReviewAndRequest)
  on(ReviewAndRequest)do |page|
    page.select_request_reservation_button
  end

  on(ConfirmationPage) do |page|
    page.verify_on_confirmation_page
    page.select_view_print_itinerary_button
  end
  on(RequestedReservationPage) do |page|
    page.verify_on_requested_reservation_page
    page.select_edit_flight
    page.wait_for_ajax
  end
  act_dephr = dephr.to_i+(off_set_from_utc.to_f)+5

  on(FlightsPage) do |page|
    page.verify_on_flights_page
    page.set_departure_airport airport
    page.select_departure_date_time_link
    page.set_flight_date_time act_dephr
    page.select_calendar_save_link
    page.save_exit_element.when_present.click
    # page.wait_for_ajax
  end
end

Then(/^owner see an error messages about (\d+) hours prior to departure$/) do |arg|
  on(FlightsPage).wait_for_ajax
  msg = on(FlightsPage).error_msg_element.text
  expect(msg).to include "Flights requested through Owner Portal must be booked at least #{arg} hours in advance"
end

Then(/^owner see an error messages about (\d+) days prior to departure$/) do |arg|
  msg = on(FlightsPage).error_msg_element.when_visible.text
  expect(msg).to include "Flights requested through Owner Portal must be booked at least 48 hours (2 days) in advance"
end


When(/^Owner scheduled a peak period day within (\d+) hours prior to departure$/) do |dephr|
  navigate_to(FlightsPage)

  on(FlightsPage) do |page|
    page.verify_on_flights_page
    page.wait_for_ajax
    page.select_aircraft_type('CITATION ENCORE')
    page.wait_for_ajax
    page.set_departure_airport 'CMH', 1
    page.wait_for_ajax
    page.set_arrival_airport 'MIA',1
    page.select_departure_date_time_link(legNumber=1)
    page.wait_for_ajax
    page.set_flight_date_time '36'
    page.select_calendar_save_link
    page.wait_for_ajax
    page.addPassengers_element.when_present.click
    page.wait_for_ajax
  end
end

Then(/^owner see an error messages about (\d+) days before departure$/) do |arg|
  msg = on(FlightsPage).error_msg_element.text
  expect(msg).to include "Flights requested through Owner Portal must be booked at least 120 hours (5 days) in advance"
end

When(/^owner scheduled a flight within (\d+) hours$/) do |dephr|
  Session[:dep_airport] = 'LCY'
  Session[:arr_airport] = 'VIE'
  navigate_to(LoginPage)
  on(LoginPage).login_application_with(:juma_account)
  on(HomePage).bookFlight
  #Enter the departure,arrival page and select air_craft
  on(FlightsPage) do |page|
    page.set_departure_airport(Session[:dep_airport], legNumber=1)
    page.set_arrival_airport(Session[:arr_airport], legNumber=1)
    page.select_aircraft_type('FALCON 2000')
    page.select_departure_date_time_link(legNumber=1)
    page.wait_for_ajax
    # page.set_departure_time_from_now(dephr, leg_number=1, "NJE")
    page.set_flight_date_time dephr,'NJE'
    page.select_calendar_save_link
    page.wait_for_ajax
    page.addPassengers
  end


end

When(/^NJA edit a submitted reservation to depart on a peak period day prior to (\d+) hours$/) do |dephr|

  navigate_to(ReviewAndRequest)
  on(ReviewAndRequest)do |page|
    page.select_request_reservation_button
  end

  on(ConfirmationPage) do |page|
    page.verify_on_confirmation_page
    page.select_view_print_itinerary_button
  end
  on(RequestedReservationPage) do |page|
    page.verify_on_requested_reservation_page
    page.select_edit_flight
    page.wait_for_ajax
  end

  on(FlightsPage) do |page|
    page.verify_on_flights_page
    page.select_departure_date_time_link
    page.set_flight_date_time '24'
    page.select_calendar_save_link
    page.save_exit_element.when_present.click
    page.wait_for_ajax
  end
end

When(/^NJA owner entering a prohibited airport for departure$/) do
  Session[:dep_airport] ='MMX'

  navigate_to(LoginPage)
  on(LoginPage).login_application_with(:red_robin_account)
  on(HomePage).bookFlight
  on(HomePage).wait_for_ajax
  #Enter the departure,arrival page and select air_craft
  on(FlightsPage) do |page|
    page.select_aircraft_type 'CITATION ENCORE'
    page.wait_for_ajax
    page.upgrade_aircraft_type 'CITATION EXCEL/XLS'
    page.enter_departure_airport Session[:dep_airport]
    page.wait_for_ajax
  end
end

Then(/^NJA owner was inform the departure airport is not suitable$/) do
  on(FlightsPage) do |page|
    airport = page.gather_drop_down_departure_airport
    expect(airport[0]).to include 'Not suitable for CITATION EXCEL'
  end
end

When(/^NJA owner entering a prohibited airport for arrival$/) do
  Session[:arr_airport] ='MMX'

  navigate_to(LoginPage)
  on(LoginPage).login_application_with(:red_robin_account)
  on(HomePage).bookFlight
  on(HomePage).wait_for_ajax
  #Enter the departure,arrival page and select air_craft
  on(FlightsPage) do |page|
    page.select_aircraft_type 'CITATION ENCORE'
    page.wait_for_ajax
    page.upgrade_aircraft_type 'CITATION EXCEL/XLS'
    page.enter_arrival_airport Session[:arr_airport]
    page.wait_for_ajax
  end
end

Then(/^NJA owner was inform the arrival airport is not suitable$/) do
  on(FlightsPage) do |page|
    airport = page.gather_drop_down_arrival_airport
    expect(airport[0]).to include 'Not suitable for CITATION EXCEL'
  end
end

Then(/^NJA owner was inform the departure airport is not suitable for the flight$/) do
  on(FlightsPage) do |page|
    airport = page.gather_drop_down_departure_airport
    expect(airport[0]).to include 'Not suitable for CITATION ENCORE'
  end
end

When(/^NJA owner entering a prohibited until review airport for departure$/) do
  Session[:dep_airport] ='MMX'

  navigate_to(LoginPage)
  on(LoginPage).login_application_with(:red_robin_account)
  on(HomePage).bookFlight
  on(HomePage).wait_for_ajax
  #Enter the departure,arrival page and select air_craft
  on(FlightsPage) do |page|
    page.select_aircraft_type 'CITATION ENCORE'
    page.enter_departure_airport Session[:dep_airport]
    page.wait_for_ajax
  end
end

When(/^NJA owner entering a prohibited until review airport for arrival$/) do
  Session[:arr_airport_airport] ='MMX'

  navigate_to(LoginPage)
  on(LoginPage).login_application_with(:red_robin_account)
  on(HomePage).bookFlight
  on(HomePage).wait_for_ajax
  #Enter the departure,arrival page and select air_craft
  on(FlightsPage) do |page|
    page.select_aircraft_type 'CITATION ENCORE'
    page.enter_arrival_airport Session[:arr_airport]
    page.wait_for_ajax
  end
end

Then(/^NJA owner was inform the arrival airport is not suitable for the flight$/) do
  on(FlightsPage) do |page|
    airport = page.gather_drop_down_arrival_airport
    expect(airport[0]).to include 'Not suitable for CITATION ENCORE'
  end
end

When(/^NJE owner entering a prohibited until review airport for departure$/) do
  Session[:dep_airport] ='GLZ'

  navigate_to(LoginPage)
  on(LoginPage).login_application_with(:juma_account)
  on(HomePage).bookFlight
  on(HomePage).wait_for_ajax
  #Enter the departure,arrival page and select air_craft
  on(FlightsPage) do |page|
    page.wait_for_ajax
    page.downgrade_aircraft_type 'CITATION EXCEL/XLS'
    page.enter_departure_airport Session[:dep_airport]
    page.wait_for_ajax
  end
end

Then(/^NJE owner was inform the departure airport is not suitable$/) do
  on(FlightsPage) do |page|
    airport = page.gather_drop_down_departure_airport
    expect(airport[0]).to include 'Not suitable for CITATION EXCEL'
  end
end

When(/^NJE owner entering a prohibited airport for arrival$/) do
  Session[:arr_airport] ='LCY'

  navigate_to(LoginPage)
  on(LoginPage).login_application_with(:juma_account)
  on(HomePage).bookFlight
  on(HomePage).wait_for_ajax
  #Enter the departure,arrival page and select air_craft
  on(FlightsPage) do |page|
    page.wait_for_ajax
    page.upgrade_aircraft_type 'GULFSTREAM V/550'
    page.enter_arrival_airport Session[:arr_airport]
    page.wait_for_ajax
  end
end

Then(/^NJE owner was inform the arrival airport is not suitable$/) do
  on(FlightsPage) do |page|
    airport = page.gather_drop_down_arrival_airport
    expect(airport[0]).to include 'Not suitable for GULFSTREAM 550'
  end
end

Then(/^NJE owner was inform the departure airport is not suitable for the flight$/) do
  on(FlightsPage) do |page|
    airport = page.gather_drop_down_departure_airport
    expect(airport[0]).to include 'Not suitable for CITATION EXCEL'
  end
end

When(/^NJE owner entering a prohibited until review airport for arrival$/) do
  Session[:arr_airport] ='GLZ'

  navigate_to(LoginPage)
  on(LoginPage).login_application_with(:juma_account)
  on(HomePage).bookFlight
  on(HomePage).wait_for_ajax
  #Enter the departure,arrival page and select air_craft
  on(FlightsPage) do |page|
    page.wait_for_ajax
    page.downgrade_aircraft_type 'CITATION EXCEL/XLS'
    page.enter_arrival_airport Session[:arr_airport]
    page.wait_for_ajax
  end
end

Then(/^NJE owner was inform the arrival airport is not suitable for the flight$/) do
  on(FlightsPage) do |page|
    airport = page.gather_drop_down_arrival_airport
    expect(airport[0]).to include 'Not suitable for CITATION EXCEL'
  end
end

When(/^NJE owner entering a prohibited airport for departure$/) do
  pending
end

When(/^depart from a slotted airport$/) do

  Session[:dep_airport] ='LCY'
  Session[:arr_airport] = 'EDL'

  navigate_to(LoginPage)
  on(LoginPage).login_application_with(:juma_account)
  on(HomePage).bookFlight
  on(HomePage).wait_for_ajax
  #Enter the departure,arrival page and select air_craft
  on(FlightsPage) do |page|
    page.wait_for_ajax
    page.set_departure_airport Session[:dep_airport]
    page.wait_for_ajax
    page.set_arrival_airport Session[:arr_airport]
    page.select_departure_date_time_link
    page.set_flight_date_time '36','NJE'
    page.select_calendar_save_link
    page.wait_for_ajax
  end

end

Then(/^a message about slotted time departure airport restriction is shown$/) do
    on(FlightsPage) do |page|
    data = page.gather_departure_alert_msg
    expect(data).to include 'Slotted Airport'
    end
end

When(/^arrive into a slotted airport$/) do
  Session[:dep_airport] ='EDL'
  Session[:arr_airport] = 'LCY'

  navigate_to(LoginPage)
  on(LoginPage).login_application_with(:juma_account)
  on(HomePage).bookFlight
  on(HomePage).wait_for_ajax
  #Enter the departure,arrival page and select air_craft
  on(FlightsPage) do |page|
    page.wait_for_ajax
    page.set_departure_airport Session[:dep_airport]
    page.wait_for_ajax
    page.set_arrival_airport Session[:arr_airport]
    page.select_departure_date_time_link
    page.set_flight_date_time '36','NJE'
    page.select_calendar_save_link
    page.wait_for_ajax
  end
end

Then(/^a message about slotted time arrival airport restriction is shown$/) do
  on(FlightsPage) do |page|
    data = page.gather_arrival_alert_msg
    expect(data).to include 'Slotted Airport'
  end
end

When(/^depart from a restricted airport$/) do
  Session[:dep_airport] ='EDL'
  Session[:arr_airport] = 'LCY'

  navigate_to(LoginPage)
  on(LoginPage).login_application_with(:juma_account)
  on(HomePage).bookFlight
  on(HomePage).wait_for_ajax
  #Enter the departure,arrival page and select air_craft
  on(FlightsPage) do |page|
    page.wait_for_ajax
    page.set_departure_airport Session[:dep_airport]
    page.wait_for_ajax
    page.set_arrival_airport Session[:arr_airport]
    page.select_departure_date_time_link
    page.wait_for_ajax
    page.set_flight_date_time '36','NJE'
    page.select_calendar_save_link
    page.wait_for_ajax
  end
end

Then(/^a message about restricted time departure airport is shown$/) do
  on(FlightsPage) do |page|
    data = page.gather_departure_alert_msg
    expect(data).to include 'Airport is prohibited'
  end
end

When(/^arrive into a restricted airport$/) do
  Session[:dep_airport] ='LCY'
  Session[:arr_airport] = 'EDL'

  navigate_to(LoginPage)
  on(LoginPage).login_application_with(:juma_account)
  on(HomePage).bookFlight
  on(HomePage).wait_for_ajax
  #Enter the departure,arrival page and select air_craft
  on(FlightsPage) do |page|
    page.verify_on_flights_page
    page.set_departure_airport Session[:dep_airport]
    page.wait_for_ajax
    page.set_arrival_airport Session[:arr_airport]
    page.select_departure_date_time_link
    page.wait_for_ajax
    page.set_flight_date_time '36','NJE'
    page.select_calendar_save_link
    page.wait_for_ajax
  end
end

Then(/^a message about restricted time arrival airport is shown$/) do
  on(FlightsPage) do |page|
    data = page.gather_arrival_alert_msg
    expect(data).to include 'Airport is prohibited'
  end
end

When(/^NJA edit a submitted flight arrival into (.*) (.*) (\d+) hours before departure$/) do |airport, off_set_from_utc, arrhr|

  navigate_to(FlightsPage)

  on(FlightsPage) do |page|
    page.verify_on_flights_page
    page.wait_for_ajax
    page.select_aircraft_type('CITATION ENCORE')
    page.wait_for_ajax
    page.set_arrival_airport airport, 1
    page.wait_for_ajax
    page.set_departure_airport 'MIA',1
    page.select_departure_date_time_link
    page.wait_for_ajax
    page.set_flight_date_time arrhr
    page.select_calendar_save_link
    page.wait_for_ajax
    page.addPassengers_element.when_present.click
    page.wait_for_ajax
  end



end