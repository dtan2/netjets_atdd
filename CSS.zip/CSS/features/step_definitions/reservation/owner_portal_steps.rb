When(/^the user logs into Owner Portal$/) do
  Session[:password] = 'abc123ABC'
  # navigate_to(LoginPage, using: :default)
  # navigate_to(select_login_url('op_login'))
  visit(LoginPage)
    on(LoginPage) do |page|
    page.wait_for_ajax
    page.verify_on_login_page
    page.userName = Session[:user_email]
    page.userPassword = Session[:password]
    sleep 10
    page.signIn
  end
end
Then(/^the homepage appears$/) do
  on(HomePage).verify_on_home_page
end