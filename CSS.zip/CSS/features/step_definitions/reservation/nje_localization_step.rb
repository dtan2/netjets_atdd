Given(/^I am logged in as an NJE user$/) do
  # navigate_to(CateringPage)
  on(LoginPage).login_application_with(:juma_account)

end


When(/^I navigate through the owner portal seeing time in 24 hour format$/) do


    on(HomePage) do |page|
       page.verify_nje_time_format_res
       page.bookFlight
    end

    on(FlightsPage) do |page|
      page.set_req_data_for_reservation 'juma_reservation','NJE'
      page.wait_for_loading_overlay
    end

    on(PassengersPage) do |page|
     page.set_passenger_name 'Paul Janecek'
     page.select_add_to_flight_button
     page.wait_for_loading_overlay
     timestamp= page.gather_passenger_flight_info
     expect(timestamp[5]).not_to include 'am' || 'pm'
     expect(timestamp[10]).not_to include 'am' || 'pm'
     page.nextCatering
     page.wait_for_ajax
    end

     on(CateringPage) do |page|
      flight_info = page.gather_catering_flight_info
      expect(flight_info[5]).not_to include 'am' || 'pm'
      expect(flight_info[10]).not_to include 'am' || 'pm'
      page.groundTransportation
      page.wait_for_loading_overlay
     end

      on(GroundPage) do |page|

        page.create_nje_dep_chauffeured 'Luxury Sedan (3 + Driver)','Paul Janecek'
        pickup = page.gather_chauffeured_form_pickup_time_format
        expect(pickup).to include '23'
        page.save_chauffeured_order
        page.wait_for_ajax_loader

        page.create_nje_arr_rental_credit_card 'Mid Size','none','Paul Janecek'
        page.rental_form_element.link_element(:class => 'set-date date-time').when_present.click
        dropoff = page.gather_nje_rental_calendar_return_time_format
        expect(dropoff).to include '23'
        page.calendar_element.link_element(:text=>'Confirm').click
        dropoff_1= page.gather_rental_form_time_format
        expect(dropoff_1).not_to include 'am' || 'pm'
        page.save_rental_order
        page.wait_for_ajax_loader
        flight_info = page.gather_ground_flight_info
        expect(flight_info[5]).not_to include 'am' || 'pm'
        expect(flight_info[10]).not_to include 'am' || 'pm'
        page.reviewAndRequest
      end

      on(ReviewAndRequest)  do |page|
       time_format = page.gather_time_nje_time_format
       expect(time_format[10]).not_to include 'am' || 'pm'
       expect(time_format[16]).not_to include 'am' || 'pm'
       expect(time_format[49]).not_to include 'am' || 'pm'
       expect(time_format[63]).not_to include 'am' || 'pm'
      end
end

When(/^I select the Account header link$/) do
  on(AccountBasicDetailsPage).profile_account_element.when_present.hover
end

Then(/^I do not see a Preferences sub\-header$/) do
  on(AccountBasicDetailsPage) do |page|
  expect(page.hover_items_element.div_elements[1].list_item_elements[3].present?).to be false
  end
end

When(/^I select the Profile header link$/) do
  on(ProfilePage).profile
end

When(/^I add a one\-time contact for a lead passenger$/) do
    on(HomePage).verify_on_home_page
    on(HomePage).bookFlight

    on(FlightsPage) do |page|
    page.set_req_data_for_reservation 'juma_reservation','NJE'
    end
end

Then(/^a '\+' appears before the phone number$/) do

      on(PassengersPage) do |page|
         page.set_passenger_name 'Paul Janecek'
         page.select_add_to_flight_button
         page.wait_for_loading_overlay
         page.select_lead_passenger_radio_button
         page.all_leg_element.list_item_elements[0].span_element(:id=>'international-prefix-1').text.should == '+'
        end

end

And(/^I can enter a 3 digit country code$/) do

  on(PassengersPage) do |page|
      page.all_leg_element.list_item_elements[0].text_field_element(:id=>'country-10').value = '1234'
      page.wait_for_ajax_loader
      page.all_leg_element.list_item_elements[0].text_field_element(:id=>'country-10').value.length.should == 3
  end
end

And(/^I can enter a 3 digit area code$/) do
  on(PassengersPage) do |page|
      page.all_leg_element.list_item_elements[0].text_field_element(:id=>'area-10').value = '6834'
      page.wait_for_ajax_loader
      page.all_leg_element.list_item_elements[0].text_field_element(:id=>'area-10').value.length.should == 3
  end
end

And(/^I can enter a 20 digits into the rest of the number$/) do
    on(PassengersPage) do |page|
      page.all_leg_element.list_item_elements[0].text_field_element(:id=>'number-10').value = '683434683264834725443'
      page.wait_for_ajax_loader
      page.all_leg_element.list_item_elements[0].text_field_element(:id=>'number-10').value.length.should == 20
   end
end

When(/^I am at the profile information page$/) do

      on(ProfilePage) do |page|
      page.select_personal_details
      page.phoneNumbers
      page.select_pn_add_new_button
      end
  end

Then(/^I can enter a 5 digit country code$/) do

     on(ProfilePage) do |page|
       page.set_pn_country_code '242346'
       page.pnPhoneCountry.length.should == 5
     end

end

And(/^I can enter a 5 digit area code$/) do
  on(ProfilePage) do |page|
    page.set_pn_area_code '3425346'
    page.pnPhoneArea.length.should == 5
  end
end

And(/^I can enter a 20 digit into the rest of the number$/) do
  on(ProfilePage) do |page|
    page.set_pn_telephone '342534689123456782341'
    page.pnPhoneTel.length.should == 20
    page.pnSave
    page.wait_for_ajax_loader
  end


end

And(/^a '\+' appears before the number fields$/) do
  on(ProfilePage) do |page|
    page.select_personal_details
    page.phoneNumbers
    page.phone_summary_element.text[0].should == '+'
  end


end

Given(/^I am logged into Owner Portal as an NJE Card Account user$/) do
  on(LoginPage).login_application_with(:juma_account)
  on(HomePage).verify_on_home_page

end

When(/^I am on the new reservation Flights screen$/) do
  continue_navigation_to(FlightsPage)

  on(FlightsPage).verify_on_flights_page

end

Then(/^the contract type is shown as a Card$/) do

  on(FlightsPage).validate_contract_type 'NJ Card'


end

When(/^I am on the Aircraft & Balance page$/) do
   on(AccountBasicDetailsPage).select_aircraft_balance
    end

Then(/^the contract type is shown as a Card and contract hours is hidden$/) do
   on(AccountBasicDetailsPage) do |page|
   page.validate_contract_type 'NJ Card','1411346'
   expect(page.account_page_element.text).not_to include 'Remaining hours as of last invoice'
   end
end