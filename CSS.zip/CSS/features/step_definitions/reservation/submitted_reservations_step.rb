Given(/^I have a WIP reservation with Flights and Passengers$/) do
  navigate_to(ReviewAndRequest)
end
When(/^I submit the reservation$/) do
  on_page ReviewAndRequest do |page|
    page.wait_for_ajax
    page.verify_on_review_and_request_page
    page.select_request_reservation_button
  end
end
Then(/^a reservation number is returned$/) do
  on_page ConfirmationPage do |page|
    page.verify_on_confirmation_page
    page.verify_reservation_number_exists
  end
end
Given(/^I have a multi-flight WIP reservation with catering and ground$/) do
  navigate_to(CateringPage)

  on(CateringPage) do |page|
    page.verify_on_catering_page
    page.select_add_button
    page.wait_for_ajax
    page.add_catering_item 'Crudites'
    page.add_catering_item 'Mezze Tray'
    page.select_save_catering
    page.wait_for_ajax
    page.groundTransportation
  end

  on_page GroundPage do |page|
    page.verify_on_ground_page
    page.add_taxi(1)
    page.create_arr_chauffeured_enrollment_num '8 Passenger Stretch Limo (6 + Driver)', 'Eric Houseman'
    page.save_chauffeured_order
    # page.chauffeured_form_element.link_element(:class=>'btn btn3 btn3-smaller').when_not_visible (timeout=20)
    page.wait_for_ajax
    page.reviewAndRequest_element.when_present.click
  end

end
When(/^the reservation appears in the submitted list$/) do
  on_page ConfirmationPage do |page|
    @reservation_number = page.get_reservation_number
    page.select_return_to_home_page_button
  end
  on_page HomePage do |page|
    page.verify_on_home_page
    result = page.verify_reservation_number? @reservation_number
    expect(result).to eq true
  end
end
Given(/^I have a multi-flight WIP reservation with an upgrade and downgrade$/) do
  navigate_to(CateringPage)
  on(CateringPage).wait_for_ajax
  on(CateringPage).verify_on_catering_page
  on(HeaderMenu).flights_element.click

  on_page FlightsPage do |page|
    page.verify_on_flights_page
    page.upgrade_aircraft_type('GULFSTREAM IV/SP', 1)
    page.wait_for_ajax
    page.select_change_aircraft 2
    page.select_aircraft_type 'HAWKER 800XP - Collins', 2
    page.wait_for_ajax
    page.downgrade_aircraft_type('CITATION ENCORE', 2)
    page.select_add_passengers_button
  end
  @current_page = PassengersPage.new(@browser, false)
  on(PassengersPage).verify_on_passengers_page
  on(PassengersPage).skipToReviewAndRequest
end
Given(/^I submit a reservation$/) do

  steps %{
       Given I have a multi-flight WIP reservation with catering and ground
         When I submit the reservation}

end
When(/^I open the reservation$/) do
  on_page ConfirmationPage do |page|
    @reservation_number = page.get_reservation_number
    page.select_return_to_home_page_button
  end
  on_page HomePage do |page|
    page.select_reservation_submitted_flights @reservation_number
  end
end
Then(/^the reservation summary appears$/) do

  on_page RequestedReservationPage do |page|
    page.verify_on_requested_reservation_page
    expect(@browser.url).to include @reservation_number
  end
end
Given(/^I create a WIP reservation$/) do
  navigate_to(PassengersPage)
  @wip_id = on(PassengersPage).get_wip_reservation_id
end
When(/^I open a WIP reservation from the drafts list$/) do
  on(HeaderMenu).select_header_flights_link
  on(HomePage).select_drafts_link
end
Then(/^I see the WIP reservation$/) do
  on(HomePage).open_wip_reservation @wip_id
end
Given(/^I view the Flights not submitted list$/) do
  navigate_to(HomePage)
  on(HomePage).select_drafts_link
end
When(/^I delete the WIP reservation$/) do
  @wip_id = (HomePage).delete_wip_reservation @browser.div(:id => 'reservationList').li().attribute_value 'id'
end
Then(/^The reservation no longer appears in the drafts list$/) do
  submitted_reservation_in_list?
end

When(/^I view the reservation summary$/) do
  on(ConfirmationPage).select_view_print_itinerary_button

end

Then(/^the data on the for the reservation matches the data in the summary$/) do

  data_dept = on(RequestedReservationPage).gather_departure_itinerary
  expect(data_dept.departure).to eq @departure
  expect(data_dept.departure_time).to eq @departure_time
  expect(data_dept.departure_date).to eq @departure_date
  expect(data_dept.departure_fbo).to eq @departure_fbo
  data_arrl = on(RequestedReservationPage).gather_arrival_itinerary
  expect(data_arrl.arrival).to eq @arrival
  expect(data_arrl.arrival_time).to eq @arrival_time
  expect(data_arrl.arrival_date).to eq @arrival_date
  expect(data_arrl.arrival_fbo).to eq @arrival_fbo
end

Given(/^I have a submitted reservation with Flights and Passengers$/) do
  navigate_to(ReviewAndRequest)
  on(ReviewAndRequest).wait_for_ajax
  on(ReviewAndRequest).verify_on_review_and_request_page
  summary_dept = on(RequestedReservationPage).gather_departure_itinerary
  @departure = summary_dept.departure
  @departure_fbo = summary_dept.departure_fbo
  @departure_time = summary_dept.departure_time
  @departure_date = summary_dept.departure_date
  summary_arrl = on(RequestedReservationPage).gather_arrival_itinerary
  @arrival = summary_arrl.arrival
  @arrival_fbo = summary_arrl.arrival_fbo
  @arrival_time = summary_arrl.arrival_time
  @arrival_date = summary_arrl.arrival_date
  step 'I submit the reservation'
end

Given(/^I submit a reservation with catering order$/) do
  navigate_to(CateringPage)
  on(CateringPage) do |page|
    page.verify_on_catering_page
    page.select_add_button
    page.add_catering_item 'Mezze Tray'
    page.add_catering_item 'Antipasto Tray'
    page.wait_for_ajax
    page.select_save_catering
    page.wait_for_ajax_loader
    page.wait_for_ajax
    page.select_add_button 2
    page.add_catering_item 'Crudites', 2, 2
    page.add_catering_item 'Side Caesar Salad', 2, 2
    page.wait_for_ajax_loader
    page.select_save_catering 2
    page.wait_for_loading_overlay
    page.wait_for_ajax_loader
    page.select_skip_to_review_and_request_button
    page.wait_for_loading_overlay
  end

  on(ReviewAndRequest).verify_on_review_and_request_page
  @catering_temp = on(RequestedReservationPage).gather_catering_order
  @catering_temp2 = on(RequestedReservationPage).gather_catering_order 2
  step 'I submit the reservation'
end

Then(/^the data on the for the catering order matches the data in the summary$/) do
  catering = on(RequestedReservationPage).gather_catering_order
  catering_2 = on(RequestedReservationPage).gather_catering_order 2
  expect(catering).to eq @catering_temp
  expect(catering_2).to eq @catering_temp2
end


When(/^I change the departure time$/) do
  on(ConfirmationPage) do |page|
    page.verify_on_confirmation_page
    page.select_view_print_itinerary_button
  end

  on(RequestedReservationPage) do |page|
    page.verify_on_requested_reservation_page
    page.select_edit_flight
  end

  on(FlightsPage) do |page|
    page.wait_for_ajax
    page.select_existing_departure_date_time_link
    page.set_flight_date_time '150'
    page.select_calendar_save_link
    page.wait_for_ajax
    @dep_info = page.get_departure_date_time
    page.save_exit
  end
end

Then(/^the departure time is updated$/) do
  on(RequestedReservationPage) do |page|
    page.wait_for_ajax
    page.verify_on_requested_reservation_page
    final_dep_info = page.gather_departure_itinerary
    expect(final_dep_info.departure_date.delete('0')).to eq @dep_info.date.delete('0')
    expect(final_dep_info.departure_time).to eq @dep_info.time
    offsetDate = Time.now + (24*60*60)

    expect(final_dep_info.departure_date).not_to eq offsetDate.strftime "%a %e %b %Y"
  end
end

When(/^I change the arrival time$/) do

  on(ConfirmationPage) do |page|
    page.verify_on_confirmation_page
    page.select_view_print_itinerary_button
  end

  on(RequestedReservationPage) do |page|
    page.verify_on_requested_reservation_page
    page.select_edit_flight
  end

  on(FlightsPage) do |page|
    page.wait_for_ajax
    page.select_existing_arrival_date_time_link
    page.set_flight_date_time '150'
    page.select_calendar_save_link
    page.wait_for_ajax
    @arrival_info = page.get_arrival_date_time
    page.save_exit
  end
end

Then(/^the arrival time is updated$/) do
  on(RequestedReservationPage) do |page|
    page.wait_for_ajax
    page.verify_on_requested_reservation_page
    final_dep_info = page.gather_arrival_itinerary
    expect(final_dep_info.departure_date.delete('0')).to eq @arrival_info.date.delete('0')
    expect(final_dep_info.departure_time).to eq @arrival_info.time
    offsetDate = Time.now + (24*60*60)

    expect(final_dep_info.departure_date).not_to eq offsetDate.strftime "%a %e %b %Y"
  end
end

When(/^I change the departure airport$/) do
  on(ConfirmationPage) do |page|
    page.verify_on_confirmation_page
    page.select_view_print_itinerary_button
  end

  on(RequestedReservationPage) do |page|
    page.verify_on_requested_reservation_page
    @dep_airport = page.gather_departure_itinerary
    page.select_edit_flight
  end

  on(FlightsPage) do |page|
    page.wait_for_ajax
    page.set_departure_airport 'JFK'
    page.select_departure_date_time_link
    page.set_flight_date_time '150'
    page.select_calendar_save_link
    page.wait_for_ajax_loader
    page.save_exit_element.click
    page.wait_for_ajax
  end
end

Then(/^the departure airport has changed$/) do
  on(RequestedReservationPage) do |page|
    page.verify_on_requested_reservation_page
    final_dep_info = page.gather_departure_itinerary
    expect(final_dep_info.departure).not_to eq @dep_airport.departure
    expect(final_dep_info.departure).to eq 'KJFK'
  end
end

When(/^I change the arrival airport$/) do
  on(ConfirmationPage) do |page|
    page.verify_on_confirmation_page
    page.select_view_print_itinerary_button
  end

  on(RequestedReservationPage) do |page|
    page.verify_on_requested_reservation_page
    @arrival_airport = page.gather_arrival_itinerary
    page.select_edit_flight
  end

  on(FlightsPage) do |page|
    page.wait_for_ajax
    page.set_arrival_airport 'JFK', 2
    page.select_arrival_date_time_link
    page.set_flight_date_time '150'
    page.select_calendar_save_link
    page.wait_for_ajax_loader
    page.save_exit_element.click
    page.wait_for_ajax
  end
end

Then(/^the arrival airport has changed$/) do
  on(RequestedReservationPage) do |page|
    page.verify_on_requested_reservation_page
    final_arr_info = page.gather_arrival_itinerary 2
    expect(final_arr_info.departure).not_to eq @arrival_airport.departure
    expect(final_arr_info.departure).to eq 'KJFK'
  end
end

Given(/^I have a submitted reservation with catering order$/) do
  navigate_to(CateringPage)

  on(CateringPage) do |page|
    page.verify_on_catering_page
    page.add_catering_item ''
  end

end

When(/^I edit the catering order$/) do

  on(ConfirmationPage) do |page|
    page.verify_on_confirmation_page
    page.select_view_print_itinerary_button
  end

  on(RequestedReservationPage) do |page|
    page.verify_on_requested_reservation_page
    page.select_edit_catering
  end

  on(CateringPage) do |page|
    page.verify_on_catering_page
    page.select_edit_button
    page.add_catering_item 'Fried Chicken Tenders'
    page.change_catering_quantity 'Antipasto Tray', 10
    page.wait_for_ajax
    page.select_save_catering
    page.wait_for_ajax_loader
    page.wait_for_ajax
    page.BacktoReservationSum
    page.wait_for_ajax
  end

end

Then(/^the catering order is edited$/) do
  on(RequestedReservationPage) do |page|
    page.verify_on_requested_reservation_page
    catering = page.gather_catering_order
    expect(catering[4]).to eq '5 x Fried Chicken Tenders'
    expect(catering[3]).to eq '10 x Antipasto Tray'
  end
end

Given(/^I have a submitted_reservation with (.*)$/) do |ground_order|

  navigate_to(GroundPage)
  on(GroundPage).verify_on_ground_page
  @ground_order = ground_order
  case ground_order

    when 'departure chauffeured'

      on(GroundPage) do |page|
        page.wait_for_ajax
        page.create_dep_chauffeured_NJ '12 Passenger Van', 'Eric Houseman'
        page.save_chauffeured_order
      end

    when 'arrival chauffeured'

      on_page GroundPage do |grd|
        grd.wait_for_ajax_loader
        grd.create_arr_chauffeured_NJ '12 Passenger Van', 'Eric Houseman'
        grd.save_chauffeured_order
      end

    when 'rental'

      on_page GroundPage do |grd|
        grd.wait_for_ajax_loader
        grd.create_arr_rental_credit_card "Mid Size", 'none', 'Eric Houseman'
        grd.save_rental_order
      end

    else
      nil

  end
  on(GroundPage).wait_for_ajax(timeout =30, message= 'time out ajax')
  on(GroundPage).select_review_and_request_button
  on(ReviewAndRequest) do |page|
    page.verify_on_review_and_request_page
    page.requestReservation
  end
end

When(/^I change the vehicle type to (.*)$/) do |vehicle_type|

  on(ConfirmationPage) do |page|
    page.verify_on_confirmation_page
    page.select_view_print_itinerary_button
  end

  on(RequestedReservationPage) do |page|
    page.verify_on_requested_reservation_page
    page.select_edit_ground
  end

  on(GroundPage) do |page|
    page.verify_on_ground_page
    page.edit_ground_order

    if @ground_order != 'rental'
      page.set_chauffeured_vehicle vehicle_type
      page.save_chauffeured_order
    else
      page.set_rental_vehicle vehicle_type
      page.save_rental_order
    end
    page.wait_for_ajax
    page.back_summary_element.when_present.click
  end
end

When(/^a delete a flight$/) do
  on(ConfirmationPage) do |page|
    page.wait_for_ajax
    page.verify_on_confirmation_page
    page.viewPrintItinerary
  end

  on(RequestedReservationPage) do |page|
    page.verify_on_requested_reservation_page
    page.select_cancel_flight_button
    page.wait_for_ajax
  end


end

Then(/^the flight is cancelled$/) do
  sleep 1
  flight_info = on(RequestedReservationPage).flights_header_elements[0].when_visible.text.split(/\n/)
  expect(flight_info[6]).to eq 'CANCELLED'
end

Then(/^the (.*) (.*) is changed$/) do |ground_order, vehicle_type|

  case ground_order

    when 'departure chauffeured'
      on(RequestedReservationPage) do |page|
        page.verify_on_requested_reservation_page
        @ground_order = page.gather_departure_ground_order
      end

    when 'arrival chauffeured'
      on(RequestedReservationPage) do |page|
        page.verify_on_requested_reservation_page
        @ground_order = page.gather_arrival_ground_order
      end

    when 'rental'
      on(RequestedReservationPage) do |page|
        page.verify_on_requested_reservation_page
        @ground_order = page.gather_rental_ground_order
      end
      expect(@ground_order[2]).to eq vehicle_type

    else
      nil

  end
end

When(/^I change the contracted aircraft$/) do

  on(ConfirmationPage) do |page|
    page.verify_on_confirmation_page
    page.select_view_print_itinerary_button
  end

  on(RequestedReservationPage) do |page|
    page.verify_on_requested_reservation_page
    page.select_edit_flight
    page.wait_for_ajax
  end

  on(FlightsPage) do |page|
    page.verify_on_flights_page
    page.select_change_aircraft
    page.select_aircraft_type 'HAWKER 800XP - Collins'
    page.wait_for_ajax
    page.save_exit
    page.wait_for_ajax
  end

end

Then(/^the aircraft has been changed$/) do
  on(RequestedReservationPage) do |page|
    page.verify_on_requested_reservation_page
    page.select_edit_flight
    page.wait_for_ajax
  end

  on(FlightsPage) do |page|
    page.verify_on_flights_page
    air_craft= page.gather_selected_aircraft
    expect(air_craft).to eq 'HAWKER 800XP - Collins'
  end


end

When(/^I upgrade an aircraft$/) do

  on(ConfirmationPage) do |page|
    page.verify_on_confirmation_page
    page.select_view_print_itinerary_button
  end

  on(RequestedReservationPage) do |page|
    page.verify_on_requested_reservation_page
    page.select_edit_flight
    page.wait_for_ajax
  end

  on(FlightsPage) do |page|
    page.verify_on_flights_page
    page.upgrade_aircraft_type 'GULFSTREAM 450'
    page.wait_for_ajax
    page.save_exit
    page.wait_for_ajax
  end


end

Then(/^the aircraft has been updated$/) do
  on(RequestedReservationPage) do |page|
    page.verify_on_requested_reservation_page
    data = page.gather_contract_info
    expect(data[0]).to eq 'Upgraded from CITATION ENCORE'

  end
end

When(/^I downgrade an aircraft$/) do
  step 'I change the contracted aircraft'

  on(RequestedReservationPage) do |page|
    page.verify_on_requested_reservation_page
    page.select_edit_flight
    page.wait_for_ajax
  end

  on(FlightsPage) do |page|
    page.verify_on_flights_page
    page.downgrade_aircraft_type 'CITATION EXCEL/XLS'
    page.wait_for_ajax
    page.save_exit
    page.wait_for_ajax
  end

end

Then(/^the aircraft has been downgraded$/) do

  on(RequestedReservationPage) do |page|
    page.verify_on_requested_reservation_page
    data = page.gather_contract_info
    expect(data[0]).to eq 'Downgraded from HAWKER 800XP - Collins'
  end


end

Given(/^I have upgrade by aircraft in a submitted reservation$/) do
  steps %{Given I have a submitted reservation with Flights and Passengers
         When I upgrade an aircraft}

end

When(/^I delete my regrade$/) do
  on(RequestedReservationPage) do |page|
    page.verify_on_requested_reservation_page
    page.select_edit_flight
    page.wait_for_ajax
  end

  on(FlightsPage) do |page|
    page.verify_on_flights_page
    page.cancel_aircraft_regrade
    page.wait_for_ajax
  end


end

Then(/^the upgrade is deleted$/) do

  on(FlightsPage) do |page|
    air_craft= page.gather_selected_aircraft
    expect(air_craft).to eq 'CITATION ENCORE'
  end

end

Given(/^I have downgrade by aircraft in a submitted reservation$/) do
  steps %{Given I have a submitted reservation with Flights and Passengers
          When I downgrade an aircraft}
end

Then(/^the downgrade is deleted$/) do
  on(FlightsPage) do |page|
    air_craft= page.gather_selected_aircraft
    expect(air_craft).to eq 'HAWKER 800XP - Collins'
  end
end