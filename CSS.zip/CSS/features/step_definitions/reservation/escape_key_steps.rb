Given(/^I am at the downgrade aircraft windows$/) do
  navigate_to(FlightsPage)
  on(FlightsPage).verify_on_flights_page
  on(FlightsPage).select_aircraft_type 'GULFSTREAM V'
  on(FlightsPage).select_down_grade_button

end

Then(/^the aircraft selection windows closed$/) do
  expect(on(FlightsPage).up_down_grade_element.visible?).to eq 'false'
end

When(/^I want to close the downgrade aircraft windows$/) do
  on(FlightsPage).select_esc_key 'up_down_grade'
end

Given(/^I am at the upgrade aircraft windows$/) do
  navigate_to(FlightsPage)
  on(FlightsPage).verify_on_flights_page
  on(FlightsPage).select_aircraft_type 'CITATION ENCORE'
  on(FlightsPage).select_up_grade_button
end

When(/^I want to close the upgrade aircraft windows$/) do
  on(FlightsPage).select_esc_key 'up_down_grade'
 end