Given(/^I am on the reservation (.*) screen$/) do |op_wip_page|

  @notes = op_wip_page

  case op_wip_page

    when 'Flights'
      navigate_to(FlightsPage)
    when 'Passengers'
      navigate_to(PassengersPage)
    when 'Catering'
      navigate_to(CateringPage)
    when 'Ground'
      navigate_to(GroundPage)
    when 'Review and submit'
      navigate_to(ReviewAndRequest)

    else
      nil

  end

end

When(/^I add a reservation note$/) do
  on(ReservationNotes).wait_for_ajax
  on(ReservationNotes).add_reservation_note
  on(ReservationNotes).create_reservation_note @notes
  on(ReservationNotes).wait_for_ajax_loader
end


Then(/^The reservation note label to "([^"]*)"$/) do |arg|

  on(ReservationNotes).add_reservation_note_element.text.should == "#{arg}"

end


Then(/^An email is send to OSRs$/) do

  on(NetjetsWebmailLoginPage).login_to_webmail
  on(NetjetsWebmailInboxPage).open_email 0
  on(NetjetsWebmailInboxPage).verify_reservation_notes_email @reservation_num, 'john123456789011121314151617181920@redrobin.com', @notes

end

Given(/^I am on the submitted reservation (.*) screen adding a reservation notes$/) do |op_submitted_page|
  navigate_to(ReviewAndRequest)
  on(ReviewAndRequest).requestReservation
  @reservation_num = on(ConfirmationPage).get_reservation_number
  on(ConfirmationPage).viewPrintItinerary
  @notes = op_submitted_page

  case op_submitted_page

    when 'Flights'
      on(RequestedReservationPage).select_edit_flight
      on(RequestedReservationPage).wait_for_loading_overlay
      on(FlightsPage).verify_on_flights_page

    when 'Passengers'
      on(RequestedReservationPage).select_edit_passengers
      on(RequestedReservationPage).wait_for_loading_overlay
      on(PassengersPage).verify_on_passengers_page

    when 'Catering'
      on(RequestedReservationPage).select_edit_catering
      on(RequestedReservationPage).wait_for_loading_overlay
      on(CateringPage).verify_on_catering_page

    when 'Ground'
      on(RequestedReservationPage).select_edit_ground
      on(RequestedReservationPage).wait_for_loading_overlay
      on(GroundPage).verify_on_ground_page


    else
      nil


  end
  on(ReservationNotes).add_reservation_note
  on(ReservationNotes).create_reservation_note @notes
  on(ReservationNotes).wait_for_ajax_loader

end

Given(/^I have a wip reservation with reservation notes$/) do

  navigate_to(ReviewAndRequest)
  @wip_num =@browser.url.match(/WIP-\d+/)
  on(ReservationNotes).add_reservation_note
  on(ReservationNotes).create_reservation_note 'Summary'
  on(ReservationNotes).wait_for_ajax_loader

end

When(/^I update a reservation note from each page$/) do |table|

  table.hashes.each do |items|

    @notes = items['pages']

    case items['pages']

      when 'Flights'
        on(HeaderMenu).flights_element.click
        on(FlightsPage).wait_for_loading_overlay
        on(FlightsPage).verify_on_flights_page

      when 'Passengers'
        on(HeaderMenu).passengers_element.click
        on(PassengersPage).wait_for_loading_overlay
        on(PassengersPage).verify_on_passengers_page

      when 'Catering'
        on(HeaderMenu).catering_element.click
        on(CateringPage).wait_for_loading_overlay
        on(CateringPage).verify_on_catering_page

      when 'Ground'
        on(HeaderMenu).ground_element.click
        on(GroundPage).wait_for_loading_overlay
        on(GroundPage).verify_on_ground_page


      else
        nil

    end
    on(ReservationNotes).wait_for_ajax_loader
    on(ReservationNotes).add_reservation_note
    on(ReservationNotes).create_reservation_note @notes
    on(ReservationNotes).wait_for_ajax_loader
  end

end


Then(/^the reservation notes is edited$/) do
  on(ReservationNotes).add_reservation_note
  on(ReservationNotes).verify_reservation_notes 'Summary'
  on(ReservationNotes).verify_reservation_notes 'Flights'
  on(ReservationNotes).verify_reservation_notes 'Passengers'
  on(ReservationNotes).verify_reservation_notes 'Catering'
  on(ReservationNotes).verify_reservation_notes 'Ground'
end

Given(/^I have a submitted reservation with reservation notes$/) do

  navigate_to(ReviewAndRequest)
  on(ReviewAndRequest).requestReservation
  @reservation_num = on(ConfirmationPage).get_reservation_number
  on(ConfirmationPage).viewPrintItinerary
  on(ReservationNotes).wait_for_ajax_loader
  on(ReservationNotes).add_reservation_note
  on(ReservationNotes).create_reservation_note 'Summary'
  on(ReservationNotes).wait_for_ajax_loader


end

When(/^I update the existing reservation note from each page$/) do |table|


  table.hashes.each do |items|

    @notes = items['pages']

    case items['pages']

      when 'Flights'
        on(RequestedReservationPage).select_edit_flight
        on(RequestedReservationPage).wait_for_loading_overlay
        on(FlightsPage).verify_on_flights_page
        on(ReservationNotes).add_reservation_note
        on(ReservationNotes).create_reservation_note @notes
        on(ReservationNotes).wait_for_ajax_loader
        on(FlightsPage).cancel_element.click

      when 'Passengers'
        on(RequestedReservationPage).select_edit_passengers
        on(RequestedReservationPage).wait_for_loading_overlay
        on(PassengersPage).verify_on_passengers_page
        on(ReservationNotes).add_reservation_note
        on(ReservationNotes).create_reservation_note @notes
        on(ReservationNotes).wait_for_ajax_loader
        on(PassengersPage).cancel_element.click

      when 'Catering'
        on(RequestedReservationPage).select_edit_catering
        on(RequestedReservationPage).wait_for_loading_overlay
        on(CateringPage).verify_on_catering_page
        on(ReservationNotes).add_reservation_note
        on(ReservationNotes).create_reservation_note @notes
        on(ReservationNotes).wait_for_ajax_loader
        on(CateringPage).BacktoReservationSum_element.click

      when 'Ground'
        on(RequestedReservationPage).select_edit_ground
        on(RequestedReservationPage).wait_for_loading_overlay
        on(GroundPage).verify_on_ground_page
        on(ReservationNotes).add_reservation_note
        on(ReservationNotes).create_reservation_note @notes
        on(ReservationNotes).wait_for_ajax_loader
        on(GroundPage).reviewAndRequest_element.click

      else
        nil

    end

  end

end

Then(/^An email is sent to the OSRs with edited notes$/) do

  on(NetjetsWebmailLoginPage).login_to_webmail
  on(NetjetsWebmailInboxPage).open_email 0
  email_body = on(NetjetsWebmailInboxPage).verify_reservation_notes_email @reservation_num, 'john123456789011121314151617181920@redrobin.com', 'Summary'

  email_body[7].should =='Summary Flights Passengers Catering Ground'

end

Given(/^I receive a reservation note email$/) do
  navigate_to(ReviewAndRequest)
  on(ReviewAndRequest).requestReservation
  @reservation_num = on(ConfirmationPage).get_reservation_number
  on(ConfirmationPage).viewPrintItinerary
  on(ReservationNotes).wait_for_ajax_loader
  on(ReservationNotes).add_reservation_note
  on(ReservationNotes).create_reservation_note 'Summary'
  on(ReservationNotes).wait_for_ajax_loader
end

When(/^I view the email$/) do
  on(NetjetsWebmailLoginPage).login_to_webmail
  on(NetjetsWebmailInboxPage).open_email 0
  @email_body = on(NetjetsWebmailInboxPage).verify_reservation_notes_email @reservation_num, 'john123456789011121314151617181920@redrobin.com', 'Summary'
end

Then(/^the email subject contains the account name$/) do |table|

  table.hashes.each do |items|

    case items['header']

      when 'Account'
        @email_body[2].should == 'Account: Red Robin Gourmet Restaurants'

      when 'Update Type'
        @email_body[3].should =='Update Type: Reservation Note'

      when 'Reservation Number'
        @email_body[4].should include 'Reservation Number:'

      when 'New Reservation Note'
        @email_body[7].should == 'Summary'

      when 'Previous Reservation Note'
        @email_body[11].should == 'NA'

      when 'Date updated'
        @email_body[14].should include "#{Time.now.strftime "%a %b %d"}"

      when 'User ID'
        @email_body[16].should include 'john123456789011121314151617181920@redrobin.com'


      else
        nil

    end

  end


end

When(/^I clear the reservation note$/) do

  on(ReservationNotes).add_reservation_note
  on(ReservationNotes).clear_element.click
  on(ReservationNotes).save_element.click

end


Then(/^the reservation notes label reset$/) do

  on(ReservationNotes).wait_for_ajax
  on(ReservationNotes).add_reservation_note_element.text.should == 'Add reservation notes'


end

When(/^I am at the home page$/) do
  on(HomePage).select_header_flights_link
  on(HomePage).drafts
  on(HomePage).delete_flights_element.when_visible(timeout=20)


end

Then(/^the tool tip present for the reservation$/) do
  on(HomePage).verify_tool_tip @wip_num
end


Then(/^continue from (.*) to submit$/) do |op_wip_page|

  @notes = op_wip_page
  case op_wip_page

    when 'Flights'
      on(FlightsPage).verify_on_flights_page

    when 'Passengers'
      on(PassengersPage).verify_on_passengers_page

    when 'Catering'
      on(CateringPage).verify_on_catering_page

    when 'Ground'
      on(GroundPage).verify_on_ground_page

    when 'Review and submit'
      on(ReviewAndRequest).verify_on_review_and_request_page

    else
      nil

  end
  continue_navigation_to(ReviewAndRequest)
  on(ReviewAndRequest).select_request_reservation_button
  @reservation_num = on(ConfirmationPage).get_reservation_number
end