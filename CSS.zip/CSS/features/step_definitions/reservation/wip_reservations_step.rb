Given(/^I am on the flights screen$/) do
  navigate_to(FlightsPage)
end
When(/^I create WIP reservation with (.*) flights$/) do |flights|
  on(FlightsPage).set_req_data_for_multi_flight_reservation flights.to_i
  @current_page = PassengersPage.new(@browser, false)
end
Then(/^the the (.*) screen shows (.*) flights$/) do |page, number|
  continue_navigation_to("#{page}Page")
  on("#{page}Page").verify_flight_count number
end
Given(/^I create multi-flight WIP reservation$/) do
  navigate_to(FlightsPage)
  on(FlightsPage).set_req_data_for_multi_flight_reservation 2
  @current_page = PassengersPage.new(@browser, false)
  continue_navigation_to(ReviewAndRequest)
end
When(/^I update all flights on the (.*) screen$/) do |page|
  pending
end
When(/^I update the (.*) for all flights on the "([^"]*)" screen$/) do |edit_field, arg|
  on(ReviewAndRequest).select_flights_page_link
  on_page(FlightsPage) do |page|
    case edit_field
      when 'aircraft_type'
        page.cancel_aircraft_regrade 1
        page.downgrade_aircraft_type('HAWKER 400XP', 1)
      when 'departure_airport'
        page.set_departure_airport('OSU', 1)
      when 'arrival_airport'
        page.set_arrival_airport('MIA', 1)
      when 'departure_date'
        page.select_existing_departure_date_time_link(1)
        page.set_flight_date_time(150, 1)
      when 'arrival_date'
        page.select_existing_arrival_date_time_link(1)
        page.set_flight_date_time(150, 1)
      else
        fail 'unexpected field case'
    end
    page.select_add_passengers_button
  end
end
Then(/^the updated (.*) is saved$/) do |edit_field|
  on(PassengersPage).select_catering_button
  @current_page = CateringPage.new(@browser, false)
  continue_navigation_to(ReviewAndRequest)
  on_page(ReviewAndRequest) do |page|
    case edit_field
      when 'aircraft_type'
        page.validate_aircraft_type('HAWKER 400XP', 1)
      when 'departure_airport'
        page.validate_departure_airport('OSU', 1)
      when 'arrival_airport'
        page.validate_arrival_airport('MIA', 1)
      when 'departure_date'
        page.validate_departure_time
        page.validate_departure_date
      when 'arrival_date'
        page.validate_arrival_time
        page.validate_arrival_date
      else
        fail 'unexpected validation case'
    end
  end
end
Given(/^I create a WIP reservation with flights$/) do
  navigate_to PassengersPage
  @wip_id = on_page(PassengersPage).get_wip_reservation_id
  sleep 1
  on_page(HeaderMenu).select_header_flights_link
  on_page(HomePage) do |page|
    page.select_drafts_link
    page.open_wip_reservation @wip_id
  end
end
When(/^I update the WIP reservation's contracted aircraft type$/) do
  on_page(FlightsPage) do |page|
    page.select_change_aircraft 1
    page.select_aircraft_type 'FALCON 2000'
    page.select_add_passengers_button
  end
end
Then(/^the updated aircraft type is saved to the WIP reservation$/) do
  on_page(HeaderMenu).select_header_flights_link
  on_page(HomePage) do |page|
    page.select_drafts_link
    page.open_wip_reservation @wip_id
  end
  on_page(FlightsPage).validate_aircraft_type(1, 'FALCON 2000')
end
When(/^I update the WIP reservation's departure airport$/) do
  on_page(FlightsPage) do |page|
    page.set_departure_airport('ELP', 1)
    page.select_add_passengers_button
  end
end
Then(/^the updated departure airport is saved to the WIP reservation$/) do
  on_page(HeaderMenu).select_header_flights_link
  on_page(HomePage) do |page|
    page.select_drafts_link
    page.open_wip_reservation @wip_id
  end
  on_page(FlightsPage).validate_departure_airport('ELP', 1)
end
When(/^I update the WIP reservation's arrival airport$/) do
  on_page(FlightsPage) do |page|
    page.set_arrival_airport('ELP', 1)
    page.select_add_passengers_button
  end
end
Then(/^the updated arrival airport is saved to the WIP reservation$/) do
  on_page(HeaderMenu).select_header_flights_link
  on_page(HomePage) do |page|
    page.select_drafts_link
    page.open_wip_reservation @wip_id
  end
  on_page(FlightsPage).validate_arrival_airport('ELP', 1)
end
When(/^I update the WIP reservation's departure date$/) do
  on_page(FlightsPage) do |page|
    @expected_departure_date_time = page.select_flight_date_time 30
    page.select_add_passengers_button
  end
end
Then(/^the updated departure date is saved to the WIP reservation$/) do
  on_page(HeaderMenu).select_header_flights_link
  on_page(HomePage) do |page|
    page.select_drafts_link
    page.open_wip_reservation @wip_id
  end
  on_page(FlightsPage).validate_departure_date_time(@expected_departure_date_time, 1)
end
When(/^I update the WIP reservation's arrival date$/) do
  on_page(FlightsPage) do |page|
    page.select_existing_departure_date_time_link
    page.wait_for_ajax
    @expected_arrival_date_time = page.set_flight_date_time '30'
    page.select_calendar_save_link
    page.select_add_passengers_button
  end
end
Then(/^the updated arrival date is saved to the WIP reservation$/) do
  on_page(HeaderMenu).select_header_flights_link
  on_page(HomePage) do |page|
    page.select_drafts_link
    page.open_wip_reservation @wip_id
  end
  on_page(FlightsPage).validate_arrival_date_time(@expected_arrival_date_time, 1)
end
Given(/^I create a WIP reservation with passengers$/) do
  navigate_to(CateringPage)
  @wip_id = on_page(PassengersPage).get_wip_reservation_id
  sleep 1
  on_page(HeaderMenu).select_header_flights_link
  on_page(HomePage) do |page|
    page.select_drafts_link
    page.open_wip_reservation @wip_id
  end
end

Given(/^I have a reservation$/) do
  navigate_to(FlightsPage)
  on(FlightsPage) do |page|
    page.select_aircraft_type 'CITATION ENCORE'
    page.set_departure_airport 'CMH'
    page.set_arrival_airport 'MIA'
    page.select_departure_date_time_link
    page.wait_for_ajax_loader
    page.set_flight_date_time 36
    page.select_calendar_save_link
   end 
end

When(/^I add the return flight$/) do
  on(FlightsPage) do |page|
  page.wait_for_ajax_loader
  page.wait_for_loading_overlay
  page.select_add_return_flight_link
  page.wait_for_ajax_loader
  end
end

Then(/^I the depature and arrival time are not populated$/) do
  expect()


end