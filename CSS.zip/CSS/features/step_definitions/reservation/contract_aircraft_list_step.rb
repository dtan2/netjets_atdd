

Given(/^I have (.*) (.*) (.*) login into flight page$/) do |contract_type, contract_num, login|

        @contract_type  = contract_type
        @contract_num = contract_num
          login2 = login.to_sym

        on(LoginPage).login_application_with(login2)
        on(HomePage).verify_on_home_page
        sleep 1
        continue_navigation_to(FlightsPage)

      end




Then(/^I should see my contract type in flight page$/) do


  on(FlightsPage).verify_on_flights_page
  on(FlightsPage).wait_for_ajax_loader
  on(FlightsPage).validate_contract_type(@contract_type)


end

And(/^contract and number showing in the aircraft balance page$/) do

  on(HeaderMenu).account
  on(AccountBasicDetailsPage).ac_balance
  on(AccountBasicDetailsPage).validate_contract_type(@contract_type,@contract_num)

end









