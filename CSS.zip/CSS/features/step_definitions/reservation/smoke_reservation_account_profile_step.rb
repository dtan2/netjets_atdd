Given(/^the user is logged in to owner's portal$/) do
  @browser.goto(select_login_url('op_login'))
  on_page LoginPage do |page|
    page.verify_on_login_page
    page.login_application_with
  end

  #@login = InputDataHelper.get_map('QALogIn')
  #on_page LoginPage do |page|
  #  page.verify_on_login_page
  #  page.set_user_name @login
  #  page.set_user_password @login
  #  page.select_sign_in_button
  #end
end

Given(/^the user selects 'Plan & book a new flight'$/) do
  on_page HomePage do |page|
    page.verify_on_home_page
    page.select_plan_book_flight_link
  end
end

When(/^the user selects a (.+) aircraft type$/) do |aircraftType|
  on_page FlightsPage do |page|
    page.verify_on_flights_page
    page.select_aircraft_type aircraftType
  end
end

When(/^the user selects the (.*) as departure airport for leg (.*)$/) do |departure_airport, leg_number|
  on_page FlightsPage do |page|
    page.verify_on_flights_page
    page.set_departure_airport(departure_airport, leg_number)
  end
end

When(/^the user selects the (.*) as arrival airport for leg (.*)$/) do |arrival_airport, leg_number|
  on_page FlightsPage do |page|
    page.verify_on_flights_page
    page.set_arrival_airport(arrival_airport, leg_number)
  end
end

When(/^the user designates the departure time as (.*) for leg (.*)$/) do |departure_time, leg_number|
  on_page FlightsPage do |page|
    page.verify_on_flights_page
    page.select_departure_date_time_link leg_number
    page.set_flight_date_time(departure_time, leg_number)
    page.select_calendar_save_link
  end
end

When(/^the user designates the arrival time as (.*) for leg (.*)$/) do |arrival_time, leg_number|
  on_page FlightsPage do |page|
    page.verify_on_flights_page
    page.select_existing_arrival_date_time_link leg_number
    page.set_flight_date_time(arrival_time, leg_number)
    page.select_calendar_save_link
  end
end

When(/^the user selects 'Add return flight'$/) do
  on_page FlightsPage do |page|
    page.verify_on_flights_page
    page.select_add_return_flight_link
  end
end

When(/^the user selects the 'Next: Passengers' button$/) do
  on_page FlightsPage do |page|
    page.verify_on_flights_page
    page.select_add_passengers_button
  end
end

When(/^the user adds two passengers to the reservation$/) do
  on_page PassengersPage do |page|
    page.verify_on_passengers_page
    page.set_passenger_name 'Andy Arena'
    page.select_add_to_flight_button
    page.set_passenger_name 'Rob Higbee'
    page.select_add_to_flight_button
  end
end

When(/^the user selects a lead passenger$/) do
  on_page PassengersPage do |page|
    page.verify_on_passengers_page
    page.select_lead_passenger_list 'Andy Arena', 1
  end
end

When(/^the user selects a contact$/) do
  on_page PassengersPage do |page|
    page.select_booking_agent_radio_button
  end
end

When(/^the user selects a contact number$/) do
  on_page PassengersPage do |page|
    page.select_lead_passenger_radio_button
    page.set_country_number 01
    page.set_area_number 614
    page.set_number 248552
  end
end

When(/^the user selects 'Next: Catering'$/) do
  on_page PassengersPage do |page|
    page.select_catering_button
  end
end

When(/^the user selects 'Next: Ground Transportation'$/) do
  on_page CateringPage do |page|
    page.verify_on_catering_page
    page.select_ground_transportation_button
  end
end

When(/^the user selects 'Next: Review & Request'$/) do
  on_page GroundPage do |page|
    page.verify_on_ground_page
    page.select_review_and_request_button
  end
end

When(/^the user selects 'Request Reservation'$/) do
  on_page ReviewAndRequest do |page|
    page.verify_on_review_and_request_page
    page.select_request_reservation_button
  end
end

Then(/^a new page loads called (.*)$/) do |message|
  on_page ConfirmationPage do |page|
    page.verify_on_confirmation_page
    page.verify_message_exists message
  end
end

Then(/^a reservation number is listed$/) do
  on_page ConfirmationPage do |page|
    page.verify_on_confirmation_page
    page.verify_reservation_number_exists
    #@reservation_number = page.get_reservation_number
    #p @reservation_number
    #page.select_return_to_home_page_button
  end
end

Given(/^the user opens a booked reservation submitted to IJet2$/) do

  #navigate_to(ReviewAndRequest).select_request_reservation_button
  #
  #on_page Confirmation do |page|
  #  page.verify_on_confirmation_page
  #  page.verify_reservation_number_exists
  #  @reservation_number = page.get_reservation_number
  #  p @reservation_number
  #  page.select_return_to_home_page_button
  #end


  on_page HomePage do |page|
    page.verify_on_home_page
    page.select_reservation_submitted_flights 5956544 #5956494#6020274#
    #page.select_reservation_submitted_flights @reservation_number
  end
end

###########################
Then(/^the user opens a booked reservation$/) do
  on_page HomePage do |page|
    page.verify_on_home_page
    #p "Reservation Number is #{@reservation_number}"
    page.select_reservation_submitted_flights @reservation_number
  end
end
###########################

When(/^the user saves the changes$/) do

  on_page FlightsEditPage do |page|
    page.verify_on_flights_page
    page.select_save_exit_button
  end
end

#When(/^the user selects to edit (.+) and (.+) and upgrades the (.+) for leg (.+)$/) do |departure_airport, arrival_airport, aircraft, leg_number|
#
#  on_page RequestedReservationPage do |page|
#    page.verify_on_requested_reservation_page
#    page.select_flight leg_number
#    page.select_edit_flight leg_number
#  end
#  on_page FlightsPage do |page|
#    page.verify_on_flights_page
#    page.select_flight leg_number
#
#    page.set_departure_airport(departure_airport, leg_number)
#    page.set_arrival_airport(arrival_airport, leg_number)
#  end
#end

#When(/^the user selects to edit (.*) as arrival airport for leg (\d+) and saves the changes$/) do |arrival_airport, leg_number|
#  steps %{
#      When  the user selects the #{arrival_airport} as arrival airport for leg #{leg_number}
#      When the user saves the changes
#  }
#
#end

#When(/^the user selects to edit (.*) as arrival airport, modifies the (.*) for leg (\d+) and saves the changes$/) do |arrival_airport, arrival_time, leg_number|
#  steps %{
#      When  the user selects the #{arrival_airport} as arrival airport for leg #{leg_number}
#      When the user designates the arrival time as #{arrival_time} for leg #{leg_number}
#      When the user saves the changes
#  }
#end

Then(/^the changes to (.+) and (.+) and (.+) and (.+) are reflected on the summary page$/) do |aircraft_name, departure_airport_name, arrival_airport_name, arrival_detail_time|
  on_page RequestedReservationPage do |page|
    page.verify_on_requested_reservation_page
    page.select_flight 1
    sleep 5
    page.verify_aircraft_details aircraft_name, 1
    page.verify_departure_airport_details departure_airport_name, 1
    page.verify_arrival_airport_details arrival_airport_name, 1
    page.verify_arrival_airport_details arrival_detail_time, 1
  end
end


When(/^the user selects to edit passengers by removing the existing passenger and adds a new lead passenger with contact details and save the changes for leg 1$/) do
  on_page(RequestedReservationPage).select_edit_passengers 1
  on_page PassengersPage do |page|
    page.verify_on_passengers_page
    page.select_remove_passenger_from_this_flight('Daniel Zukas', 1)

  end
end

#When(/^the user selects to edit departure_airport and saves the changes for leg (.+)$/) do |leg_number|
#
#  on_page(CateringPage) do |page|
#    page.verify_on_catering_page
#    page.select_add_link 1
#    page.select_search_link 1
#
#    table.hashes.each do |data|
#      page.set_search_item data['catering item'], 1
#      page.select_go_link 1
#      page.verify_search_results_message data['message'], 1
#    end
#  end
#
#  on_page RequestedReservationPage do |page|
#    page.verify_on_requested_reservation_page
#    page.select_flight leg_number
#    page.select_edit_flight leg_number
#  end
#  on_page FlightsPage do |page|
#    page.verify_on_flights_page
#    page.select_flight leg_number
#
#    page.set_departure_airport(departure_airport, leg_number)
#    page.set_arrival_airport(arrival_airport, leg_number)
#  end
#
#
#end

When(/^the user selects to edit arrival airport as "([^"]*)" and saves the changes for leg (.+)$/) do |arrival_airport, leg_number|
  on_page RequestedReservationPage do |page|
    page.verify_on_requested_reservation_page
    page.select_flight leg_number
    page.select_edit_flight leg_number
  end
  on_page FlightsEditPage do |page|
    page.verify_on_flights_page
    page.select_flight leg_number
    page.set_arrival_airport(arrival_airport, leg_number)
    page.select_save_exit_button
  end

end

When(/^the user selects to edit departure airport as "([^"]*)" and saves the changes for leg (.+)$/) do |departure_airport, leg_number|
  on_page RequestedReservationPage do |page|
    page.verify_on_requested_reservation_page
    page.select_flight leg_number
    page.select_edit_flight leg_number
  end
  on_page FlightsEditPage do |page|
    page.verify_on_flights_page
    page.select_flight leg_number
    page.set_departure_airport(departure_airport, leg_number)
    page.select_save_exit_button
  end
end

Then(/^the changes for the departure airport is reflected as "([^"]*)" on the summary page for leg (.+)$/) do |departure_airport, leg_number|
  on_page RequestedReservationPage do |page|
    page.verify_on_requested_reservation_page
    page.select_flight leg_number
    page.verify_departure_airport_details departure_airport, leg_number
  end
end

Then(/^the changes for the arrival airport is reflected as "([^"]*)" on the summary page for leg (.+)$/) do |arrival_airport, leg_number|
  on_page RequestedReservationPage do |page|
    page.verify_on_requested_reservation_page
    page.select_flight leg_number
    page.verify_arrival_airport_details arrival_airport, leg_number
  end
end
When(/^the user selects to edit arrival time as (.+) hours and saves the changes for leg (.+)$/) do |arrival_time, leg_number|
  on_page RequestedReservationPage do |page|
    page.verify_on_requested_reservation_page
    page.select_flight leg_number
    page.select_edit_flight leg_number
  end
  on_page FlightsEditPage do |page|
    page.verify_on_flights_page
    page.select_flight leg_number
    page.select_existing_arrival_date_time_link leg_number
    page.set_flight_date_time arrival_time, leg_number
    page.select_calendar_save_link
    page.select_save_exit_button
  end
end

Then(/^the changes for the arrival time is reflected as (.+) on the summary page for leg (.+)$/) do |arrival_detail_time, leg_number|
  on_page RequestedReservationPage do |page|
    page.verify_on_requested_reservation_page
    page.select_flight leg_number
    #page.verify_arrival_airport_details arrival_detail_time, leg_number
    page.verify_arrival_time_details arrival_detail_time, leg_number
  end
end

When(/^the user selects to edit aircraft as "([^"]*)" and saves the changes for leg (.+)$/) do |aircraft_name, leg_number|
  on_page RequestedReservationPage do |page|
    page.verify_on_requested_reservation_page
    page.select_flight leg_number
    page.select_edit_flight leg_number
  end
  on_page FlightsEditPage do |page|
    page.select_flight leg_number
    page.select_change_aircraft 1
    page.select_aircraft_type aircraft_name
    page.select_save_exit_button
  end
end
Then(/^the changes for the aircraft is reflected as "([^"]*)" on the summary page for leg (.+)$/) do |aircraft_name, leg_number|
  on_page RequestedReservationPage do |page|
    page.verify_on_requested_reservation_page
    page.select_flight leg_number
    page.verify_aircraft_details aircraft_name, leg_number
  end
end
When(/^the user removes "([^"]*)" from a reservation from leg (.+)$/) do |passenger_name, leg_number|
  on_page RequestedReservationPage do |page|
    page.verify_on_requested_reservation_page
    page.select_flight leg_number
    page.select_edit_passengers leg_number
  end
  on_page PassengersEditPage do |page|
    #page.select_change_aircraft 1
    page.select_remove_passenger_from_this_flight passenger_name, leg_number
    #page.select_save_exit_button
  end
end

Then(/^the passenger "([^"]*)" is not visible on the summary page for leg (.+)$/) do |passenger_name, leg_number|
  on_page RequestedReservationPage do |page|
    page.verify_on_requested_reservation_page
    page.select_flight leg_number
    page.verify_passengers_not_exists passenger_name, leg_number
  end
end
When(/^the user adds "([^"]*)" to the reservation for leg (.+)$/) do |passenger_name, leg_number|
  on_page RequestedReservationPage do |page|
    page.verify_on_requested_reservation_page
    page.select_flight leg_number
    page.select_edit_passengers leg_number
  end
  on_page PassengersEditPage do |page|
    #page.select_change_aircraft 1
    page.verify_on_passengers_page
    page.set_passenger_name passenger_name
    page.select_add_to_flight_button
    page.select_save_exit_button
  end
end

Then(/^the passenger "([^"]*)" is visible on the summary page for leg (.+)$/) do |passenger_name, leg_number|
  on_page RequestedReservationPage do |page|
    page.verify_on_requested_reservation_page
    page.select_flight leg_number
    page.verify_passengers_exists passenger_name, leg_number
  end
end

When(/^the user changes the lead passenger "([^"]*)" on leg (.+)$/) do |passenger_name, leg_number|
  on_page RequestedReservationPage do |page|
    page.verify_on_requested_reservation_page
    page.select_flight leg_number
    page.select_edit_passengers leg_number
  end
  on_page PassengersEditPage do |page|
    page.verify_on_passengers_page
    page.select_lead_passenger_list passenger_name, leg_number
    page.select_save_exit_button
  end
end

Then(/^the new lead passenger "([^"]*)" is designated on the summary page for leg (.+)$/) do |passenger_name, leg_number|
  on_page RequestedReservationPage do |page|
    page.verify_on_requested_reservation_page
    page.select_flight leg_number
    page.verify_passengers_exists passenger_name+" (lead passenger)", leg_number
  end
end

When(/^the user changes a lead passenger contact on leg (.+)$/) do |leg_number|
  on_page RequestedReservationPage do |page|
    page.verify_on_requested_reservation_page
    page.select_flight leg_number
    page.select_edit_passengers leg_number
  end
  on_page PassengersEditPage do |page|
    page.verify_on_passengers_page
    #page.select_lead_passenger_list passenger_name, leg_number
    page.select_booker_contact_number_list "Office 1 313 1381967", leg_number
    page.select_save_exit_button
  end
end

Given(/^the user is viewing Basic Information$/) do
  on_page HomePage do |page|
    page.verify_on_home_page
    page.select_header_profile_link
  end
  on_page ProfilePage do |page|
    page.verify_on_profile_page
    page.select_basic_information_link
    #page.verify_bi_basic_information 'Ms. ELENA ANNE FORD'
    #page.verify_bi_basic_information '5/25/1966'
    #page.verify_bi_basic_information 'Female'
    #
    #page.select_bi_edit_button
    #page.set_bi_first_name "Ravi"
    #page.set_bi_middle_name "K"
    #page.set_bi_last_name "Chandaluri"
    #page.set_bi_date_of_birth "08/07/1981"
    #
    #page.set_bi_prefix 'Mr.'
    #page.set_bi_suffix 'IV'
    #page.set_bi_gender 'Unspecified'
  end
end
Given(/^the user is viewing Phone Numbers$/) do
  on_page HomePage do |page|
    page.verify_on_home_page
    page.select_header_profile_link
  end
  on_page ProfilePage do |page|
    page.verify_on_profile_page
    page.select_phone_numbers_link
    ##page.select_pn_delete_by_type_button "1.208.1381969"
    #page.select_pn_edit_by_type_button "Office Fax"
    #page.set_pn_type "Hotel"
    #page.set_pn_country_code 91
    #page.set_pn_area_code  040
    #page.set_pn_telephone 2487052413
    #page.set_pn_telephone_ext 100    #sleep 3
    #page.select_pn_cancel_link

    page.verify_pn_phone_numbers "1.313.13819660"

  end

end