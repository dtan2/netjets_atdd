When(/^owner search for a pet$/) do
  navigate_to(PassengersPage)
  Session[:pet] = 'Sundance'

  on(PassengersPage) do |page|
    page.addPassengerName = Session[:pet]
    page.wait_for_predictive_search
    page.wait_for_ajax_loader
    page.search_result_elements[0].click
    page.addToFlight
    page.wait_for_ajax
  end
end

Then(/^owner found the pet$/) do
  on(PassengersPage) do |page|
  data = page.get_passenger_list
  expect(data[0]).to include Session[:pet]
  end
end

When(/^owner search for a decease pet$/) do
  navigate_to(PassengersPage)
  Session[:pet] = 'Chili'

  on(PassengersPage) do |page|
    page.addPassengerName = Session[:pet]
    page.wait_for_predictive_search
    page.wait_for_ajax_loader
    # page.search_result_elements[0].click
    # page.addToFlight
    # page.wait_for_ajax
    end
end

Then(/^owner can not find the pet$/) do
  on(PassengersPage) do |page|
    data = page.search_result_elements[0].text
    expect(data).to eq 'No person found with that name'
  end
end

#red robin
#Melinda Tharp
When(/^owner search for a inactive person$/) do
  navigate_to(PassengersPage)
  Session[:person] = 'Melinda Tharp'

  on(PassengersPage) do |page|
    page.addPassengerName = Session[:person]
    page.wait_for_predictive_search
    page.wait_for_ajax_loader
  end
end

Then(/^owner can not find the person$/) do
  step 'owner can not find the pet'
end


#red robin
#setup two Kim Lee with middle initial

When(/^owner searches a person with same first and last name$/) do
  navigate_to(PassengersPage)
  Session[:person] = 'Kim Lee'

  on(PassengersPage) do |page|
    page.addPassengerName = Session[:person]
    page.wait_for_predictive_search
    page.wait_for_ajax_loader
  end
end

Then(/^owner will see the middle initial of the searched person$/) do

  on(PassengersPage) do |page|
    data = page.search_result_elements[0].text.split(/\n/)
    expect(data[0]).to eq 'Kim K Lee (Kim Lee)'
    expect(data[1]).to eq 'Kim M Lee (Kim Lee)'
  end

end