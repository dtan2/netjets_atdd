When(/^I am creating a new reservation$/) do
  navigate_to(FlightsPage, using: :default)
  on(FlightsPage) do | page |
    @contracted_aircraft = page.get_selected_contracted_aircraft_type
    page.upgrade_aircraft_type
    page.submit
  end
  on(PassengersPage).go_to_flights_page
  @route_path = :default
end

When(/^I cancel changing from my contracted aircraft type$/) do
  on(FlightsPage).cancel_aircraft_regrade
  on(FlightsPage).submit
end

Then(/^My contracted aircraft type is used in my flight request$/) do
  continue_navigation_to(ReviewAndRequest, using: @route_path)
  expect(@contracted_aircraft).to eq(on(ReviewAndRequest).get_requested_aircraft_type)
end

Given(/^I am editing a reservation$/) do
  navigate_to(FlightsPage, using: :edit_flights)
  on(FlightsPage) do | page |
    @contracted_aircraft = page.get_selected_contracted_aircraft_type
    page.upgrade_aircraft_type
    page.submit
  end
  @route_path = :edit_flights
end

Given(/^a user is creating a new reservation$/) do
  visit_page(LoginPage) do |page|
    page.username = 't.olofson@any.domain.cc'
    page.password = 'abc123ABC'
    page.login
  end

  on(HomePage).new_reservation

  on(FlightsPage) do |page|
    page.select_aircraft_type('CITATION EXCEL')
    page.set_departure_airport('CMH',1)
    page.set_arrival_airport('TEB',1)
    page.hours_until_departure_time(50,1,'NJA')
  end

end

When(/^a user upgrades their aircraft type$/) do
  Session[:aircraft] = 'GULFSTREAM 450'
  on(FlightsPage).upgrade_aircraft_type(Session[:aircraft],1)
  sleep 2
end

Then(/^the contracted aircraft is upgraded to the newly selected aircraft$/) do
  actual_aircraft = on(FlightsPage).get_aircraft_type_for_leg(1)
  expect(actual_aircraft).to eq(Session[:aircraft])
end