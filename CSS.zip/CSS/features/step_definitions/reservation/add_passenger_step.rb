Given(/^a booking agent is logged in$/) do
  navigate_to(LoginPage)
  on(LoginPage).login_application_with(:user_with_multiple_accounts)
  on(HomePage).verify_on_home_page
  on(HomePage).bookFlight

end

Given(/^a reservation has (.*) of flights$/) do |number|
  navigate_to(LoginPage)
  on(LoginPage).login_application_with(:user_with_multiple_accounts)
  on(HomePage).verify_on_home_page
  on(HomePage).bookFlight


  case number

    when '1'
      @new_name = "Sam"

      on(FlightsPage) do |page|

        page.set_req_data_for_multi_flight_reservation(1)
        page.wait_for_loading_overlay
      end

    when '3'
      @new_name = "Jenny"

      on(FlightsPage) do |page|
        page.set_req_data_for_multi_flight_reservation(3)

      end

    when '8'
      @new_name = "Moe"

      on(FlightsPage) do |page|
        page.set_req_data_for_multi_flight_reservation(8)

      end

    when '12'
      @new_name = "Moe"

      on(FlightsPage) do |page|
        page.set_req_data_for_multi_flight_reservation(12)


      end

    else
      nil

  end

end

When(/^I add an existing passenger$/) do

on(PassengersPage) do |page|
    page.verify_on_passengers_page
    page.set_passenger_name 'Tom Walton'
    page.select_add_to_flight_button
    page.wait_for_loading_overlay
    @new_passenger = 'Tom Walton'
  end


end

Then(/^the existing passenger is added to all flights$/) do

  on(PassengersPage) do |page|

    page.validate_passenger_in_list(@new_passenger, leg_number='all')
  end

end

When(/^I add a new passenger$/) do

  on(PassengersPage) do |page|

    page.verify_on_passengers_page
    @new_passenger = page.add_new_passenger_to_account @new_name
    page.wait_for_ajax
  end


end

Then(/^the new passenger is added to all flights$/) do

  on(PassengersPage) do |page|

    page.validate_passenger_in_list(@new_passenger, leg_number='all')
  end

end

When(/^I add an unknown passenger$/) do

  on(PassengersPage) do |page|

    page.verify_on_passengers_page
    @new_unknown = page.set_unknown_passenger
    page.wait_for_loading_overlay
    page.wait_for_ajax_loader

  end

end

Then(/^a unknown passenger is added to all flights$/) do

  on(PassengersPage) do |page|

    page.validate_passenger_in_list(@new_unknown, leg_number='all')

  end
end

Given(/^I am on the passengers screen$/) do
  navigate_to(PassengersPage)
end

When(/^I add each unknown passenger type$/) do |table|
  @seat_left = []
  @passenger_list =[]
  table.hashes.each do |item|

    on(PassengersPage) do |page|
      page.wait_for_ajax
      page.verify_on_passengers_page
      new_passenger = page.set_unknown_passenger item['passenger_type']
      page.wait_for_loading_overlay
      page.wait_for_ajax_loader
      @seat_left << page.get_number_of_seat_left
      @passenger_list << new_passenger
    end
  end

end

Then(/^Each unknown passenger type is added to the reservation$/) do

  #loop through the array
  for passenger in @passenger_list

    on(PassengersPage) do |page|

      page.validate_passenger_in_list(passenger, leg_number='all')


    end
  end
end

When(/^I add more passengers than the remaining capacity$/) do

  passenger_arry=["Alysa Levine", "John Rowe", "Hep Ingham", "Patricia Cooper", "Eric Houseman", "Stephen Carly",
                  "Brad Clawson", "Ron Levine", "Jeff Neely"]

  for passenger in passenger_arry

    on(PassengersPage) do |page|
      page.verify_on_passengers_page
      page.set_passenger_name passenger
      page.wait_for_ajax_loader
      page.select_add_to_flight_button
      page.wait_for_loading_overlay
      page.wait_for_ajax_loader
    end
  end

end

Then(/^I see a message advising me that the flight is overcapacity$/) do
  seat_info = on(PassengersPage).get_seats_info
  expect(seat_info[1]).to eq "1 passenger overcapacity"
end

And(/^I should still be able to proceed with my reservation$/) do

  on(PassengersPage) do |page|
    page.wait_for_loading_overlay
    page.nextCatering
    page.wait_for_loading_overlay

  end

  on(CateringPage).verify_on_catering_page
end

Given(/^I am editing the Passengers of a submitted reservation$/) do

  navigate_to(ReviewAndRequest)
  on(ReviewAndRequest).requestReservation
  on(ConfirmationPage).verify_on_confirmation_page
  on(ConfirmationPage).viewPrintItinerary
  on(RequestedReservationPage).verify_on_requested_reservation_page
  on(RequestedReservationPage).edit_passenger
  on(RequestedReservationPage).wait_for_loading_overlay
  @new_name = "Eric3"
end

And(/^I add a known pet$/) do

  on(PassengersPage) do |page|
    page.verify_on_passengers_page
    page.set_passenger_name 'Sundance'
    page.select_add_to_flight_button
    page.wait_for_loading_overlay

  end

end

And(/^I add a known passenger$/) do

  on(PassengersPage) do |page|
    page.verify_on_passengers_page
    page.set_passenger_name 'Alysa Levine'
    page.select_add_to_flight_button
    page.wait_for_loading_overlay

  end

end


Then(/^the passenger is added to the reservation$/) do

  passenger_list =["Eric Houseman", "Hep Ingham"]
  passenger_list << @new_passenger
  passenger_list << @new_unknown
  for passenger in passenger_list
    on(PassengersPage).validate_passenger_in_list(passenger, leg_number='all')
  end

end


Given(/^I have a lead passenger with a contact person$/) do
  navigate_to(CateringPage)
  on(CateringPage).wait_for_loading_overlay
  on(CateringPage).select_back_button
  on(PassengersPage).wait_for_ajax
end

When(/^I want to update the contact person's existing contact number$/) do

  on(PassengersPage) do |page|
    page.select_booker_contact_number_list('Boat 65 556 472147856', 1)
    page.select_booker_contact_number_list('Office 1 567 34789723', 2)

  end

end

Then(/^the selected number appears with the contact person$/) do

  on(PassengersPage) do |page|
    num = page.get_booker_contact
    expect(num).to eq 'Boat 65 556 472147856'
    num_2 = page.get_booker_contact 2
    expect(num_2).to eq 'Office 1 567 34789723'

  end
end

When(/^I select "([^"]*)" for a contact person$/) do |arg|

  on(PassengersPage) do |page|
    page.select_booker_contact_number_list arg
    page.select_booker_contact_number_list arg, 2
  end
end

And(/^enter a number$/) do

  on(PassengersPage) do |page|
    page.wait_for_ajax_loader
    page.set_country_number_booker("60")
    page.set_area_number_booker("513")
    page.set_number_booker("5556789")
    page.wait_for_ajax_loader
    page.set_country_number_booker("012", 2)
    page.set_area_number_booker("570", 2)
    page.set_number_booker("9991345", 2)

  end


end

Then(/^the new number appears with the contact person$/) do


  num_1 = on(PassengersPage).get_contact_another_num_booker(1)
  num_2 = on(PassengersPage).get_contact_another_num_booker(2)


  fail "Wrong booker contact phone number" unless num_1 =="605135556789"
  fail "Wrong booker contact phone number" unless num_2 =="0125709991345"

end

When(/^select lead passenger as contact$/) do

  on(PassengersPage) do |page|
    page.wait_for_ajax
    page.select_lead_passenger_radio_button
    page.select_lead_contact_number_list('Another number')
    page.wait_for_ajax_loader
    page.select_lead_passenger_radio_button (2)
    page.select_lead_contact_number_list('Another number', 2)

  end

end


And(/^enter a lead contact$/) do

  on(PassengersPage) do |page|
    page.wait_for_ajax_loader
    page.set_country_number_lead("60")
    page.set_area_number_lead("513")
    page.set_number_lead("5556789")
    page.wait_for_ajax_loader
    page.set_country_number_lead("012", 2)
    page.set_area_number_lead("570", 2)
    page.set_number_lead("9991345", 2)

  end


end

Then(/^lead contact number appears$/) do

  num_1 = on(PassengersPage).get_contact_num_lead(1)
  num_2 = on(PassengersPage).get_contact_num_lead(2)

  fail "Wrong booker contact phone number" unless num_1 =="605135556789"
  fail "Wrong booker contact phone number" unless num_2 =="0125709991345"

end

Then(/^the remaining seats decreases by one each passenger$/) do
  reference =["7", "6", "5"]
  expect(@seat_left).to eq reference
end

Then(/^the remaining the same$/) do
  expect(@seat_left[0]).to eq '8'
end

When(/^I add passengers to exhaust the regular seats$/) do
  #loop 7 times
  7.times do

    on(PassengersPage) do |page|
      page.verify_on_passengers_page
      page.set_unknown_passenger "Adult"
      page.wait_for_loading_overlay
      page.wait_for_ajax_loader

    end


  end


end

Then(/^Remaining seating capacity is (\d+) and a Lavatory Seat warning appears$/) do |arg|

  data = on(PassengersPage).get_seats_info(1)
  expect(data[1]).to eq '1(lav seat) remaining'
end

And(/^navigating to the flight page.$/) do

  on(PassengersPage).wait_for_loading_overlay

  @data_1st = on(PassengersPage).get_passenger_list(1)
  @data_2nd = on(PassengersPage).get_passenger_list(2)
  on(PassengersPage).back

end

Then(/^the passenger still added in the reservation$/) do

  on(FlightsPage).wait_for_ajax
  on(FlightsPage).verify_on_flights_page
  on(FlightsPage).wait_until do
    on(FlightsPage).addReturnFlight_element.when_visible
  end
  on(FlightsPage).addPassengers_element.when_present.click
  on(PassengersPage).verify_on_passengers_page
  on(PassengersPage).wait_for_loading_overlay
  data1= on(PassengersPage).get_passenger_list(1)
  data2= on(PassengersPage).get_passenger_list(2)

  fail "Passenger no longer in the 1st reservation" unless @data_1st == data1

  fail "Passenger no longer in the 2nd reservation" unless @data_2nd == data2

end

And(/^not providing a contact$/) do

  on(PassengersPage) do |page|
    page.wait_for_ajax
    page.select_lead_passenger_radio_button
    page.wait_for_ajax_loader

  end

end

Then(/^not able to navigate to the flight page.$/) do

  on(PassengersPage).wait_for_loading_overlay
  on(PassengersPage).back

  fail "There is no error message" unless on(PassengersPage).error_banner_element.visible?

end


Then(/^I may designate any known passenger\(non-pet\) as lead$/) do

  on(PassengersPage) do |page|
    passenger_list = page.get_lead_passenger_list
    expect(passenger_list).not_to include 'Sundance'
    expect(passenger_list).not_to include 'Child'
  end
end

When(/^I am on the passenger_page screen for a (.*)$/) do |reservation_state|

  case reservation_state

    when 'new wip reservation'
      navigate_to(PassengersPage)
    when 'edit wip reservation'
      navigate_to(ReviewAndRequest)
      on(ReviewAndRequest).wait_for_ajax
      on(ReviewAndRequest).edit_elements[1].click


    when 'edit submitted reservation'

      navigate_to(ReviewAndRequest)
      on(ReviewAndRequest).wait_for_loading_overlay
      on(ReviewAndRequest).requestReservation
      on(ConfirmationPage).verify_on_confirmation_page
      on(ConfirmationPage).viewPrintItinerary
      on(RequestedReservationPage).verify_on_requested_reservation_page
      on(RequestedReservationPage).edit_elements[1].click

    else
      nil
  end
end

Then(/^I am able to add a passenger$/) do

  on(PassengersPage) do |page|
    page.verify_on_passengers_page
    page.wait_for_ajax
    page.set_passenger_name 'Alysa Levine'
    page.select_add_to_flight_button
    page.wait_for_loading_overlay
    page.validate_passenger_in_list('Alysa Levine', leg_number='all')
  end
end