Given(/^I have unpaid invoices$/) do
  # invoice with amount less than a credit memo (login, invoice #, credit memo #)
  # invoice with amount greater than a credit memo (login, invoice #, credit memo #)
  # multiple invoices and multiple credit memos
  @smaller_invoice = 1111
  @larger_credit_memo = 2222
  @larger_invoice = 3333
  @smaller_credit_memo = 4444
  @smallest_credit_memo = 5555
  login_as(Login::USERWITHUNPAIDINVOICES)
  @initial_credit = credit_memo(@credit_memo_number).balance
end


When(/^I partially use a credit memo$/) do
  on(PaymentsInvoicesPage).select_invoice(@smaller_invoice )
  on(PaymentsInvoicesPage).select_invoice(@larger_credit_memo)
  pay_with_credit_memo
  expect(payment_confirmation_number).to include ''
end


Then(/^the credit memo balance is updated$/) do
  #new credit memo balance = old balance minus invoice amount due
  expect(on(UnpaidInvoicePage).credit_memo.balance).to eq (@initial_credit - invoice.due_amount)
  delete_unprocessed_payments
end


When(/^I fully use a credit memo$/) do
  on(PaymentsInvoicesPage).select_invoice(@larger_invoice)
  on(PaymentsInvoicesPage).select_invoice(@smaller_credit_memo)
  pay_with_credit_memo
  expect(payment_confirmation_number).to include ''
end


Then(/^the credit memo balance is (\d+)$/) do | balance |
  expect(on(UnpaidInvoicePage).credit_memo.balance).to eq balance
  delete_unprocessed_payments
end


When(/^I use multiple credit memos$/) do
  @credit_memo_dates = get_invoice_dates(@smaller_credit_memo, @smallest_credit_memo)
  on(PaymentsInvoicesPage).select_invoice(@larger_invoice)
  on(PaymentsInvoicesPage).select_invoice(@smaller_credit_memo)
  on(PaymentsInvoicesPage).select_invoice(@smallest_credit_memo)
  pay_with_credit_memo
  expect(payment_confirmation_number).to include ''
end


Then(/^the oldest credit memos are used up first$/) do
  oldest_credit_memos = get_older(@credit_memo_dates)
  newest_credit_memo = get_newest(@credit_memo_dates)
  credit_memos = on(PaymentsInvoicesPage).collect_data_for('Invoice #')
  expect(credit_memos.sort).not_to include oldest_credit_memos.sort
  expect(credit_memos).to include newest_credit_memo
  delete_unprocessed_payments
end


When(/^I pay multiple invoices with credit memos$/) do
  @invoice_dates = get_invoice_dates(@smaller_credit_memo, @smallest_credit_memo)
  on(PaymentsInvoicesPage).select_invoice(@smaller_invoice)
  on(PaymentsInvoicesPage).select_invoice(@larger_invoice)
  on(PaymentsInvoicesPage).select_invoice(@smallest_credit_memo)
  on(PaymentsInvoicesPage).select_invoice(@smaller_credit_memo)
  on(PaymentsInvoicesPage).select_invoice(@larger_credit_memo)
  pay_with_credit_memo
  expect(payment_confirmation_number).to include ''
end


Then(/^the oldest invoices are paid first$/) do
  older_invoices = get_older(@invoice_dates)
  newest_invoice = get_newest(@invoice_dates)
  credit_memos = on(PaymentsInvoicesPage).collect_data_for('Invoice #')
  expect(credit_memos.sort).not_to include older_invoices.sort
  expect(credit_memos).to include newest_invoice
  delete_unprocessed_payments
end


When(/^I pay with a credit memo and bank account$/) do
  on(PaymentsInvoicesPage).select_invoice(@larger_invoice)
  on(PaymentsInvoicesPage).select_invoice(@smaller_credit_memo)
  pay_with_credit_memo_and_bank_account
  expect(payment_confirmation_number).to include ''
end

And(/^the authorization is stored in the NetJets database$/) do
  delete_unprocessed_payments
  pending
end

And(/^the invoices are paid$/) do
  delete_unprocessed_payments
  pending
end