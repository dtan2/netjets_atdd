Given(/^I create an internal Miscellaneous invoice without an outstanding balance in IJet2$/) do
  Session[:invoice_num] = 1234009
  pending 'validation needs added to verify invoice number exists in the database'
  login_as(Login::USERWITHUNPAIDINVOICES)
end