#TODO: build logic to drive steps
Given(/^I add an autopay for a contract's (.*) invoices$/) do |type|
  @autopay_details = {contract: '1388930',
                      invoice_type: type,
                      bank_account: 'Oberbrunner, Lowe an ...8427',
                      aircraft: 'HS-125-800XPC',
                      tail: 'N880QS'}
end

When(/^I accept the autopay terms and conditions$/) do
  login_as(Login::USERWITHUNPAIDINVOICES)
  select_autopays_to_enroll(@autopay_details)
  @terms_and_conditions = accept_terms_and_conditions
  @autopay_page = on(ManageAccountsPage).get_autopays
  on(ManageAccountsPage).add_autopay
  @add_autopay_page = on(AutopaySetupPage).get_autopays
end

Then(/^autopay is scheduled for that contract's (.*) invoices$/) do |type|
  expect(@autopay_page).to include @autopay_details
  expect(@add_autopay_page).to include @autopay_details
  expect(TermsAndConditions.terms).to eq @terms_and_conditions
  on(ManageAccountsPage).remove_autopay(@autopay_details[:contract], type)
end

When(/^I add an autopay for all invoice types on a contract$/) do |table|
# table is a table.hashes.keys # => [:Invoice Types]
  login_as(Login::USERWITHUNPAIDINVOICES)
  add_autopay_for_all_invoice_types(@contract)
  @autopay_page = on(ManageAccountsPage).get_autopays
  on(ManageAccountsPage).add_autopay
  @add_autopay_page = on(AutopaySetupPage).get_autopays
  table.rows.each do | row |
    on(ManageAccountsPage).remove_autopay(@autopay_details[:contract], row)
  end
end

Then(/^an autopay is scheduled for each invoice type and contract combination$/) do
  expect(@autopay_page).to include @autopay_details
  expect(@add_autopay_page).to include @autopay_details
end

When(/^I delete an autopay for a contract's (.*) invoices$/) do |type|
  on(ManageAccountsPage).remove_autopay(@autopay_details[:contract], type)
  @autopay_page = on(ManageAccountsPage).get_autopays
  on(ManageAccountsPage).add_autopay
  @add_autopay_page = on(AutopaySetupPage).get_autopays
  on(AutopaySetupPage).invoice_page
  @invoice_status = on(UnpaidInvoicePage).invoice_table_element["Status"][10].text
end

Then(/^the autopay is no longer scheduled for that contract's (.*) invoices$/) do |type|
  expect(@autopay_page).not_to include @autopay_details
  expect(@add_autopay_page).not_to include @autopay_details
  expect(Autopay.termination_date).to eq Date.today
  expect(@invoice_status).not_to eq 'Autopay'
end

Given(/^I setup an autopay as an individual$/) do
  @autopay_details = {contract: '', invoice_type: type, bank_account: '', aircraft: '', tail: ''}
  login_as(Login::USER1ACCOUNTA)
  enroll_in_autopay(@autopay_details)
end

When(/^I view those autopay details as a different individual$/) do
  login_as(Login::USER2ACCOUNTA)
  goto_autopay
  @autopay = on(ManageAccountsPage).get_autopay(@autopay_details[:contract], @autopay_details[:invoice_type])
  on(ManageAccountsPage).add_autopay
  @autopay2 = on(AutopaySetupPage).get_autopay(@autopay_details[:contract], @autopay_details[:invoice_type])
end

Then(/^I am unable to see that Autopay's bank account details$/) do
  expect(@autopay[:bank_account]).not_to satisfy { |text| text.match(/...\d\d\d\d/) }
  expect(@autopay2[:bank_account]).not_to satisfy { |text| text.match(/...\d\d\d\d/) }
end

Given(/^the individual who did not initiate a scheduled autopay is logged in$/) do
  @autopay_details = {contract: '', invoice_type: type, bank_account: '', aircraft: '', tail: ''}
  login_as(Login::USER1ACCOUNTA)
  enroll_in_autopay(@autopay_details)
  login_as(Login::USER2ACCOUNTA)
end

When(/^the individual tries to delete an autopay they did not initiate$/) do
  goto_autopay
end

Then(/^the scheduled autopay is not deleted$/) do
  expect(on(ManageAccountsPage).delete_autopay.visible?).to eq false
end

When(/^the individual cancels autopay setup$/) do
  @autopay_details = {contract: '', invoice_type: type, bank_account: '', aircraft: '', tail: ''}
  login_as(Login::USERWITHUNPAIDINVOICES)
  goto_autopay
  on(ManageAccountsPage).add_autopay
  @message1 = on(AutopaySetupPage).cancel_autopay_setup
  select_autopays_to_enroll(@autopay_details)
  @message2 = on(AutopayTermsPage).cancel_autopay_setup
end

Then(/^a message will display canceling autopay enrollment$/) do
  expect(@message1).to eq 'Autopay cancelled'
  expect(@message2).to eq 'Autopay cancelled'
end

When(/^an owner views the terms and conditions$/) do
  @autopay_details = {contract: '', invoice_type: type, bank_account: '', aircraft: '', tail: ''}
  login_as(Login::USERWITHUNPAIDINVOICES)
  goto_autopay
  on(ManageAccountsPage).add_autopay
  select_autopays_to_enroll(@autopay_details)
  @terms_and_conditions = on(AutopayTermsPage).terms_and_conditions
end

Then(/^they will view the following text$/) do |text|
  expect(@terms_and_conditions).to eq text
end