# require_relative '../pages/owner_portal/online_payment/billing_and_great_plains_sync_page'

Given(/^I designate a (.*) date range of (.*) to (.*)$/) do |scenario, from_date, to_date|
  visit(BillingAndGreatPlainsSyncPage) do |page|
    page.from_date(send(from_date))
    page.to_date(send(to_date))
  end
end

When(/^I sync the data$/) do
  on(BillingAndGreatPlainsSyncPage).sync
end

Then(/^Invoices last modified within the date range are updated$/) do
  on(BillingAndGreatPlainsSyncPage).dates_synced.each do |date|
    expect(date).to be_between(@date_from, @date_to)
  end
end

