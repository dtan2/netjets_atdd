class LoginPage
  include PageObject
  include DataMagic
  require_relative "../../../features/support/global_settings"
  include GlobalSettings

  DataMagic.yml_directory = "features/support/page_input_data"
  # DataMagic.load('css_login.yml')

  text_field(:userName, :id => 'UserName')
  # text_field(:username, :id => 'UserName')
  text_field(:userPassword, :id => 'Password')
  # text_field(:password, :id => 'Password')
  button(:signIn, :value => 'Sign in')
  # button(:login, :value => 'Sign in')
  button(:new_account, :value => 'Create New Account')
  div(:error_msg,:id=>'validationSummary')
  div(:error_banner,:class=>'errors show clear')
  page_url(select_login_url('op_login'))

  #****************************************
  # Main Methods
  #****************************************

  def verify_on_login_page
    verify_on_page('LogOn')
  end

  def set_user_name (map)
    #userName_element.when_visible.set map['username']
    self.userName = map['username']
  end

  def set_user_password (map)
    #userPassword_element.when_visible.set map['password']
    self.userPassword = map['password']
  end

  def select_sign_in_button
    signIn_element.when_visible(small_wait).click
  end

  def verify_
    signIn_element.when_visible(small_wait).click
  end

  #def login_application_with(data={})
  #  verify_on_login_page()
  #  populate_page_with data_for(:user_with_multiple_accounts, data)
  #  signIn
  #end

  def login_application_with(data=:red_robin_account_long)
    DataMagic.load('css_login.yml')
    navigate_to(select_login_url('op_login'))
    verify_on_login_page()
    populate_page_with data_for(data)
    signIn
    begin
      signIn
    rescue
      puts 'second sign in click'
    end
    end

  def open_self_enroll_page
    #new_account
    #@browser.goto TEST_ENVIRONMENT_URL + '/Account/Enroll'
    # @browser.goto(select_login_url('op_enroll'))
    navigate_to(select_login_url('op_enroll'))
  end

  def login_as(user)
    wait_until{self.signIn_element.visible?}
    self.userName = user
    self.userPassword = 'abc123ABC'
    wait_for_ajax
    self.signIn

  end



end