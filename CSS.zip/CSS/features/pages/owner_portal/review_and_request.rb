class ReviewAndRequest
  include PageObject
  require_relative "../../../features/support/global_settings"
  include GlobalSettings


  button(:requestReservation, :class => 'btn btn6 next-step')
  button(:submit_reservation, value: 'Submit your flight')
  span(:flightsPageWIP, :class => 'flights')
  divs(:aircraftReviewSections, :class => 'section aircraft clear')
  divs(:aircraftTypes, :class => 'text clear')
  divs(:block, :class => 'reservation-block clear')
  div(:loadingOverlay, :class => 'curtain')
  links(:edit, :class => 'edit btn')
  unordered_lists(:legs, :class => 'flight-list')
  divs(:flights, :class => 'flight-details')
  #****************************************
  # Main Methods
  #****************************************

  def verify_on_review_and_request_page
    verify_on_page("Summary")
  end

  def gather_time_nje_time_format(leg_num=1)
    legs_elements[leg_num-1].text.split(/\n/)
  end

  def select_request_reservation_button
    wait_for_ajax
    self.requestReservation_element.when_present.click
    verify_on_page("Confirmation")
  end

  def select_flights_page_link
    flightsPageWIP_element.click
    loadingOverlay_element.wait_until_present
    loadingOverlay_element.wait_while_present
  end

  def validate_aircraft_type(aircraft_type, leg_number)
    fail 'unexpected aircraft type' unless @browser.div(:class => 'section aircraft clear', :index => leg_number-1).
        div(:class => 'text clear').text == aircraft_type
  end

  def validate_departure_airport(departure_airport, leg_number)
    fail 'unexpected departure airport' unless @browser.div(:class => 'section departure clear', :index => leg_number-1).
        p(:class => 'airport').text[0, 3] == departure_airport

  end

  def validate_arrival_airport(arrival_airport, leg_number)
    fail 'unexpected arrival airport' unless @browser.div(:class => 'section arrival clear', :index => leg_number-1).
        p(:class => 'airport').text[0, 3] == arrival_airport
  end

  def validate_departure_time(leg_number, hours)
    departure_time = (Time.now + (hours*60*60)).strftime "%FT%T%:z"
    fail 'unexpected departure time' unless @browser.div(:class => 'section arrival clear', :index => leg_number-1).
        p(:class => 'time').text == departure_time.text[11, 5]
  end

  def gather_rental_dropoff_FBO(leg_num=1)
    wait_for_ajax_loader
    fbo_temp= self.flights_elements[leg_num-1].div_element(:class => 'reservation-block clear', :index => 3).text.split(/Rental car 1/)
    rental_info = fbo_temp[1]
    rental_temp = rental_info.gsub(/\d|:|AM|PM|\n/, "").split(",").map { |dropoff_fbo| dropoff_fbo.strip }
    return rental_temp[2]
  end

  def gather_arrival_airport_FBO(leg_num=1)
    wait_for_ajax_loader
    self.flights_elements[leg_num-1].paragraph_element(:class => 'fbo', :index => 1).text
  end

  def gather_departure_airport_FBO (leg_num=1)
    self.flights_elements[leg_num-1].paragraph_element(:class => 'fbo').text
  end


  #def get_passenger_list
  #
  #  summary_passenger_list = []
  #
  #
  #
  #end


end