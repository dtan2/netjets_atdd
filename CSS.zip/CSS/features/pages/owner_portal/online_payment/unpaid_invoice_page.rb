=begin
This monkey patch...
=end
module PageObject

  module Accessors
    def row(name, identifier={:index => 0}, &block)
      standard_methods(name, identifier, 'row_for', &block)
    end
  end

  module Platforms
    module WatirWebDriver
      class PageObject
        def row_for(identifier)
          call = call_for_watir_element(identifier, "tr(identifier)")
          find_watir_element(call, Elements::TableRow, identifier)
        end
      end
    end
  end
end

=begin
possibly shares behavior with UnpaidInvoicePage

UnpaidInvoicePage describes the actions that can be performed on the page and the objects that exist on the page
This page shows the list of unpaid invoices and allows payments to be made on them
=end

class UnpaidInvoicePage
  include PageObject
  include Watir
  include InvoicesHeader

  link(:manage_accounts, :text => 'Manage Accounts')
  link(:auto_pay, :text => 'Add a new account')
  select_list(:table_page, xpath: '//*[@id="invoicesTable_paginate"]/div/select')

  indexed_property(:invoices, [
      [:row, :containing_row, :xpath => '//*[@id="invoicesTable"]/tbody/tr[%s]'],
      [:label, :choose, :xpath => '//*[@id="invoicesTable"]/tbody/tr[%s]/td[1]/label'],
      [:cell, :date, :xpath => '//*[@id="invoicesTable"]/tbody/tr[%s]/td[2]'],
      [:cell, :number, :xpath => '//*[@id="invoicesTable"]/tbody/tr[%s]/td[4]'],
      [:cell, :invoice_type, :xpath => '//*[@id="invoicesTable"]/tbody/tr[%s]/td[5]'],
      [:cell, :due, :xpath => '//*[@id="invoicesTable"]/tbody/tr[%s]/td[9]'],
      [:cell, :status, :xpath => '//*[@id="invoicesTable"]/tbody/tr[%s]/td[10]']
  ])

  table(:invoice_table, id: 'invoicesTable')
  button(:continue, :value => 'Continue')

  def continue
    scroll_to_page_body
    continue_element.click
  end

  def scroll_to_page_body
    @browser.execute_script("window.scrollTo(0,document.body.scrollHeight)")
  end

  def select_payable_invoice
    scroll_to_page_body
    invoices.each do |invoice|
      if invoice_is_payable(invoice)
        invoice.choose_element.click
        return invoice
      end
    end
  end

  def select_payable_invoice_type(type)
    table_page_options.each do |next_page|
      scroll_to_page_body
      self.table_page= next_page
      invoices.each do |invoice|
        if invoice_is_payable(invoice) && invoice.invoice_type == type
          scroll_to_page_body
          invoice.choose_element.click
          return invoice
        end
      end
    end
  end

  def invoice_is_payable(invoice)
    (invoice.due? && invoice.due[1..-1].to_f > 0) &&
        invoice.choose? &&
        (invoice.status? && invoice.status.strip.empty?) &&
        !invoice.containing_row_element.class_name.include?('selected')
  end

  def invoice_numbers
    invoices_on_page = Array.new
    table_page_options.each do |next_page|
      self.table_page= next_page
      invoices.each do |invoice|
        invoices_on_page << invoice.number
      end
    end
    invoices_on_page.flatten
  end


  def select_not_payable_invoice(amount)
    selected_invoice = invoices.select do |invoice|
      invoice.due == amount && invoice.choose? && invoice.status.trim ==""
    end

    selected_invoice.check_choose

    selected_invoice

  end

  def can_continued
    continue_element.enabled?
  end

  def select_multiple_payable_invoices(number_of_invoices = 3)
    (0...number_of_invoices).collect do |i|
      select_payable_invoice
    end


  end

  def collect_data_for(column)
    column_data = Array.new
    self.table_page_options.each do |next_page|
      self.table_page = next_page
      column_data << row_data_for(column)
      column_data.flatten!
    end
    column_data
  end

  def row_data_for(column)
    rows = self.invoice_table_element[0..-2].collect do |invoice|
      invoice["#{column}"].text
    end
    rows.shift
    rows
  end

  def sort_by(column)
    fail "Unable to find column named #{column}" unless self.invoice_table_element[0].text.include? column
    invoice_table_element[0].find { |cell| cell.text.include? column }.click
  end


  def all_invoice_numbers
    invoices_on_page = Array.new
    self.table_page_options.each do |next_page|
      self.table_page= next_page
      (self.invoices_element.map { |invoice| invoice[3].text.to_i }).each do |invoice_num|
        invoices_on_page << invoice_num
      end
    end
    invoices_on_page
  end

  def all_invoice_types
    invoice_types_displayed = Array.new
    self.table_page_options.each do |next_page|
      self.table_page= next_page
      self.invoices.each { |invoice| invoice_types_displayed << invoice.invoice_type }
    end

    invoice_types_displayed = invoice_types_displayed.flatten.uniq.sort
    invoice_types_displayed
  end

  def invoice_headers

    (invoice_table_element[0].map {|header| header.text})[1..-2]

  end

end
