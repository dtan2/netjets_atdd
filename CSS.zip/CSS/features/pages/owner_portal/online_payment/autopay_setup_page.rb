class AutopaySetupPage
  include PageObject

  button(:continue, value: 'Continue')
  table(:autopay_grid, class: 'autopay-selection')
  select_list(:bank_account, id: 'account-selection-dd')

  def setup_autopay_for(contract, invoice_type)
    autopay_grid_element.find{|row| row.text.include? contract}["#{invoice_type}"].click
  end
end