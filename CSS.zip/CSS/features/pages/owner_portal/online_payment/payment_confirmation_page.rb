=begin
PaymentConfirmationPage describes the actions that can be performed on the page and the objects that exist on the page
This page shows the list of Paid Invoices
=end
class PaymentConfirmationPage
  require_relative '../modules/top_menu_header'

  include PageObject
  include TopMenuHeader

  paragraph(:account, xpath: '//div[@class = "row"][1]/div[@class = "col"][2]/p')
  paragraph(:date, xpath: '//div[@class = "row"][2]/div[@class = "col"][2]/p')
  paragraph(:amount, xpath: '//div[@class = "row"][3]/div[@class = "col"][2]/p')
  paragraph(:confirmation_number, xpath: '//div[@class = "row"][4]/div[@class = "col"][2]/p')



  def confirmation_details
    details = PaymentConfirmationDetails.new
    details.account = self.account
    details.date = self.date
    details.amount = self.amount
    details.confirmation_number = self.confirmation_number

    details
  end

end

=begin
PaymentConfirmationDetails allows access to the Payment confirmation Details attributes
=end
class PaymentConfirmationDetails
  attr_accessor :account, :date, :amount, :confirmation_number
end