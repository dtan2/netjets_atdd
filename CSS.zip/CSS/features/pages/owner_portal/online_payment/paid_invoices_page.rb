=begin
PaidInvoicesPage describes the actions that can be performed on the page and the objects that exist on the page
This page shows the list of Paid Invoices
=end
class PaidInvoicesPage
  include PageObject
  include InvoicesHeader
  select_list(:table_page, xpath: '//*[@id="invoicesTable_paginate"]/div/select')
  table(:invoices, id: 'invoicesTable')

  indexed_property(:invoices, [
      [:cell, :number, class: ' invoice-no'],
      [:cell, :due, class: ' due']

  ])

  def invoice_numbers_and_amounts
    invoices_on_page = Array.new
    table_page_options.each do |next_page|
      self.table_page= next_page
      invoices_on_page << invoices_element.map { |row| {number: row['Invoice #'].text.delete('$,').to_f, due: row['Due'].text} }
    end
    invoices_on_page
  end

  # def invoice_numbers_and_amounts
  #   invoices_on_page = Array.new
  #   table_page_options.each do |next_page|
  #     self.table_page= next_page
  #     invoices.each do |i|
  #       invoices_on_page << {:number => i.number, :due => i.due}
  #     end
  #   end
  #   invoices_on_page.flatten
  # end


end