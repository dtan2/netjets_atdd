=begin
AutoPayPage describes the actions that can be performed on the page and the objects that exist on the page
This page is where Automatic Payments can be managed
=end
class AutoPayPage
  include PageObject

  link(:add_new_account, :text => 'Add a new account')

  def payment_account_numbers
      bank_account.collect


    account_blocks.collect  do |account_block|
      account_block.account_number
    end
  end

  def account_added_message
    # get message
    messages_box.collect do |message_box|
      message_box.message
    end
  end

end