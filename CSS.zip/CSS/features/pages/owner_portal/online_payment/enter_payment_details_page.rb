=begin
EnterPaymentDetailsPage describes the actions that can be performed on the page and the objects that exist on the page
This page is the step in the payment process where payment details are input, i.e. amount, date
=end

require 'date'

class EnterPaymentDetailsPage
  include PageObject

  button(:continue, :text => 'Continue')
  link(:add_account, class: 'add-account-link')
  select_list(:added_bank_accounts, id: 'account-selection-dd')
  label(:payment_date, id: 'payment-date')
  span(:selected_invoice_amount, id: 'spnSelectedInvoice')
  span(:all_invoices_amount, id: 'spnTotalInvoice')
  label(:payment_type_selected_invoices, xpath: '//label[@for="paymentOption"]')
  label(:payment_type_total_invoices, xpath: '//label[@for="paymentOption_1"]')
  label(:payment_type_custom_amount, xpath: '//*[@id="paymentOption_2"]/../label')
  text_field(:custom_payment_amount, id: 'PaymentCustomAmount')
  div(:error_container, class: 'errors show clear')

  indexed_property(:invoices, [
      [:cell, :number, :xpath => '//*[@id="invoicesSelectedTable"]/tbody/tr[%s]/td[4]']
  ])


  def find_selected_invoice_amount
    selected_invoice_amount.delete('$,').to_f
  end

  def pay_on_next_day
    self.payment_date = (Date.today + 1).to_s
    payment_date
  end

  def pay_selected_invoices
    payment_type_selected_invoices_element.click
    selected_invoice_amount
  end

  def payment_type_custom_amount
    payment_type_custom_amount_element.click
  end

  def payment_type_custom_amount=(value)
    payment_type_custom_amount_element.click
    self.custom_payment_amount = value
  end

  def payment_details(payment_selection = :selected)
    payment_details = Hash.new
    payment_details[:date] = payment_date
    payment_details[:account] = added_bank_accounts
    payment_details[:invoices] = selected_invoices
    payment_details[:amount] = get_payment_amount_for(payment_selection)
    payment_details
  end

  #accepted parameters = :selected, :all, or :custom
  def get_payment_amount_for(payment_selection)
    if payment_selection == :selected
      selected_invoice_amount
    elsif payment_selection == :all
      all_invoices_amount
    elsif payment_selection == :custom
      custom_payment_amount
    else
      raise Exception.new("Unexpected payment_selection of #{payment_selection}")
    end
  end

  def selected_invoices
    selected_invoices = Array.new
    invoices.each do | invoice |
      selected_invoices << invoice.number
    end
    selected_invoices
  end
end