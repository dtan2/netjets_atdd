class AutopayTermsPage
  include PageObject

  button(:continue, value: 'Continue')
  button(:cancel, text: 'Cancel')
  label(:accept_terms, class: 'fancy-check')
  div(:terms_and_conditions, class: 'terms-container')

  def accept_terms_check
    scroll_to_page_body
    accept_terms_element.click
  end
  # alias_method(:accept_terms_uncheck, :accept_terms_check)

  def scroll_to_page_body
    @browser.execute_script("window.scrollTo(0,document.body.scrollHeight)")
  end

end