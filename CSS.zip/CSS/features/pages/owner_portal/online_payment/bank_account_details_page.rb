=begin
possibly shares behavior with ManageAccountsPage

BankAccountDetailsPage describes the actions that can be performed on the page and the objects that exist on the page
This page is where Bank Accounts can be managed
=end

class BankAccountDetailsPage
  include PageObject
  include DataMagic

  DataMagic.yml_directory = "features/support/page_input_data"
  DataMagic.load('bank_account_details.yml')

  text_field(:routing_number, id: 'bankAccount_input_rtn')
  text_field(:bank_account_number, id: 'bankAccount_input_accountNumber')
  text_field(:bank_account_number_confirm, id: 'bankAccount_input_accountNumberConfirm')
  text_field(:bank_account_nickname, id: 'bankAccount_input_nickName')
  radio_button_group(:bank_account_type, name: 'accountType')
  radio_button_group(:bank_account_category, name: 'accountCategory')
  button(:submit, id: 'submit')
  button(:cancel, id: 'cancel')
  div(:page_error, class: 'pageerror')



  def submit_bank_account_details(bank_account_details = nil)
    _add_bank_acct_details_template(bank_account_details) do
      self.submit
    end
  end

  def cancel_add_bank_acct_details(bank_account_details = nil)
    _add_bank_acct_details_template(bank_account_details) do
      self.cancel
    end
  end

  def _add_bank_acct_details_template(bank_account_details)
    wait_for_ajax
    DataMagic.load('bank_account_details.yml')
    _bank_account_details = bank_account_details || data_for(:valid_bank_account_details)
    bank_account = populate_page_with(_bank_account_details)

    self.bank_account_number_confirm = self.bank_account_number
    yield

    return bank_account
  end



  def cancel_bank_account_details
    DataMagic.load('bank_account_details.yml')
    populate_page_with data_for :valid_bank_account_details

    self.reenter_bank_account_number = self.bank_account_number
    self.check_savings
    self.check_business
    self.cancel

  end

end