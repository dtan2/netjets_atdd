=begin
ConfirmSubmitPaymentPage describes the actions that can be performed on the page and the objects that exist on the page
This page is the step in the payment process where payment details can be confirmed and submitted
=end
class ConfirmSubmitPaymentPage
  include PageObject


  label(:terms, xpath: '//*[@id="agree-terms-and-conditions-checkbox"]/../label')
  button(:continue, :text => 'Continue')

  def accept_terms_authorize_payment
    scroll_to_page_body
    terms_element.click
  end

  def scroll_to_page_body
    @browser.execute_script("window.scrollTo(0,document.body.scrollHeight)")
  end

end