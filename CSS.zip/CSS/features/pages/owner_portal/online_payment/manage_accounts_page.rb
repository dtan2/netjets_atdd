=begin
possibly shares behavior with BankAccountDetailsPage

ManageAccountsPage describes the actions that can be performed on the page and the objects that exist on the page
This page is where Bank Accounts can be managed
=end

class ManageAccountsPage
  include PageObject

  button(:add_account, :text => 'Add Account')

  def payment_account_numbers
    #collect the accounts from the blocks on the page
    account_blocks.collect  do |account_block|
      account_block.account_number
    end
  end

  def account_added_message
    # get message
    messages_box.collect do |message|
      message.message
    end
  end

end