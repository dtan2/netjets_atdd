class ReservationNotes
  include PageObject
  include GlobalSettings

 link(:add_reservation_note,:id=>'reservation-edit-notes')
 text_field(:notes,:id=>'notes')
 link(:clear,:id=>'clear-note')
 link(:save,:id=>'save-note')

  def create_reservation_note notes
  wait_for_ajax_loader
  self.notes_element.append "\n #{notes}"
  save
  wait_for_ajax_loader
  end

  def verify_reservation_notes notes

    notes_element.value.should include notes
  end
end