class AccountBasicDetailsPage < ProfilePage

  include PageObject
  require_relative "../../../features/support/global_settings"
  include GlobalSettings
  include TopMenuHeader
  include ProfileAccount

  link(:account, :text => 'Account')
  link(:ac_balance, :text => 'Aircraft & Balance')
  link(:preference, :text => 'Preferences')
  link(:account_address, :id => 'accountAddresses')
  link(:emergency_contact, :id => 'emergencyContacts')
  div(:emergency_section, :id => 'emergencyContacts')
  div(:emergency_entry,:class=>'edit-mode edit-open')
  link(:edit_emergency) { |page| page.emergency_section_element.link_element(:class => 'btn btn1 edit') }
  div(:emergency_data) { |page| page.emergency_section_element.div_element(:class => 'preview-mode clear') }
  link(:edit, :class => 'btn btn1 edit')
  link(:add_new, :class => 'btn btn1 none add-new', :text => 'Add New')
  link(:contact_delete, :class => 'btn btn2 delete', :text => 'Delete')
  link(:delete_continue, :class => 'btn btn1 none continue', :text => 'Continue')
  text_field(:contact_name, :id => 'contact-name')
  text_field(:contact_country_code, :id => 'phone-country')
  text_field(:contact_area_code, :id => 'phone-area')
  text_field(:contact_tel_num, :id => 'phone-tel')
  text_field(:contact_ext, :id => 'phone-ext')
  span(:save, :text => 'Save', :index => 1)
  div(:principals, :class => 'field', :index => 1)
  div(:account_page, :class => 'account-page')

  def verify_in_account_page()
    verify_on_page("Account/BasicDetails")
  end

  def get_all_account_address()
    add_count = @browser.dds(:class => 'type').count
    acc_addresses=[]

    for all_account_addresses in 2..(add_count+2-1)
      acc_addresses_temp = @browser.div(:class => 'preview-mode clear', :index => all_account_addresses).text.split("\n")
      #acc_addresses << acc_addresses_temp[1] + acc_addresses_temp[-1]
      acc_addresses << "#{acc_addresses_temp[1] }#{acc_addresses_temp[-1]}"
    end

    return acc_addresses
  end

  def select_emergency_type(type)
    wait_until{save_element.visible?}
    emergency_entry_element.span_element(:class => 'fancy-select-general-value').click
    emergency_entry_element.unordered_list_element(:class => 'fancy-select-general-ul open').list_item_element(:text => type).when_visible.click
  end


  def compare_account_address(text)
    gui_address = get_all_account_address
    #fail "Address and account type not matching" unless gui_address.map{|x| x.delete(" ")}.include? text.delete(" ")
    fail "Address #{text } is not matching any of the addresses displayed - #{gui_address}" unless gui_address.map { |account_address| account_address.delete(" ") }.include? text.delete(" ")
  end

  def select_contract(contract_num)

    count = @browser.divs(:class => 'contract-details clear').count

    for contract in 0..count-1

      if @browser.div(:class => 'contract-details clear', :index => contract).text.include? contract_num

        index = contract

        break
      end
    end

    return index
  end

  def validate_contract_type(contract_type, contract_num)
    expect(account_page_element.text).to include contract_type
    expect(account_page_element.text).to include contract_num
  end

  def gather_emergency_type
  emergency_data_element.dd_elements[1].when_visible.text
  end

end