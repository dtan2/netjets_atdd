class ProfilePage
  include PageObject
  require_relative "../../../features/support/global_settings"
  include GlobalSettings
  require_relative 'modules/top_menu_header'
  include TopMenuHeader
  include ProfileAccount


  #some of the share element is in the ProfileAccount module
  link(:basicInformation, :text => 'Basic Information')
  link(:phoneNumbers, :text => 'Phone Numbers')
  link(:emailAddresses, :text => 'Email Addresses')
  link(:mailingAddresses, :text => 'Mailing Addresses')
  link(:internationalInformation, :text => 'International Information')
  link(:passportsAndVisas, :text => 'Passports & visas')
  link(:profile, :text => 'Profile')
  link(:preferences, :text => 'Preferences')
  link(:add_new, :class => 'btn btn1 none more-space add-new')
  #Basic Information
  links(:biEdit, :class => 'btn btn1 edit')
  link(:biSave, :class => 'btn btn1 none save')
  link(:biCancel, :class => 'btn btn12 cancel')
  links(:delete_fbo, :class => 'btn btn2 delete')
  text_field(:biFirstName, :id => 'basic-firstname')
  text_field(:biMiddleName, :id => 'basic-middlename')
  text_field(:biLastName, :id => 'basic-lastname')
  text_field(:biMonth, :id => 'basic-dobM')
  text_field(:biDay, :id => 'basic-dobD')
  text_field(:biYear, :id => 'basic-dobY')
  text_field(:manifest_name, :id => 'basic-manifest-name')
  text_field(:airport, :id => 'location-name')
  spans(:select_drop, :class => 'fancy-select-general-value')
  span(:fbo_select, :class => 'fancy-select-general clear')
  span(:fbo_exist, :class => 'fancy-select-general-value', :text => /NetJets Preferred/)
  ul(:drop_down, :class => 'fancy-select-general-ul open')
  div(:airport_results, :class => 'predictive-results')
  div(:profile_summary, :class => 'preview-mode clear')
  divs(:fbo_preference, :class => 'entry')
  link(:pnAddNew, :class => 'btn btn1 none add-new')
  link(:continue, :class => 'btn btn1 none continue')
  link(:pnSave, :class => 'btn btn1 none save', :index => 1)
  link(:pnCancel, :class => 'btn btn12 cancel', :index => 1)
  text_field(:pnPhoneCountry, :id => 'phone-country')
  text_field(:pnPhoneArea, :id => 'phone-area')
  text_field(:pnPhoneTel, :id => 'phone-tel')
  text_field(:pnPhoneExt, :id => 'phone-ext')
  dd(:phone_summary, :class => 'telephone')
  # Email Addresses Methods

  # Mailing Addresses Methods

  # International Information Methods

  # Passports & Visas Methods


  #****************************************
  # Main Methods
  #****************************************

  def verify_on_profile_page
    @browser.wait_until(large_wait, "Profile page has not loaded") do
      @browser.text.include? 'Profile'
    end
  end


  def select_basic_information_link
    basicInformation_element.when_visible(small_wait).click
  end

  def select_phone_numbers_link
    phoneNumbers_element.when_visible(small_wait).click
  end

  def select_email_addresses_link
    emailAddresses_element.when_visible(small_wait).click
  end

  def select_mailing_addresses_link
    mailingAddresses_element.when_visible(small_wait).click
  end

  def select_international_information_link
    internationalInformation_element.when_visible(small_wait).click
  end

  #****************************************
  # Basic Information Methods
  #****************************************

  def select_bi_edit_button
    biEdit_elements[0].when_visible(small_wait).click
    sleep 2
  end

  def select_bi_save_button
    biSave_element.when_visible(small_wait).click
    wait_for_loading_overlay
    wait_for_ajax_loader
  end

  def select_bi_cancel_link
    biCancel_element.when_visible(small_wait).click
  end

  def select_airport(airport)
    self.airport_element.clear
    self.airport_element.when_present.type airport
    airport_results_element.when_visible
    airport_results_element.list_item_elements.each do |list_of_airports|
      if list_of_airports.text[0, 3] == airport
        list_of_airports.click
        break
      end
    end
  end

  def select_fbo_usage(preference)
    self.select_drop_elements[0].click
    self.drop_down_element.list_item_element(:text => preference).click
  end

  def select_fbo(prefer_fbo)
    fbo_exist_element.when_visible
    fbo_select_element.click
    drop_down_element.list_item_element(:text => /#{prefer_fbo}/).click
  end


  def add_fbo_preference (airport, pereference='Always use', fbo)
    self.add_new_element.click
    wait_for_ajax_loader
    select_airport airport
    wait_for_ajax_loader
    select_fbo_usage pereference
    wait_for_ajax_loader
    select_fbo fbo

  end

  def select_edit_fbo(airport)

    fbo_preference_elements[1].link_element(:class => 'btn btn1 edit').should be_visible
    fbo_preference_elements.each_with_index do |list_of_fbos, index_value|
      if list_of_fbos.text.include? airport
        fbo_preference_elements[index_value].link_element(:class => 'btn btn1 edit').click
        return index_value
        break
      end
    end
  end

  def edit_fbo_preference(airport, new_airport, pereference, fbo)
    index = select_edit_fbo airport
    wait_for_ajax_loader
    biSave_element.when_visible
    select_airport new_airport
    wait_for_ajax_loader
    select_fbo_usage pereference
    wait_for_ajax_loader
    select_fbo fbo
    return index
  end

  def select_delete_fbo(airport)
    wait_for_ajax_loader
    fbo_preference_elements[1].link_element(:class => 'btn btn2 delete').should be_visible
    fbo_preference_elements.each_with_index do |list_of_fbos, index_value|

      if list_of_fbos.text.include? airport
        fbo_preference_elements[index_value].link_element(:class => 'btn btn2 delete').click
        return index_value
        break
      end
    end
    wait_for_ajax_loader
  end

  def delete_all_fbo_preference
    wait_for_ajax_loader
    delete_fbo_elements.each do |fbo_preferences|
      fbo_preferences.click
      wait_for_ajax_loader
      self.continue
      sleep 1
    end
  end


  def set_bi_first_name(firstName)
    self.biFirstName = firstName
  end

  def set_bi_middle_name(middleName)
    self.biMiddleName = middleName
  end

  def set_bi_last_name(lastName)
    self.biLastName = lastName
  end

  def set_bi_date_of_birth(dateOfBirth)
    dob = dateOfBirth.split("/")
    self.biMonth = dob.at(0) #month
    self.biDay = dob.at(1) #day
    self.biYear = dob.at(2) #year
    return dateOfBirth
  end

  def set_profile_prefix(prefix)
    self.select_drop_elements[0].click
    self.drop_down_element.list_item_element(:text => prefix).click
    return prefix
  end

  def set_profile_suffix(suffix)
    self.select_drop_elements[1].click
    self.drop_down_element.list_item_element(:text => suffix).click
    return suffix
  end


  def set_bi_prefix(prefixValue)
    @browser.span(:class => 'fancy-select-general-inner', :index => 0).click

    listOfNames = @browser.ul(:class => 'fancy-select-general-ul', :index => 0)
    listOfNames.when_present.lis.each do |names|
      if names.text.downcase == prefixValue.downcase
        names.click
        break
      end
    end
  end

  def set_bi_suffix(suffixValue)
    @browser.span(:class => 'fancy-select-general-inner', :index => 1).click

    list_of_names = @browser.ul(:class => 'fancy-select-general-ul', :index => 1)
    list_of_names.when_present.lis.each do |names|
      if names.text.downcase == suffixValue.downcase
        names.click
        break
      end
    end
  end

  def set_bi_gender(genderValue)
    @browser.span(:class => 'fancy-select-general-inner', :index => 2).click

    list_of_names = @browser.ul(:class => 'fancy-select-general-ul', :index => 2)
    list_of_names.when_present.lis.each do |names|
      if names.text.downcase == genderValue.downcase
        names.click
        break
      end
    end
  end

  def verify_bi_basic_information(textToVerify)
    basic_info = @browser.div(:class => 'preview-mode clear')
    fail "#{textToVerify} is not displayed under the Basic Information section" unless basic_info.when_present.text.include? textToVerify
  end

  def gather_profile_basic_info
    wait_for_ajax_loader
    basic_info = self.profile_summary_element.text.split("\n")
    return basic_info
  end


  #****************************************
  # Phone Numbers Methods
  #****************************************
  def select_pn_add_new_button
    pnAddNew_element.when_visible(small_wait).click
    sleep 1
  end

  def select_pn_edit_by_type_button(typeOrNum)
    phone_number = @browser.dls(:class => "clear").count

    for index_value in 1..phone_number-6
      if @browser.dl(:class => "clear", :index => index_value).text.include? typeOrNum
        @browser.link(:class => 'btn btn1 edit', :index => index_value).click #The index starts from 1
        sleep 1
        return
      end
    end

  end

  def select_pn_delete_by_type_button(typeOrNum)
    phone_number = @browser.dls(:class => "clear").count

    for index_value in 1..phone_number-6
      if @browser.dl(:class => "clear", :index => index_value).text.include? typeOrNum
        @browser.link(:class => "btn btn2 delete", :index => i-1).click #The index starts from 0
        select_dlg_delete_entry_continue()
                                                                        #select_dlg_delete_entry_cancel()
        return
      end
    end

  end

  def select_dlg_delete_entry_continue
    @browser.div(:class => "confirm-delete modal-window").link(:class => "btn btn1 none continue").click
  end

  def select_dlg_delete_entry_cancel
    @browser.div(:class => "confirm-delete modal-window").link(:class => "btn btn9 none cancel").click
  end

  def select_pn_save_button
    pnSave_element.when_visible(small_wait).click
    sleep 1
  end

  def select_pn_cancel_link
    pnCancel_element.when_visible(small_wait).click
  end

  def set_pn_type(typeValue)
    @browser.span(:class => 'fancy-select-general-value', :index => 3).click

    list_of_phone_types = @browser.ul(:class => 'fancy-select-general-ul', :index => 3)
    list_of_phone_types.when_present.lis.each do |names|
      if names.text.downcase == typeValue.downcase
        names.click
        break
      end
    end
  end

  def set_pn_country_code(countryCode)
    self.pnPhoneCountry = countryCode
  end

  def set_pn_area_code(areaCode)
    self.pnPhoneArea = areaCode
  end

  def set_pn_telephone(telNum)
    self.pnPhoneTel = telNum
  end

  def set_pn_telephone_ext(telExt)
    self.pnPhoneExt = telExt
  end


  def verify_pn_phone_numbers(typeOrNum)
    phone_number = @browser.dls(:class => "clear").count

    for index_value in 1..phone_number-7
      if @browser.dl(:class => "clear", :index => index_value).text.include? typeOrNum
        bolStatus = "True"
        break
      end
    end

    if bolStatus != "True"
      fail "#{typeOrNum} is not displayed under the Phone Number section"
    end

  end

  def set_manifest_name(manifest_name)
    self.select_bi_edit_button
    self.wait_for_ajax_loader
    self.manifest_name = manifest_name
    self.biSave
    self.wait_for_loading_overlay
  end

  class FboPreference
    attr_accessor :usage, :airport, :fbo
  end

  def fbo_preference(index = 1)
    biEdit_elements[0].when_visible
    usage = fbo_preference_elements[index].span_element(:class => /use-preference/).text
    airport = fbo_preference_elements[index].span_element(:class => 'location-name').text
    fbo = fbo_preference_elements[index].span_element(:class => 'provider-name').text

    pre = FboPreference.new
    pre.usage = usage
    pre.airport = airport
    pre.fbo = fbo
    return pre

  end

end


#****************************************
# Email Addresses Methods
#****************************************

#****************************************
# Mailing Addresses Methods
#****************************************

#****************************************
# International Information Methods
#****************************************

#****************************************
# Passports & Visas Methods
#****************************************




