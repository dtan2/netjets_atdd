class PassengersEditPage < PassengersPage

  def verify_on_flights_edit_page
    verify_text_exists("Edit passengers")
  end

  def select_save_exit_button
    sleep 3
    #@browser.span(:text=>'Save & Exit').click
    @browser.link(:class => 'btn btn3 next-step add-catering').click
    verify_on_page("RequestedReservation")
  end
end
