class CompleteEnrollmentSecurityPage
  include PageObject
  require_relative "../../../features/support/global_settings"
  include GlobalSettings
  require 'rspec'

  text_field(:security_answer_field, :id => 'SecretAnswer')
  button(:submit_answer_button, :type => 'submit')

  def verify_on_page
    @browser.text.should include 'Answer your security question'
  end

  def submit_security_enrollment_answer_as(answer = Session[:answer])
    security_answer_field_element.when_visible(12)
    self.security_answer_field = answer
    self.submit_answer_button
  end

end