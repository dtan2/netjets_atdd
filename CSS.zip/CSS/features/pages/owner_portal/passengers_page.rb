class PassengersPage
  include PageObject
  require_relative "../../../features/support/global_settings"
  include GlobalSettings
  include TopMenuHeader



  link(:addToFlight, :class => 'btn btn6 add-passenger')
  link(:nextCatering, :class => 'btn btn3 next-step add-catering')
  link(:skipToGroundTransportation, :class => 'btn btn10 next-step add-ground')
  link(:skipToReviewAndRequest, :class => 'btn btn10 next-step', :index => 1)
  link(:back, :class => 'btn btn13 next-step back')
  link(:savePassenger, :class => 'btn btn3 next-step')
  li(:flights, :class => 'first done')
  link(:new_person, :class => 'btn btn2', :index => 1)
  link(:unknown_person, :class => 'btn btn2', :index => 0)
  link(:Confirm, :class => 'btn btn6 add-passenger', :index => 1)
  link(:cancel,:class=>'btn btn11')
  link(:remove,:class => 'remove remove-passenger')

  text_field(:addPassengerName, :id => 'passengersInput')
  text_field(:first_name, :id => 'first-name')
  text_field(:last_name, :id => 'last-name')
  text_field(:manifest_name, :id => 'manifest-name')
  text_field(:MM, :id => 'dobM')
  text_field(:DD, :id => 'dobD')
  text_field(:YYYY, :id => 'dobY')
  divs(:search_result,:class => 'predictive-results')
  div(:error_msg, :class => 'error')
  div(:addPassenger, :class => 'predictive-results show')
  div(:duplicate_error, :class => 'modal duplicate-person')
  div(:loadingOverlay, :class => 'curtain')
  div(:removePassenger, :class => 'remove-passenger-confirmation-overlay confirmation-overlay modal-window')
  div(:unknown_overlay,:class=>'form clear')
  div(:lead_passenger,:class=>'lead-passenger-head clear show')
  div(:error_banner,:class=>'error-msgs')
  divs(:flight_leg,:class=>'flight clear')
  divs(:contact,:class=>'contact reveal-group')
  divs(:passenger_leg,:class=>'passengers clear')
  divs(:lead_passenger_leg,:class=>'lead-passenger clear')
  ul(:drop_down,:class=>'fancy-select-general-ul open')
  ul(:all_leg,:class=>'flight-list')
  ul(:passenger_list, :class => 'passenger-list')
  #span(:leadPassenger,:class=>'fancy-select-general-value')
  select_list(:contactsList, :id => 'contact-booker-numbers-0')
  radio_button(:bookingAgent, :id => 'contact-booker-0')




  @@passengerManifest = Array.new


  #****************************************
  # Main Methods
  #****************************************

  def verify_on_passengers_page
    verify_on_page('Passengers')
  end

  def gather_passenger_flight_info (leg_num=1)
    flight_leg_elements[leg_num-1].text.split(/\n/)
    end

  def set_passenger_name(passengerName)

    self.addPassengerName_element.type passengerName,0.3
    wait_until{search_result_elements[0].visible?}
    find_passenger_in_results passengerName
  end

  def select_add_to_flight_button
    wait_for_ajax
    addToFlight_element.click
    wait_for_ajax
  end

  def get_default_lead_passenger(leg_num=1)
    wait_for_ajax
    lead_passenger_temp =lead_passenger_leg_elements[leg_num-1].span_element(:class => 'fancy-select-general-value').text.split(' ')
    lead_passenger = "#{lead_passenger_temp [0]} #{lead_passenger_temp[-1]}"
    return lead_passenger
  end

  def get_lead_passenger_list(leg_num=1)
   wait_for_ajax
   lead_passenger_leg_elements[leg_num-1].span_element(:class => 'fancy-select-general-value').click
   wait_for_ajax
   list_of_names = lead_passenger_leg_elements[leg_num-1].unordered_list_element(:class => 'fancy-select-general-ul')
    return list_of_names.text
  end

 def select_default_lead_passenger (leg_num=1)
   lead_passenger_leg_elements[leg_num-1].span_element(:class => 'fancy-select-general-value').when_present.click
   wait_for_ajax
   lead_passenger_leg_elements[leg_num-1].unordered_list_element.list_item_elements[1].when_present.click
 end


  def select_lead_passenger_list (passengerName, leg_num =1)

    lead_passenger_leg_elements[leg_num-1].span_element(:class => 'fancy-select-general-value').when_present.click
    wait_for_ajax
    list_of_names = lead_passenger_leg_elements[leg_num-1].unordered_list_element(:class => 'fancy-select-general-ul')
    list_of_names.list_item_element(:text=> passengerName).click

  end

  def select_booking_agent_radio_button (leg_num=1)
    var = leg_num-1
    lead_passenger_leg_element[leg_num-1].radio_button(:id => "contact-booker-#{var}").click
    # sleep 2
  end

  def select_booker_contact_number_list(contactdetails, leg_num =1)
    wait_for_ajax
    lead_passenger_leg_elements[leg_num-1].span_element(:class => 'fancy-select-general-value',:index=>1).click
    wait_for_ajax
    list_of_numbers = lead_passenger_leg_elements[leg_num-1].unordered_list_element(:class => 'fancy-select-general-ul',:index=>1)
    wait_for_ajax
    list_of_numbers.list_item_element(:text=> contactdetails).click
    end

  def select_lead_passenger_radio_button (leg_num =1)

    lead_passenger_leg_elements[leg_num-1].radio_button_element(:id => "contact-lead-#{leg_num-1}").click
  end

  def select_lead_contact_number_list(contactdetails, leg_num =1)
    wait_for_ajax
    lead_passenger_leg_elements[leg_num-1].span_element(:class => 'fancy-select-general-value',:index=>2).click
    wait_for_ajax
    list_of_numbers = lead_passenger_leg_elements[leg_num-1].unordered_list_element(:class => 'fancy-select-general-ul',:index=>2)
    wait_for_ajax
    list_of_numbers.list_item_element(:text=> contactdetails).click
   end


  #Use for 2 legs only

  def set_country_number_booker(countryNumber,leg_num=1)
    leg_order_number = leg_num-1
    country_number_booker ="country-0#{leg_order_number}"
    lead_passenger_leg_elements[leg_num-1].text_field_element(:id => country_number_booker).value = countryNumber
  end

  def set_area_number_booker (areaNumber, leg_num =1)
    leg_order_number = leg_num-1
    area_number_booker ="area-0#{leg_order_number}"
    lead_passenger_leg_elements[leg_num-1].text_field_element(:id => area_number_booker).value = areaNumber

  end

  def set_number_booker (number, leg_num =1)
    leg_order_number = leg_num-1
    number_booker ="number-0#{leg_order_number}"
    lead_passenger_leg_elements[leg_num-1].text_field_element(:id =>number_booker).value = number
  end

  def set_country_number_lead (countryNumber,leg_num=1)
    leg_order_number = leg_num+10-1
    country_number_lead ="country-#{leg_order_number}"
    lead_passenger_leg_elements[leg_num-1].text_field_element(:id => country_number_lead).value = countryNumber

  end

  def set_area_number_lead (areaNumber, leg_num =1)
    leg_order_number = leg_num+10 -1
    area_number_lead ="area-#{leg_order_number}"
    lead_passenger_leg_elements[leg_num-1].text_field_element(:id => area_number_lead).value = areaNumber
  end

  def set_number_lead (number, leg_num =1)
    leg_order_number = leg_num+10-1
    number_lead ="number-#{leg_order_number}"
    lead_passenger_leg_elements[leg_num-1].text_field_element(:id =>number_lead).value = number

  end

  def get_contact_another_num_booker(leg_num =1)

    leg_order_number = leg_num-1
    contact_another_country_booker ="country-0#{leg_order_number}"
    country_booker = lead_passenger_leg_elements[leg_num-1].text_field_element(:id => contact_another_country_booker).value

    #area_1 = leg_num-1
    contact_another_area_booker ="area-0#{leg_order_number}"
    area_booker = lead_passenger_leg_elements[leg_num-1].text_field_element(:id => contact_another_area_booker).value

    #num_1 = leg_num-1
    get_another_number_booker ="number-0#{leg_order_number}"
    num_booker =lead_passenger_leg_elements[leg_num-1].text_field_element(:id =>get_another_number_booker).value

    contact_num_booker ="#{country_booker}#{area_booker}#{num_booker}"

    return contact_num_booker
  end

  def get_booker_contact(leg_num =1)
  self.lead_passenger_leg_elements[leg_num-1].span_element(:class=>'fancy-select-general-value',:index=>1).text
  end

  def get_contact_num_lead(leg_num =1)

    leg_order_number = leg_num+10-1
    country_lead ="country-#{leg_order_number}"
    country_booker = lead_passenger_leg_elements[leg_num-1].text_field_element(:id => country_lead).value

    #area_1 = leg_num+10-1
    area_lead ="area-#{leg_order_number}"
    area_booker = lead_passenger_leg_elements[leg_num-1].text_field_element(:id => area_lead).value

    #num_1 = leg_num+10-1
    number_lead ="number-#{leg_order_number}"
    num_booker =lead_passenger_leg_elements[leg_num-1].text_field_element(:id =>number_lead).value

    contact_num_lead ="#{country_booker}#{area_booker}#{num_booker}"

    return contact_num_lead
  end

  def get_seats_info (leg_num =1)
  passenger_leg_elements[leg_num-1].div_element(:class=>'seats').text.split(/\n/)
 end

 def get_number_of_seat_left (leg_num =1)
   data = passenger_leg_elements[leg_num-1].div_element(:class=>'seats').text.split(/\n/)
   seat_left = data[1].split(' ')
   return seat_left[0]
 end

  def select_catering_button
    #@browser.div(:class => 'curtain').wait_while_present
    loadingOverlay_element.when_not_visible
    nextCatering_element.click
  end

  def select_skip_to_ground_transportation_button
    skipToGroundTransportation_element.when_visible(small_wait).click
    #verify_on_page("Ground")
  end

  def select_skip_to_review_and_request_button
    skipToReviewAndRequest_element.when_visible(small_wait).click
    #verify_on_page("Ground")
  end

  def select_back_button
    back_element.when_visible(small_wait).click
    #verify_on_page("Ground")
  end

  def select_remove_passenger_from_this_flight (passengerName, leg_number=1)
    wait_until(10){passenger_leg_elements[leg_number-1].link_element(:class=>'remove remove-passenger').visible?}
    # totalPassengerCount = get_number_of_passengers(leg_number)
    remove_passenger(passengerName, leg_number)
    select_dlg_rtp_from_this_flight()

  end


  def select_dlg_rtp_from_this_flight
    @browser.div(:class => "remove-passenger-confirmation-overlay confirmation-overlay modal-window", :index => 1).link(:text => "From this flight").click
  end

  def select_dlg_rtp_from_entire_reservation
    @browser.div(:class => "remove-passenger-confirmation-overlay confirmation-overlay modal-window", :index => 1).link(:text => "From entire reservation").click
  end

  def set_req_data_for_passenger_manifest (data = 'red_robin_reservation')
    #DataMagic.load('reservation.yml')
    wait_for_loading_overlay
    InputDataHelper.load_yml('reservation')
    @reservation = InputDataHelper.get_map data

    verify_on_passengers_page
    wait_for_ajax
    set_passenger_name @reservation['firstPassengerName']
    select_add_to_flight_button
    wait_for_ajax
    validate_passenger_in_list(@reservation['firstPassengerName'])
    set_passenger_name @reservation['secondPassengerName']
    select_add_to_flight_button
    wait_for_ajax
    validate_passenger_in_list(@reservation['secondPassengerName'])
    #select_lead_passenger_list @reservation['firstPassengerName']
    wait_for_ajax
    select_catering_button
  end

  def get_res_passenger_list(leg_num=1)
    self.verify_on_passengers_page #Gather the passenger list from the passenger page.
    passenger_leg_elements[leg_num-1].unordered_list_element.text.gsub(/Remove|Infant/,'').split(/\n/).select{|pax_list|!pax_list.empty?}
  end

  def add_new_passenger_to_account (new_passenger)

    self.new_person
    number_of_seconds = Time.now.sec
    number_of_minutes =Time.now.min
    first_name =self.first_name = new_passenger
    last_name = self.last_name = "Tester #{number_of_seconds}#{number_of_minutes}"
    #self.manifest_name = "Joe Camel 536237"
    self.MM = "07"
    self.DD = "04"
    self.YYYY = "1988"
    self.wait_for_ajax_loader
    self.Confirm

     passenger_name ="#{first_name} #{last_name}"
    return passenger_name
  end

  def set_unknown_passenger (data = 'Child')
    self.unknown_person
    wait_for_ajax
    unknown_overlay_element.div_element.span_element.click
    drop_down_element.when_visible
    #list_item replace li in watir
    drop_down_element.list_item_element(:text => "#{data}").click
    wait_for_ajax
    unknown_overlay_element.div_elements[1].span_element.click
    unknown_passenger = "Unknown passenger (#{data})"

  return unknown_passenger

  end

  def get_passenger_list(leg_num=1)
    passenger_leg_elements[leg_num-1].unordered_list_element(:class => 'passenger-list').text.split("\n").delete_if{|passenger_list| passenger_list == "Remove"}
  end


  #****************************************
  # Utility Methods
  #****************************************
  private



  def get_number_of_passengers(leg_number)

    # totalPassengerCount=0
    leg_count = passenger_leg_elements[leg_number-1].div_elements(:class => 'list clear').count

    if leg_number.to_i >= 1 #Get the Count of number of passengers for all the previous legs
      for number_of_pax in 1..leg_count-1
        passenger_count =  passenger_leg_elements[leg_number-1].unordered_list_element(:class => 'passenger-list', :index => number_of_pax-1).text.split("Remove").count-1 # count-1 gives the exact number of passengers
        # totalPassengerCount = totalPassengerCount + passengerCount
      end
    end
    return passenger_count
  end

  def remove_passenger(passengerName, leg_number=1)
    passenger_list = passenger_leg_elements[leg_number-1].div_element(:class => 'list clear')
    passenger_list.list_item_elements.each_with_index do |actual_passenger, index_value|
      if actual_passenger.when_present.text.downcase.include? passengerName.downcase
        passenger_leg_elements[leg_number-1].link_element(:class => 'remove remove-passenger', :index => index_value).when_present.click # indexValue+totalPassengerCount will give the right index of the required passenger
        break
      end
    end
  end

  public
  def get_wip_reservation_id
    return wip_id = 'WIP-' << browser.url.split('WIP-')[1].strip
  end

  def find_passenger_in_results(passengerName)
      search_result_elements.each do |passenger|
             if passenger.text.downcase.include? passengerName.downcase
              passenger.click
        end
        break
     end

  end

  def validate_passenger_in_list(passengerName, leg_number='all')
    if leg_number == 'all'
      missing_flights = Array.new
      passenger_leg_elements.each_with_index do |leg, index_value|
        unless leg.text.include? passengerName
          missing_flights << (index_value + 1)
        end
      end
      fail "The following flights do not include passenger #{passengerName}, "\
      "flight(s): #{(missing_flights.join(', '))}." unless missing_flights.count == 0
    else
      fail "Flight #{leg_number} does not include passenger #{passengerName}" unless @browser.ul(:class => 'passenger-list', :index => leg_number-1).text.include? passengerName
    end
  end

  def select_save_button
  wait_for_ajax_loader
  self.savePassenger
  end


end

