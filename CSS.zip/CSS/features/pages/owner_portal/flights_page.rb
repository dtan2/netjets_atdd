class FlightsPage
  include PageObject
  include DataMagic
  require_relative "../../../features/support/global_settings"
  include GlobalSettings
  require 'yaml'


  #link(:addPassengers,:text=>'Next: Passengers')
  link(:depart_time,:class=>'set-date set-dep-date selected date-time')
  link(:addPassengers, :class => 'btn btn3 next-step add-passengers')
  link(:addPassengers_disable,:class => 'btn btn3 next-step add-passengers btn-disabled')
  link(:addReturnFlight, :class => 'add-flight return-flight')
  link(:addOnwardFlight, :text => 'Add onward flight') # mgraf -- swapped selector from class to text due to incorrect element being selected
  link(:save_exit, :class => 'btn btn3 next-step')
  link(:cancel,:class=>'btn btn11')
  link(:upgrade,:text=>'Upgrade')
  div(:warning_msg,:class=>'major-changes modal-window clear')
  div(:catering_change,:class => 'catering-changes')
  div(:ground_change,:class => 'ground-changes')
  div(:error_msg, :class => 'error-msgs')
  div(:loadingOverlay, :class => 'curtain')
  div(:addFlightBar, :class => 'add-flight-bar clear')
  div(:craft_list,:class=>'choose-aircraft')
  div(:calendar,:class=>'modal calendar clear show')
  list_items(:flight_leg,:class=>'newly-added')
  div(:up_down_grade,:class=>'grade-modal modal-window')
  divs(:rows_aircraft,:class => 'regrade-craft clear')
  divs(:airport_results,:class => 'predictive-results')
  div(:pop_msg,:class=>'datetime-confirmation-overlay confirmation-overlay modal-window')
  link(:pop_yes){|page|page.pop_msg_element.link_element(:class=>'btn btn1 tick')}
  link(:pop_cancel){|page|page.pop_msg_element.link_element(:class=>'btn btn2 delete')}
  link(:review_catering,:text => 'Review Catering order')
  link(:review_ground,:text => 'Review Ground order')
  #****************************************
  # Main Methods
  #****************************************

  def verify_on_flights_page
    verify_on_page('Flights')

  end


  def verify_calender_nje_time_format

    calendar_element.select_list_element(:id => 'depart-time-').text.should include '23'
    calendar_element.select_list_element(:id => 'depart-time-ampm-').should_not exist
  end


  def verify_flight_page_nje_time_format

    flight_leg_elements[0].link_element(:class=>'set-date set-dep-date date-time selected').text.should_not include 'am' || 'pm'
    flight_leg_elements[0].link_element(:class=>'set-date set-dep-date date-time selected').text.should_not include 'am' || 'pm'
  end

  def verify_flight_leg_header_nje_time_format

    flight_leg_elements[0].div_element(:class=>'departure').text.should_not include 'am' || 'pm'
    flight_leg_elements[0].div_element(:class=>'arrival').text.should_not include 'am' || 'pm'

  end

 def select_esc_key(pops_windows)
    wait_for_ajax_loader
    self.send("#{pops_windows}_element").send_keys :escape
  end


  def select_aircraft_type(acType,legNumber=1)

    #this is passed an aircraft type, and selects that aircraft flights screen

    number_of_aircraft = flight_leg_elements[legNumber-1].div_elements(:class => 'title clear').count

 if number_of_aircraft > 1
    for aircraft_type_index in 0..number_of_aircraft-1
      current_aircraft = flight_leg_elements[legNumber-1].div_element(:class => 'title clear', :index => aircraft_type_index).text

      if current_aircraft.downcase.include? acType.downcase
        flight_leg_elements[legNumber-1].span_element(:text => 'Select', :index => aircraft_type_index).click
        @passCondition = true #mgraf -- error handling
        break
        #else
        #  puts "Expected aircraft type #{acType} does not match actual aircraft type #{currentAircraft}" #mgraf -- for debugging
      end
    end
    fail "Expected aircraft type #{acType} was not found" unless @passCondition == true #mgraf -- error handling
   end
 end


  def gather_departure_alert_msg (legNumber=1)
    flight_leg_elements[legNumber-1].unordered_list_element(:class => 'alerts').text
  end

  def gather_arrival_alert_msg (legNumber=1)
    flight_leg_elements[legNumber-1].unordered_list_element(:class => 'alerts',:index=>1).text
  end

  def select_change_aircraft(legNumber=1)
    flight_leg_elements[legNumber-1].span_element(:text => 'Change aircraft').when_present.click
  end

 def enter_departure_airport (airportCode,legNumber=1)
   flight_leg_elements[legNumber-1].text_field_element(:id => 'airport-departure-1').when_present.value = airportCode
 end

  def set_departure_airport(airportCode,legNumber=1)
    # wait_for_ajax
    enter_departure_airport airportCode,legNumber
    select_correct_airport(airportCode, legNumber, "departure")
  end

  def enter_arrival_airport (airportCode,legNumber=1)
  flight_leg_elements[legNumber-1].text_field_element(:id => 'airport-arrival-1').when_present.value = airportCode
  end

  def set_arrival_airport(airportCode, legNumber=1)
    enter_arrival_airport(airportCode,legNumber)
    select_correct_airport(airportCode, legNumber, "arrival")
  end

  def select_departure_date_time_link(legNumber=1)
    departure_time = flight_leg_elements[legNumber-1].link_element(:class => 'set-date set-dep-date')
    departure_time.when_present.click
  end

  def select_existing_departure_date_time_link(legNumber=1)
    departure_time = flight_leg_elements[legNumber-1].link_element(:class => 'set-date set-dep-date date-time selected')
    departure_time.when_present.click
  end

  def select_arrival_date_time_link(legNumber=1)
    arrival_time = flight_leg_elements[legNumber-1].link_element(:class => 'set-date set-arrival-date')
    arrival_time.when_present.click
  end

  def select_existing_arrival_date_time_link(legNumber=1)
    wait_for_ajax
    arrival_time = flight_leg_elements[legNumber-1].link_element(:class => 'set-date set-arrival-date date-time')
    arrival_time.when_present.click
  end

  def set_flight_date_time(noOfHours, account_type = 'NJA')
    select_date_time_from_now(noOfHours,account_type)
  end

  def select_calendar_save_link
    self.calendar_element.list_item_element(:class => 'confirm').when_present.click
  end


  def select_add_passengers_button
    wait_until(10){!addPassengers_disable_element.visible?}

    addPassengers_element.when_visible(10).click
     end

  def select_add_return_flight_link
    addReturnFlight_element.when_visible(small_wait).click
  end

  def select_add_onward_flight_link
    addOnwardFlight_element.when_visible(small_wait).click
  end

  def select_flight(leg_number =1)
    sleep 3
    list_of_legs = @browser.ul(:class => 'flight-list flight-acc')
    list_of_legs.when_present.lis.each do |flightNum|

      actual_flight_number = flightNum.text.split(" ")
      if actual_flight_number.at(1).to_i == leg_number.to_i
        flightNum.click
        break
      end
    end
  end

    def select_down_up_aircraft aircraft_type

      up_down_grade_element.div_elements(:class => 'regrade-craft clear').each_with_index do |aircraft_row,index|

        if aircraft_row.h3_element.text.downcase == aircraft_type.downcase
        rows_aircraft_elements[index].link_element(:class => 'btn primary tick').click
        break
        end
      end
  end


  def upgrade_aircraft_type(aircraft_type, leg_number=1)
    select_up_grade_button leg_number
    wait_until{up_down_grade_element.visible?}
    select_down_up_aircraft aircraft_type
   end

  def select_down_grade_button(leg_num=1)
   wait_for_ajax_loader
   flight_leg_elements[leg_num-1].div_element(:id=>'craftList').link_element(:class=>'btn primary down').click
  end

  def select_up_grade_button(leg_num=1)
    wait_for_ajax_loader
    flight_leg_elements[leg_num-1].div_element(:id=>'craftList').link_element(:class=>'btn primary up').click
  end


  def downgrade_aircraft_type(aircraft_type, leg_number=1)
    select_down_grade_button(leg_number)
    wait_until{up_down_grade_element.visible?}
    select_down_up_aircraft aircraft_type
  end

  def cancel_aircraft_regrade(leg_num=1)
    # begin
      #@browser.ul(:class => 'flight-list flight-acc').li(:index => leg_number-1).span(:text => 'Delete').click
      # @browser.ul(:class => 'flight-list flight-acc').li(:class => 'newly-added', :index => leg_number-1).span(:text => 'Delete').click
    # rescue
    # end
    flight_leg_elements[leg_num-1].link_element(:class=>'btn primary delete').click
  end

   def validate_aircraft_type(leg_number, aircraft_type)
    valid_aircraft = false
    aircraft_list = @browser.div(:id => 'craftList')
    aircraft_list.divs(:class => /aircraft type-/).each do |contract|
      if contract.attribute_value('class').include?('selected')
        fail 'unexpected aircraft type' unless contract.h3.text == aircraft_type
        valid_aircraft = true
      end
    end
    fail "Unexpected aircraft type. Expected: #{aircraft_type}" unless valid_aircraft
  end

  def validate_departure_airport(departure_airport, leg_number)
    selected_dep_ap = JSON.parse(@browser.input(:xpath => "//li[@class = 'newly-added'][#{leg_number}]"\
    "//div[@class = 'arrival']//input[@data-airport]").attribute_value('data-airport'))['Code']
    fail "Unexpected departure airport. Actual: #{selected_dep_ap}, Expected: #{departure_airport}" unless selected_dep_ap == departure_airport
  end

  def validate_arrival_airport(arrival_airport, leg_number)
    selected_arr_ap = JSON.parse(@browser.input(:xpath => "//li[@class = 'newly-added'][#{leg_number}]"\
    "//div[@class = 'arrival']//input[@data-airport]").attribute_value('data-airport'))['Code']
    fail "Unexpected arrival airport. Actual: #{selected_arr_ap}, Expected: #{arrival_airport}" unless selected_arr_ap == arrival_airport
  end

  def validate_departure_date_time(expected_departure_date_time, leg_number)
    departure_datetime = DateTime.parse(@browser.li(:class => 'newly-added', :index => leg_number-1).
                                           a(:class => /set-date set-dep-date date-time/).text)
    fail "Unexpected departure date and time. Expected: #{expected_departure_date_time}, "\
    "Actual: #{departure_datetime}" unless expected_departure_date_time == departure_datetime
  end

  def validate_arrival_date_time(expected_arrival_date_time, leg_number)
    arrival_datetime = DateTime.parse(@browser.li(:class => 'newly-added', :index => leg_number-1).
                                         a(:class => /set-date set-arrival-date date-time/).text)
    fail "Unexpected arrival date and time. Expected: #{expected_arrival_date_time}, "\
    "Actual: #{arrival_datetime}" unless expected_arrival_date_time == arrival_datetime
  end

  def validate_contract_type (contract_type)

    fail "Contract type #{contract_type} not showing in flight page " unless craft_list_element.text.include? contract_type

  end



  #****************************************
  # Default Reservation Creation Method
  #****************************************
  #def set_default_data_for_reservation(data={})
  #  DataMagic.load('reservation.yml')
  #
  #  select_aircraft_type 'hawker 800xp - collins'
  #  populate_page_with data_for(:basic_reservation, data)
  #  set_departure_time_link
  #
  #end

  def set_req_data_for_reservation(data='red_robin_reservation', account_type='NJA')
    #DataMagic.load('reservation.yml')
    InputDataHelper.load_yml('reservation')
    @reservation = InputDataHelper.get_map data

    wait_for_ajax
    verify_on_flights_page
    select_aircraft_type @reservation['aircraftId']
    set_departure_airport(@reservation['firstDepartureAirport'], 1)
    set_arrival_airport(@reservation['firstArrivalAirport'], 1)
    select_departure_date_time_link(1)
    wait_for_ajax
    set_flight_date_time(@reservation['noOfHours'],account_type)
    select_calendar_save_link
    wait_for_ajax
    wait_for_loading_overlay
    select_add_return_flight_link
    wait_for_ajax
    select_departure_date_time_link(2)
    wait_for_ajax
    set_flight_date_time(@reservation['noOfHours_2'],account_type)
    select_calendar_save_link
    wait_for_ajax
    select_add_passengers_button
  end

  def set_req_data_for_multi_flight_reservation(flightCount)
    #DataMagic.load('reservation.yml')
    InputDataHelper.load_yml('reservation')
    @reservation = InputDataHelper.get_map("reservation_flight_1")
    verify_on_flights_page
    wait_for_ajax
    select_aircraft_type @reservation['aircraftId']
    set_departure_airport(@reservation['departureAirport'], 1)
    set_arrival_airport(@reservation['arrivalAirport'], 1)
    select_departure_date_time_link(1)
    wait_for_ajax
    set_flight_date_time(@reservation['noOfHours'])
    select_calendar_save_link
    if flightCount > 1

      select_add_onward_flight_link
      wait_for_ajax
    end
    (2..flightCount).each do |flight|
      @reservation = InputDataHelper.get_map("reservation_flight_#{flight}")
      set_departure_airport(@reservation['departureAirport'],flight)
      set_arrival_airport(@reservation['arrivalAirport'],flight)
      select_departure_date_time_link(flight)
      wait_for_ajax
      set_flight_date_time(@reservation['noOfHours'])
      select_calendar_save_link
      unless flight == flightCount
        select_add_return_flight_link
        select_departure_date_time_link(flight)
        wait_for_ajax
        set_flight_date_time(@reservation['noOfHours'])
        select_calendar_save_link
      end
    end
    select_add_passengers_button
  end

  def get_estimated_flight_time(leg_num=1)

    wait_until {flight_leg_elements[leg_num-1].span_element(:class => 'flight-time', :index => 1).visible?}


    arr = flight_leg_elements[leg_num-1].span_element(:class => 'flight-time', :index => 1).when_present.text
    #Create an array with split
    total_arr = arr.split (' ')
    minutes = total_arr.at(-1).gsub("mins", "")
    #pick 2nd last from the array
    hours = total_arr.at(-2).gsub("hrs", "")
        #flight time in second
    arr_time_hr = minutes.to_i/60.0 + hours.to_i
        #returning a value to be stored
    return arr_time_hr

  end
  class Itinerary
    attr_accessor :time,:date
  end


  def get_departure_date_time(leg_num=1)
  dep_info = flight_leg_elements[leg_num-1].link_element(:class=>'set-date set-dep-date date-time selected').text.split(/\n/)
  dep_date_time = Itinerary.new
  dep_date_time.time = dep_info[0]
  dep_date_time.date = dep_info[1]
  return dep_date_time
  end

 def get_arrival_date_time(leg_num=1)
 arrival_info = flight_leg_elements[leg_num-1].link_element(:class=>'set-date set-arrival-date date-time selected').text.split(/\n/)
 arrival_date_time = Itinerary.new
 arrival_date_time.time = arrival_info[0]
 arrival_date_time.date = arrival_info[1]
 return arrival_date_time
 end



  def set_exact_departure_time (dep_time = '3:00', meridian)
      dep_time = dep_time.split (":")

  self.calendar_element.div_element(:class => 'field clear', :index => 2).text_field_elements[0].value = dep_time[0]
    #set minute
  self.calendar_element.div_element(:class => 'field clear', :index => 2).text_field_elements[1].value = dep_time[1]
  self.calendar_element.div_element(:class => 'field clear', :index => 2).text_field_elements[2].value = meridian

    #Save the time
  select_calendar_save_link
  end

  def gather_pop_warning_msg
    self.warning_msg_element.text.split(/\n/)
  end

  def gather_pop_ground_warning_msg
  warning_msg_element.div_element(:class=>'ground-changes').text.split(/\n/)
  end

  def gather_pop_catering_warning_msg
    warning_msg_element.div_element(:class=>'catering-changes').text.split(/\n/)
  end

  def gather_pop_links_msg
    warning_msg_element.div_element(:class=>'update clear').text.split(/\n/)
  end



  def gather_selected_aircraft(leg_num=1)
    data=flight_leg_elements[leg_num-1].text.split(/\n/)
    return data[14]
  end

  def gather_drop_down_departure_airport(leg_num=1)

  flight_leg_elements[leg_num-1].div_element(:class => 'predictive-results').when_present.text.split(/\n/)
  end

  def gather_drop_down_arrival_airport(leg_num=1)
  flight_leg_elements[leg_num-1].div_element(:class => 'predictive-results',:index=>1).text.split(/\n/)
  end


  #****************************************
  # Utility Methods
  #****************************************
  private

  def select_correct_airport(airportCode, legNumber, depOrArr)

    if depOrArr.downcase == "departure" # Taking care of indexes for different Legs
      correct_index = 0
    else
      correct_index = 1
    end

    list_of_airports = flight_leg_elements[legNumber-1].div_element(:class => 'predictive-results', :index => correct_index)

    # listOfAirports.link_element(:index => 0).wait_until_present # mgraf -- optimization to remove sleeps, changed from list item to anchor

    wait_for_ajax

    list_of_airports.list_item_elements.each do |airports|
      if airports.text[0, 3].downcase == airportCode.downcase
        #p "I about to click the airport"
        # sleep (1.0/4.0) #occasionally the code is executed to this point while the listOfAirports is not present causing a failure, unknown how
        airports.when_present.click #occasionally the code is executed to this point while the listOfAirports is not present causing a failure, unknown how
        @passCondition = true # mgraf -- error handling
        break

      end
    end
    fail "Expected airport with the airport code #{airportCode} is not listed" unless @passCondition == true # mgraf -- error handling
  end

  # def select_date(noOfHours, legNumber, depOrArr, account_type="NJA")
  def select_date_time_from_now(noOfHours,account_type="NJA")
    departure_actual_month = self.calendar_element.span_element(:class => 'month-display')
    departure_next_month = self.calendar_element.span_element(:class => 'next-but next-month')

    noOfHours = noOfHours.to_i
    offset_date = Time.now + (noOfHours*60*60) #offsetDate =   Time.now + (noOfDays *24*60*60)
    #tomorrowsDate = Time.now + (24*60*60)

    expected_day = offset_date.day
    expected_hour = offset_date.strftime "%I"
    expected_minute = offset_date.min
    expected_month = offset_date.strftime "%B"
    expected_meridian = offset_date.strftime "%p"

    # This Loop make sure we are in right month
    for correct_month in 1..5
      actual_month = departure_actual_month.when_present.text.to_s.strip.downcase # strip the white spaces and downcase
      if expected_month.downcase == actual_month.downcase
        bolStatus = true
        break
      end
      departure_next_month.when_present.click
    end

    expected_day_element = @browser.div(:class => 'modal calendar clear show').td(:title => /#{expected_day},/)
    if expected_day_element.attribute_value("aria-selected") != "true"
      expected_day_element.when_present.click
    end

    if account_type != "NJE"
      # self.calendar_element.text_field_element(:type => 'text',:index =>1).when_present = expected_hour

      self.calendar_element.div_element(:class=>'field clear',:index=>2).text_field_elements[0].value = expected_hour
      self.calendar_element.div_element(:class=>'field clear',:index=>2).text_field_elements[1].value = expected_minute
      self.calendar_element.div_element(:class=>'field clear',:index=>2).text_field_elements[2].value = expected_meridian

    else
      expected_hour = offset_date.strftime "%H"
      self.calendar_element.div_element(:class=>'field clear',:index=>2).text_field_elements[0].value = expected_hour
      self.calendar_element.div_element(:class=>'field clear',:index=>2).text_field_elements[1].value = expected_minute
    return offset_date
    end

  end

  def time_to_next_quarter_hour(time)
    array = time.to_a
    quarter = ((array[1] % 60) / 15.0).ceil
    array[1] = (quarter * 15) % 60
    Time.local(*array) + (quarter == 4 ? 3600 : 0)
  end



 end

