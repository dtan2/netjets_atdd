class ResetPasswordSecurityPage
  include PageObject
  require_relative "../../../features/support/global_settings"
  include GlobalSettings
  require 'rspec'

  text_field(:security_answer, :name => 'SecretAnswer')
  button(:submit_answer, :type => 'submit')

  def verify_on_page
    @browser.text.should include 'Answer your security question'
  end

  def submit_security_answer_as(answer = $user_security[:answer])
    security_answer_element.when_visible
    self.security_answer = answer
    self.submit_answer
  end

end