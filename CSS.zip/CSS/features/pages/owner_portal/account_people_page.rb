class AccountPeoplePage < ProfilePage

  include PageObject
  require_relative "../../../features/support/global_settings"
  include GlobalSettings
  include TopMenuHeader
  include ProfileAccount
  #some of the share element is in the ProfileAccount module

  link(:addnew_individual,:class=>'add-new')
  li(:search_result, :class => 'show selected')
  link(:addnew,:class=>'btn btn1 none add-new',:index=>1)
  link(:addnew_passport,:class=>'btn btn1 none add-new',:index=>3)
  links(:editBasic, :class => 'btn btn2 edit-3')
  link(:editBasic_alt,:class=> 'btn btn2 edit-3')
  link(:confirm,:class=>'btn btn6 add-passenger')
  link(:continue,:class=>'btn btn1 none continue')
  link(:people,:text=>'People')
  text_field(:search, :id => 'Search1')
  text_field(:people_firstname, :id => 'first-name')
  text_field(:people_lastname, :id => 'last-name')
  text_field(:people_manifestname, :id => 'manifest-name')
  text_field(:first_name, :id => 'basic-firstname')
  text_field(:middle_name, :id => 'basic-middlename')
  text_field(:last_name, :id => 'basic-lastname')
  text_field(:manifest_name, :id => 'basic-manifest-name')
  text_field(:month, :id => 'basic-dobM')
  text_field(:day, :id => 'basic-dobD')
  text_field(:YYYY, :id => 'basic-dobY')
  div(:error_msg,:class=>'error')
  div(:search_msg,:class=>'prompt')




  def verify_in_people_page()
    verify_on_page("Account/People")
  end

  def people_search name
    self.search = name
  end


  def set_basic_information
    wait_for_ajax_loader
        #start editing
    prefix = set_prefix random_prefix
    suffix = set_suffix random_suffix
    manifest_name = self.manifest_name = "manifestname_#{random_suffix}"
    month = self.month = "7"
    day = self.day ="4"
    year = self.YYYY = "1988"
    gender = set_gender "Female"
    wait_for_ajax_loader
    name = "#{prefix} John Rowe #{suffix}"
    date = "#{month}/#{day}/#{year}"
    wait_for_ajax_loader
    wait_for_loading_overlay
    return name, manifest_name, gender, date
  end


  def select_edit_basic_information
    self.editBasic_elements[0].when_visible
    self.editBasic_elements[0].click
  end

  def select_edit_passport
    wait_for_ajax
    self.editBasic_elements[5].when_present.click
    # self.editBasic_elements[5].click
    end



############################################################################################

  def gather_search_error_msg
  self.search_msg_element.when_visible.text
  end

  def gather_search_result
   self.search_result_element.when_visible.text
  end

end