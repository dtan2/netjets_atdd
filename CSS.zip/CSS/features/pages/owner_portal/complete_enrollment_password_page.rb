class CompleteEnrollmentPasswordPage
  include PageObject

  text_field(:password_field, :id => 'Password')
  text_field(:password_retype_field, :id => 'PasswordRepeat')
  link(:terms_and_conditions_link, :text => /Terms and Conditions/)
  checkbox(:accept_terms_checkbox, :id => 'accept')
  button(:submit_button, :id => 'submit')

  def submit_enrollment_password_as(password = 'abc123ABC')
    set_password_fields_to password
    accept_terms_checkbox_element.check
    submit_button
  end

  def set_password_fields_to(password)
    self.password_field = password
    self.password_retype_field = password
  end


end