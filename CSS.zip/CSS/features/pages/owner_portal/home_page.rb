class HomePage
  include PageObject
  include TopMenuHeader
  require_relative "../../../features/support/global_settings"
  include GlobalSettings
  require 'json'


  link(:bookFlight, :class => 'btn btn5 plane')
  # link(:new_reservation, :href => '/Book/Flights')
  link(:submittedFlights, :text => 'Submitted flights')
  link(:drafts, :id => 'drafts')
  link(:showMore_submittedFlights, :text => 'Show more')
  link(:flights, :text => 'Flights')
  link(:profile, :text => 'Profile')
  link(:account, :text => 'Account')
  link(:netJetsNews, :text => 'NetJets News')
  link(:netJetsCom, :text => 'NetJets.com')
  link(:personalDetails, :text => 'Personal Details')
  link(:usernamePassword, :text => 'Username & Password')
  link(:preferences, :text => 'Preferences')
  link(:fleet, :text => 'Fleet')
  link(:showMore, :text => 'Show more')
  link(:log_out, class: 'sign-out')
  div(:flights_res,:class=>'flight clear')
  div(:reservationList, :id => 'reservationList')
  divs(:sub_reservation){|page|page.reservationList_element.list_item_elements}
  span(:delete_flights, :class=>'delete-flight')
  link(:view_invoices, :id => 'view_invoices')
  link(:payments_and_invoices, :text => 'Make a Payment')

  #****************************************
  # Main Methods
  #****************************************
  def verify_on_home_page
    @browser.wait_until(large_wait, "Home page has not loaded") do
      @browser.text.include? 'Welcome'
    end
  end

  def verify_nje_time_format_res

    flights_res_element.div_element(:class=>'departure').span_elements[2].text.should_not include 'am' || 'pm'
    flights_res_element.div_element(:class=>'arrival').span_elements[2].text.should_not include 'am' || 'pm'
  end


  def select_plan_book_flight_link

    verify_on_home_page
    bookFlight_element.when_visible(small_wait).click
    wait_for_loading_overlay

    #verify_on_page("Welcome")
  end

  def select_header_flights_link
    top_menu_element.link(:text=>'Flights').click
  end

  def select_header_profile_link
    profile_element.when_visible(small_wait).click
  end

  def select_header_account_link
    account_element.when_visible(small_wait).click
  end

  def select_header_netjets_news_link
    netJetsNews_element.when_visible(small_wait).click
  end

  def select_header_netjets_com_link
    netJetsCom_element.when_visible(small_wait).click
  end

  def select_header_fleet_link
    fleet_element.when_visible(small_wait).click
  end

  def select_personal_details_link
    personalDetails_element.when_visible(small_wait).click
  end

  def select_username_and_password_link
    usernamePassword_element.when_visible(small_wait).click
  end

  def select_preferences_link
    preferences_element.when_visible(small_wait).click
  end

  def view_invoices
    self.select_account_invoice
    self.payments_and_invoices
  end

  #****************************************
  # Submitted flights List Methods
  #****************************************

  def select_submitted_flights_link
    submittedFlights_element.when_visible(small_wait).click
  end


  def gather_submitted_reservation_num
    self.reservationList_element.text.split(/#/).map{|reservation_number|reservation_number[/\d+/]}.drop(1)
  end

  def verify_reservation_number? reservation_num
    result = false
     until result == true
      gather_submitted_reservation_num.each do |num|
          if num == reservation_num
          result = true
           break
         end
      end
      if result == true
        break
      end

      self.showMore_element.when_present.click
      sleep 2
     end
    return result
  end

  def select_reservation_submitted_flights reservation_num
    result = false
    while result == false
          self.sub_reservation_elements.each_with_index do |reservation,sub_reservation|
                if reservation.text.include? reservation_num
                self.sub_reservation_elements[sub_reservation].click
                verify_on_page("RequestedReservation")
                result = true
               break
              end
          end
    if result == true
    break
    end
    self.showMore_element.when_present.click
    wait_for_ajax
    end
  end



  def check_for_submitted_flights
    submitted_flight = {"exists?" => false}
    unless @browser.div(:id => 'reservationList').text.include?('There are no submitted reservations on this account')
      submitted_flight["exists?"] = true
      submitted_flight["reservation_id"] = JSON.parse(@browser.ul(:class => 'reservations clear').li(:index => 0).attribute_value('data-flight'))['ReservationID']
      #$open_res_no = JSON.parse($open_res_no)['ReservationID']
      #return open_res_no
    end
    return submitted_flight
  end

  #****************************************
  # Flights not submitted list Methods
  #****************************************

  def select_drafts_link

    drafts_element.when_visible(small_wait).click
    @browser.div(:id => 'reservationList').li(:id => /\AWIP/).wait_until_present
  end

  #def open_wip_reservation(wip_id)
  #  unless wip_id.include? 'WIP-'
  #    wip_id = @browser.div(:id => 'reservationList').li().attribute_value 'id'
  #  end
  #  @browser.li(:id => wip_id).when_present.click
  #  @browser.url.include? wip_id
  #  wait_for_loading_overlay
  #end

  def open_wip_reservation(wip_id)
    res_exist = wip_reservation_in_list? wip_id
    fail "Reservation #{wip_id} does not exist" unless res_exist == true
    @browser.li(:id => wip_id).click
    wait_for_loading_overlay
  end

  def delete_wip_reservation(wip_id)
    @browser.li(:id => wip_id).span(:class => 'delete-flight').click
    @browser.div(:class => 'confirmation-overlay modal-window').span(:text => 'Yes').click
    return wip_id
  end

  def select_show_more_button
    showMore
    #@browser.p(:text => 'Loading more items').wait_while_present
    @browser.div(:class => 'loader').wait_while_present
  end

  def verify_tool_tip (wip_num)

    fail "Tool tip is not visible for #{wip_num} "unless @browser.span(:id=>"#{wip_num}-note").visible?

  end


  #****************************************
  # Private Utility Methods
  #****************************************
  private
  def show_all_reservations
    show_more = @browser.span(:text => 'Show more')
    while show_more.present?
      @browser.p(:text => 'Loading more items').wait_while_present
      show_more.click
    end
  end

  private
  def submitted_reservation_in_list?(res_id)
    res_exist = false
    @browser.ul(:class => 'reservations clear').lis.each do |reservation|
      if res_id == JSON.parse(reservation.attribute_value('data-flight'))['ReservationID']
        res_exist = true
        break
      end
    end
    return res_exist
  end

  private
  def wip_reservation_in_list?(wip_id)
    res_exist = false
    show_more_clicks = 0
    until showMore_element.visible? == false or res_exist == true
      res_collection = Array.new
      res_count = @browser.ul(:class => 'reservations clear').lis().count
      ((0+6*show_more_clicks)..(res_count-1+6*show_more_clicks)).
          each { |reservation_in_list| res_collection << @browser.ul(:class => 'reservations clear').li(:index => reservation_in_list) }
      res_collection.each do |reservation_id|
        if reservation_id.attribute_value('id') == wip_id #intermittant error -- Watir::Exception::UnknownObjectException: unable to locate element, using {:index=>4, :tag_name=>"li"}
          res_exist = true
        end
      end
      unless res_exist == true
        select_show_more_button
        show_more_clicks = show_more_clicks + 1
      end
    end
    return res_exist
  end

end