class ConfirmationPage
  include PageObject
  require_relative "../../../features/support/global_settings"
  include GlobalSettings
  include TopMenuHeader

  div(:heroBar, :id => 'herobar') #Your reservation request has been received
  div(:summary, :id => 'summary') #Your reservation has been received. We will send you confirmation once it is booked.  Reservation #5955683
  link(:viewPrintItinerary, :class => 'btn btn2')
  link(:bookANewReservation, :class => 'btn btn2', :index => 1)
  link(:returnToHomePage, :class => 'btn btn2', :index => 2)
  link(:logoHomePage, :class => 'logo')

  #****************************************
  # Main Methods
  #****************************************

  def verify_on_confirmation_page
    verify_on_page("Confirmation")
  end

  def verify_message_exists(text)
    fail "The message '#{text}' is not being displayed on the screen" unless @browser.text.include? text
    fail "The message '#{text}' is not being displayed on the screen" unless heroBar.include? text
  end

  def verify_reservation_number_exists
    any_reservation = "Reservation ##{/\d{3}/}"
    fail "Reservation Number not correct" unless self.summary.match(any_reservation)
  end

  def get_reservation_number
    message = summary.split("#")
    reservation_number = message.at(1)
    puts "Reservation number is #{reservation_number}"
    return reservation_number
  end

  def select_view_print_itinerary_button
    viewPrintItinerary_element.when_visible.click
    # sleep 2 #verify_on_page("Confirmation")
  end

  def select_book_new_reservation_button
    bookANewReservation_element.when_visible.click
    #verify_on_page("Confirmation")
  end

  def select_return_to_home_page_button
    returnToHomePage_element.when_visible.click
    #verify_on_page("Confirmation")
  end

  def select_logo_banner
    logoHomePage_element.when_visible.click
  end

end