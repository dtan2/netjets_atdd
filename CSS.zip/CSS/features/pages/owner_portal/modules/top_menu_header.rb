module TopMenuHeader
  include PageObject
  link(:go_to_personal_details, :text => 'Personal Details')
  link(:go_to_change_password, :text => 'Username & Password')
  link(:go_to_fbo_preferences, :text => 'Preferences')
  link(:profile_account,:text=>'Profile & Account')
  link(:aircraft_balance,:text=>'Aircraft & Balance')
  ul(:top_menu,:class=>'complete clear')
  divs(:sub_menu,:class=>'clear')
  div(:hover_items, :class=>'pop')
  link(:profile_account){|page| page.top_menu_element.link_element(:text=>'Profile & Account')}
  link(:invoices, text: 'Invoices')
  link(:home_banner, class: 'logo')

  def select_personal_details
    wait_until(10){profile_account_element.visible?
    profile_account_element.when_present.hover
    hover_items_element.div_elements[0].list_item_elements[0].click}
  end

  def select_username_password
    wait_until(10){profile_account_element.visible?
    profile_account_element.hover
    hover_items_element.div_elements[0].list_item_elements[1].click}
  end

  def select_personal_preference
    wait_until(10){profile_account_element.visible?
    profile_account_element.when_present.hover
    hover_items_element.div_elements[0].list_item_elements[2].click}
   end

  def select_account_basic_details
    wait_until{profile_account_element.visible?
    profile_account_element.when_present.hover
    hover_items_element.div_elements[1].list_item_elements[0].click}
  end

  def select_aircraft_balance
    wait_until(10){profile_account_element.visible?
    profile_account_element.when_present.hover
    hover_items_element.div_elements[1].list_item_elements[1].click}
  end

  def select_account_people
    wait_until(10){profile_account_element.visible?
    profile_account_element.when_present.hover
    hover_items_element.div_elements[1].list_item_elements[2].click}
end

  def select_account_invoice
    wait_until(10){profile_account_element.visible?
    profile_account_element.hover
    hover_items_element.div_elements[1].list_item_elements[3].click}
  end

  def select_account_preference
    wait_until(10){profile_account_element.visible?
    profile_account_element.when_present.hover
    hover_items_element.div_elements[1].list_item_elements[3].click}
  end

  def select_other_account account
    wait_until(10){profile_account_element.visible?
    profile_account_element.hover
    hover_items_element.div_elements[1].list_item_elements[5].link_element(:text=>/#{account}/).click}
  end

  def gather_access_account_name
    wait_until(10){profile_account_element.visible?
    profile_account_element.hover
    hover_items_element.div_elements[1].text.split(/Switch to:/)}
  end



end