module ProfileAccount
  include PageObject

  links(:save, :class => 'btn btn1 none save')
  link(:basic_email, :id => 'emailAddresses')
  links(:edit, :class => 'btn btn1 edit')
  links(:delete,:class=>'btn btn2 delete')
  link(:delete_alt,:class=>'btn btn2 delete')
  link(:basic_address, :id => 'mailingAddresses')
  link(:basic_international, :id => 'internationalInformation')
  link(:basic_passport, :id => 'passports')
  links(:addnew,:class=>'btn btn1 none add-new')
  link(:basic_phone, :id => 'phoneNumbers')
  div(:basic_info,:id=>'basic')
  div(:phones_info,:id=>'phones')
  div(:error_msg,:class=>'errors show clear')
  links(:edit_phone){|page|page.phones_info_element.link_elements(:class=>'btn btn1 edit')}
  links(:delete_phone){|page|page.phones_info_element.link_elements(:class=>'btn btn2 delete')}
  divs(:phone_data){|page|page.phones_info_element.div_elements(:class => 'preview-mode clear')}
  div(:email_info,:id=>'emails')
  links(:edit_email){|page|page.email_info_element.link_elements(:class=>'btn btn1 edit')}
  links(:delete_email){|page|page.email_info_element.link_elements(:class=>'btn btn2 delete')}
  divs(:email_data){|page|page.email_info_element.div_elements(:class => 'entry')}
  div(:address_info,:id=>'addresses')
  links(:edit_address){|page|page.address_info_element.link_elements(:class=>'btn btn1 edit')}
  links(:delete_address){|page|page.address_info_element.link_elements(:class=>'btn btn2 delete')}
  divs(:address_data){|page|page.address_info_element.div_elements(:class => 'preview-mode clear')}
  div(:international_info,:id=>'international')
  links(:edit_international){|page|page.international_info_element.link_elements(:class=>'btn btn1 edit')}
  divs(:international_data){|page|page.international_info_element.div_elements(:class => 'preview-mode clear')}
  div(:passport_info,:id=>'passports')
  links(:edit_passport){|page|page.passport_info_element.link_elements(:class=>'btn btn1 edit')}
  links(:delete_passport){|page|page.passport_info_element.link_elements(:class=>'btn btn2 delete')}
  links(:edit_visa){|page|page.passport_info_element.link_elements(:class=>'btn btn12 edit')}
  links(:delete_visa){|page|page.passport_info_element.link_elements(:class=>'btn btn12 delete')}
  divs(:passport_data){|page|page.passport_info_element.div_elements(:class => 'preview-mode clear')}
  divs(:visa_data){|page|page.passport_info_element.div_elements(:class => 'entry sub-entry visa clear')}
  link(:add_visa,:class=>'btn btn12 none add-new')
  divs(:info,:class => 'preview-mode clear')
  div(:basicInformationSection, :class => 'edit-mode edit-open')
  div(:visa_section,:class=>'edit-mode visa edit-open')
  spans(:passport_state){|page|page.basicInformationSection_element.span_elements(:class=>'fancy-select-general-value')}
  text_field(:country_code, :id => 'phone-country')
  text_field(:area_code, :id => 'phone-area')
  text_field(:tel, :id => 'phone-tel')
  text_field(:ext, :id => 'phone-ext')
  text_field(:email, :id => 'email-address')
  text_field(:address_line1,:id=>'address-line1')
  text_field(:zip_code,:id=>'address-zip')
  text_field(:city,:id=>'address-city')
  text_field(:birth_state,:id=>'international-state')
  text_field(:birth_city,:id=>'international-place')
  text_field(:passport_firstname,:id=>'passport-firstname')
  text_field(:passport_middlename,:id=>'passport-middlenames')
  text_field(:passport_lastname,:id=>'passport-lastname')
  text_field(:issue_month,:id=>'passport-issuedateM')
  text_field(:issue_day,:id=>'passport-issuedateD')
  text_field(:issue_year,:id=>'passport-issuedateY')
  text_field(:exp_month,:id=>'passport-expirydateM')
  text_field(:exp_day,:id=>'passport-expirydateD')
  text_field(:exp_year,:id=>'passport-expirydateY')
  text_field(:passport_num,:id=>'passport-number')
  text_field(:first_name, :id => 'first-name')
  text_field(:last_name, :id => 'last-name')
  text_field(:visa_num,:id=>'visa-number')
  text_field(:visa_issue_month,:id=>'visa-issuedateM')
  text_field(:visa_issue_day,:id=>'visa-issuedateD')
  text_field(:visa_issue_year,:id=>'visa-issuedateY')
  text_field(:visa_exp_month,:id=>'visa-expirydateM')
  text_field(:visa_exp_day,:id=>'visa-expirydateD')
  text_field(:visa_exp_year,:id=>'visa-expirydateY')
  label(:check_primary,:text=>'Use as primary passport')
  div(:check_primary_email,:class=>'input checkbox fancy clear')
  label(:checked_primary_email,:class=>'fancy-checked',:text=>'Use as primary email')
  label(:check_missing,:text=>'This passport is missing')
  label(:checked_primary,:class=>'fancy-checked',:text=>'Use as primary passport')
  label(:checked_missing,:class=>'fancy-checked',:text=>'This passport is missing')
  ul(:drop_down,:class => 'fancy-select-general-ul open')

  def set_phone_type(data)

    basicInformationSection_element.div_elements[0].div_element.click
    drop_down_element.when_visible
    drop_down_element.list_item_element(:text => "#{data}").click
    wait_for_ajax_loader

    return data
  end

  def set_phone_number
    wait_for_ajax_loader
    type_temp =['Primary Office','Primary Residence','Office','Mobile','Pager','Boat','Other','Hotel','Office Fax']
    shuffle_type = type_temp.shuffle(radom: Random).pop
    phone_type = set_phone_type shuffle_type
    country_code = self.country_code = random_country_code
    area_code = self.area_code = random_area_code
    tel = self.tel = random_phone_num
    ext = self.ext = '666'
    phone_num ="#{country_code}.#{area_code}.#{tel}.#{ext}"
    wait_for_loading_overlay
    wait_for_ajax_loader
    return phone_type, phone_num
  end

  def set_email
    email_temp =['Billing','Spouse','Office','Mobile','Other']
    shuffle_email = email_temp.shuffle(radom: Random).pop
    email_type = set_phone_type shuffle_email
    email = self.email = "golucky_#{shuffle_email}@goodluck.com"
    return email_type, email
  end

  def set_address
    address_temp =['Residence','Office','Other']
    shuffle_address = address_temp.shuffle(radom: Random).pop
    address_type = set_address_type shuffle_address
    address_line = self.address_line1 = "3400 Main #{shuffle_address} Street"
    zip_num = rand(43000..43999).to_s
    zip_code = self.zip_code = zip_num
    country = set_country 'United States'
    state_temp =['Colorado','Florida','Arkansas','Ohio','Utah','Wyoming','Michigan']
    shuffle_state = state_temp.shuffle.pop
    set_state shuffle_state
    state = shuffle_state[0,2].upcase.strip
    city = self.city = shuffle_state
    address ="#{address_line} #{city}, #{state} #{zip_code} #{country}"

    return address_type,address
  end

  def set_international
    country_temp = random_country
    country  = set_country_birth country_temp
    state = self.birth_state = country_temp
    city = self.birth_city = country_temp
    citizenship  = set_citizenship country_temp
    residence    =  set_residence country_temp

    return country,state,city,citizenship,residence
  end

  def set_passport
    country_issue = set_country_issue random_country
    prefix = set_prefix_passport random_prefix
    first_name = self.passport_firstname = "Smith_#{random_month}"
    middle_name = self.passport_middlename = "Jones_#{random_day}"
    last_name = self.passport_lastname = "Johnson_#{random_month}"

    suffix = set_suffix_passport 'Jr.'

    issue_month = self.issue_month = random_month
    issue_day = self.issue_day = random_day
    issue_year = self.issue_year = random_early_year

    exp_month = self.exp_month = random_month
    exp_day = self.exp_day = random_day
    exp_year = self.exp_year = random_later_year

    passport_tem = rand(42375475..757435747)
    passport_num = self.passport_num = passport_tem.to_s

    #check boxes
    self.check_primary_element.click

    self.check_missing_element.click

    #Check primary
    primary_checked = checked_primary_element.visible?
    #check missing
    missing_checked = checked_missing_element.visible?
    name = "#{prefix} #{first_name} #{middle_name} #{last_name} #{suffix}"
    issued_date ="#{issue_month}/#{issue_day}/#{issue_year}"
    expiration_date = "#{exp_month}/#{exp_day}/#{exp_year}"

    return  country_issue, name, issued_date, passport_num ,primary_checked, missing_checked
  end

  def set_visa
    issue_country = set_visa_issue_country random_country
    visa_type = set_visa_type 'Student Visa'
    issue_month = self.visa_issue_month = random_month
    issue_day = self.visa_issue_day = random_day
    issue_year = self.visa_issue_year = random_early_year

    exp_month = self.visa_exp_month = random_month
    exp_day = self.visa_exp_day = random_day
    exp_year = self.visa_exp_year = random_later_year

    visa_tem = rand(42375475..757435747)
    visa_num = self.visa_num = visa_tem.to_s

    issued_date = "#{issue_month}/#{issue_day}/#{issue_year}"
    expiration_date = "#{exp_month}/#{exp_day}/#{exp_year}"

    return  issue_country, visa_type,issued_date,expiration_date, visa_num

  end



  def set_prefix(data)

    basicInformationSection_element.div_element.div_element.click
    drop_down_element.when_visible
    #list_item (PageObject) repalce li in watir
    drop_down_element.list_item_element(:text => "#{data}").click
    wait_for_ajax_loader

    return data
  end

  def set_suffix(data)

    basicInformationSection_element.div_elements[9].click
    drop_down_element.when_visible
    drop_down_element.list_item_element(:text => "#{data}").click
    wait_for_ajax_loader

    return data
  end

  def set_gender(data)

    basicInformationSection_element.div_elements[15].click

    drop_down_element.when_visible
    drop_down_element.list_item_element(:text => "#{data}").click
    wait_for_ajax_loader

    return data
  end

  def set_address_type(data)
    set_phone_type(data)
  end

  def set_country(data)
    set_suffix(data)
  end

  def set_state(data)
    basicInformationSection_element.div_elements[11].click
    drop_down_element.when_visible
    drop_down_element.list_item_element(:text => "#{data}").click
    wait_for_ajax_loader

    return data
  end

  def set_country_birth(data)
    set_phone_type(data)
  end

  def set_citizenship(data)
    set_suffix(data)
  end

  def set_residence(data)
    set_state(data)
  end

  def set_country_issue(data)
    set_phone_type(data)
  end

  def set_visa_issue_country(data)
    self.visa_section_element.div_element(:class=>'input fancy-select-general').click
    drop_down_element.when_visible
    drop_down_element.list_item_element(:text => "#{data}").click
    wait_for_ajax_loader

    return data
  end

  def set_visa_type(data)
    self.visa_section_element.div_element(:class=>'input fancy-select-general',:index=>1).click
    drop_down_element.when_visible
    drop_down_element.list_item_element(:text => "#{data}").click
    wait_for_ajax_loader

    return data
  end


  def set_prefix_passport(data)
    basicInformationSection_element.div_elements[2].div_element.click
    drop_down_element.when_visible
    drop_down_element.list_item_element(:text => "#{data}").click
    wait_for_ajax_loader
    return data
  end

  def set_suffix_passport(data)
    set_state(data)
  end

  def count_primary_email
         count = email_info_element.h3s(:class=>'primary').count
        return count
  end

  def select_primary_email

        email_data_elements.each_with_index do |primary_email,index|

         if primary_email.text.include? 'Primary'
            self.edit_email_elements[index-1].click
            break
        end

      end
  end

  def gather_error_message
  wait_for_ajax
  self.error_msg.split(/\n/)
  end

  def gather_passport_info
  self.passport_data_elements[0].text.split(/\n/)
  end

  def gather_visa_info
  self.visa_data_elements[0].text.split(/\n/)
  end

  def gather_phone_info
  self.phone_data_elements[0].text.split(/\n/)
  end

  def gather_email_info
  self.email_data_elements[1].text.split(/\n/)
  end

  def gather_mailing_info
  self.address_data_elements[0].text.split(/\n/)
  end

  def random_prefix
    prefix_temp =['Dr.','HRH','Lord','Mayor','Prof.','Rabbi','Rev.','Sen.','Ms.']
    prefix_temp.shuffle(radom: Random).pop
   end

  def random_suffix
    suffix_temp=['Jr.','Sr.','V','VII','III','I','II']
    suffix_temp.shuffle(radom: Random).pop
  end

  def random_country
    country_temp =['Argentina','Canada','Bolivia','Belgium','Ghana']
    country_temp.shuffle(radom: Random).pop
  end

  def random_early_year
  rand(1920..1999).to_s
  end

  def random_later_year
  rand(2000..2019).to_s
  end

  def random_month
  rand(1..12).to_s
  end

  def random_day
  rand(1..28).to_s
  end

  def random_country_code
    rand(10..99).to_s
  end

  def random_area_code
    rand(210..999)
  end

  def random_phone_num
    rand(3423456..9999999)
  end

end