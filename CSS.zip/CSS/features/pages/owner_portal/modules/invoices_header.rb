module InvoicesHeader
  include PageObject

  link(:make_a_payment, text: 'Make a Payment')
  link(:autopay_setup, text: 'Setup AutoPay')
  link(:bank_accounts, text: 'Manage Accounts')
  link(:payment_history, text: 'Payment History')


end