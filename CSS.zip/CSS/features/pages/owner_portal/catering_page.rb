class CateringPage
  include PageObject
  require_relative "../../../features/support/global_settings"
  include GlobalSettings


  link(:save_item,:class=>'btn btn1 save')
  link(:add_item,:class=>'btn add')
  link(:groundTransportation, :class => 'btn btn3 next-step add-ground')
  link(:skipToReviewAndRequest, :class => 'btn btn10 next-step')
  link(:BacktoReservationSum,:class=>'btn btn3 next-step')
  link(:back, :class => 'btn btn13 next-step')
  link(:edit_catering, :class => 'edit btn')
  link(:save_catering, :class => 'btn btn3 btn3-smaller')
  link(:cancel_cat, :class => 'primary', :text => 'Cancel')
  link(:delete_cat, :class => 'delete btn')
  link(:confirm_del, :class => 'btn btn1 confirm')
  link(:dietary, :class => 'show-restrictions show-modal')
   div(:catering_msg,:class => 'grid g5 gmp3')
  div(:sub_menu,:class => 'category-container categories-sub')
  div(:main_menu,:class=>'selected-category')
  div(:dietary_msg,:class => 'modal modal-window dietary-restrictions-overlay')
  sections(:catering_legs,:class=>'flights catering')
  divs(:catering_legs_edit,:class=>'gr clear mode-panel catering-edit-mode')
  ul(:menu_drop,:class=>'catering-categories catering-categories-menu selected')
  divs(:flight_leg,:class=>'flight flight-acc-head clear')
  text_field(:item_quantity,:id=>'item-quantity')

  #****************************************
  # Main Methods
  #****************************************

  def verify_on_catering_page
    verify_on_page('Catering')
  end

  def select_menu menu,leg_num=1

    wait_until(10){catering_legs_elements[leg_num-1].link_element(:class=>'btn add').visible?}
    # wait_for_ajax
    main_menu_element.click

    menu_drop_element.link_element(:text => "#{menu}").click

  end

  def gather_catering_flight_info(leg_num=1)
    self.flight_leg_elements[leg_num-1].text.split(/\n/)
  end

  def verify_on_catering_edit_page
    verify_on_page("/Catering/Edit")
  end

  def select_add_button(leg_num=1)

    catering_legs_elements[leg_num-1].link_element(:class=>'edit btn new-order').when_visible.click
  end

  def select_edit_button(leg_num=1)
      catering_legs_elements[leg_num-1].link_element(:class => 'edit btn').when_present.click
  end

  def select_delete_order(leg_num=1)
    catering_legs_elements[leg_num-1].link_element(:class => 'delete btn').click
  end

  def select_cancel_edit(leg_num=1)
    catering_legs_edit_elements[leg_num-1].list_item_element(:class=>'close clear').click
    end

  def select_save_catering(leg_num=1)
    catering_legs_edit_elements[leg_num-1].link_element(:class => 'btn btn3 btn3-smaller').click
  end


  def select_add_link(leg_number =1)
    addCatering = @browser.link(:text => 'Add', :index => leg_number.to_i-1)
    addCatering.when_present.click
    @browser.link(:text => 'Search', :index => leg_number.to_i-1).wait_until_present # Wait until aircraft details are loaded
  end

  def select_search_link(leg_number =1)
    sleep 3
    search = @browser.link(:text => 'Search', :index => leg_number.to_i-1)
    search.when_present.click
  end

  def set_search_item(cateringItem, leg_number)
    @browser.text_field(:class => 'catering-search-input', :index => leg_number.to_i-1).when_present.set cateringItem
  end

  def select_go_link(leg_number =1)
    go = @browser.link(:text => 'Go', :index => leg_number.to_i-1)
    go.when_present.click
    #sleep 3 #wait to load the results
  end

  def verify_search_results_message(message, leg_number)
    self.wait_for_ajax_loader
    searchResultsMessage = @browser.div(:class => 'search-item-mask', :index => leg_number.to_i-1)
    fail "#{message} message is not displayed from the search results" unless searchResultsMessage.when_present.text.include? message
  end

  def select_catering_item(catering_item, leg_number)
    searchResults = @browser.div(:class => 'result-groups', :index => leg_number.to_i-1)
    searchResults.when_present.lis.each do |item|
      if item.text.strip == catering_item
        p "I am about to click on #{item.text}"
        item.click
        break
      end
    end
  end

  def select_add_catering_item_to_order(message, leg_number)
    searchResults = @browser.div(:class => 'result-groups', :index => leg_number.to_i-1)
    p searchResults.text
    #p "catering item is #{catering_item}"
    #x =  searchResults.when_present.lis.find_index {|item| item.text.strip == catering_item}
    #p "Index is #{x}"

    searchResults.when_present.lis.each_with_index do |item, indexValue|
      #p "item is  - #{item.text} and the index is #{indexValue}"

      #actualItem = item.text.split(" ")
      if item.text.strip == catering_item
        p "I am about to click on #{item.text} and the index is #{indexValue}"
        @browser.link(:class => 'btn add', :index => indexValue).when_present.click # clicking on + icon
        #@browser.div(:class=>'text',:index=>0).when_present.click
        break
      end
    end
  end

  def verify_catering_item_exists(catering_item, leg_number)
    sleep 2
    searchResults = @browser.div(:class => 'result-groups', :index => leg_number.to_i-1)
    fail "#{catering_item} has not found in the results" unless searchResults.when_present.lis.find { |item| item.text.strip == catering_item }
  end

  def select_ground_transportation_button
    #sleep 5
    groundTransportation_element.when_visible(small_wait).click
  end

  def select_skip_to_review_and_request_button
    skipToReviewAndRequest_element.when_visible(small_wait).click
  end

  def select_back_button
    back_element.when_visible(small_wait).click
  end

  def add_catering_item(catering_item,quantity = 5,leg_num=1)
    verify_on_catering_page
    wait_until{catering_legs_edit_elements[leg_num-1].link_element(:text => 'Add',:index=> 1).visible?}
    catering_legs_edit_elements[leg_num-1].link_element(:text =>catering_item).when_present.click
    # wait_for_ajax_loader
    self.item_quantity = quantity.to_s
    self.save_item
    fail "#{catering_item} not added" unless  catering_legs_edit_elements[leg_num-1].unordered_list_element(:class => 'order-items').text.include? catering_item
    end

  #In the catering order page
  def get_catering_items(leg_num=1)
    #verify number of ordered items
    catering_legs_edit_elements[leg_num-1].link_element(:class => 'remove', :index => 0).when_visible
    wait_for_ajax_loader
    catering_num =  catering_legs_edit_elements[leg_num-1].link_elements(:class => 'item-name').count

    ordered_items = []
    for i in 0..(catering_num-1)
      #Gathers catering order into an array
      #sleep 2
      catering_quantity = catering_legs_edit_elements[leg_num-1].text_field_element(:class => 'quantity', :index => i).value
      catering_item =  catering_legs_edit_elements[leg_num-1].link_element(:class => 'item-name', :index => i).text
      ordered_items << catering_quantity.delete(" ") + "x" + catering_item.delete(" ")
    end

    return ordered_items
  end

  def verify_order_summary_catering_items(array_catering_items,leg_num=1)

    #Gathering catering items from the summary page
    catering_legs_elements[leg_num-1].unordered_list_element(:class => 'catering-order-summary').list_item_elements.each do |list|
      #removing all white space
      catering_summary = list.text.delete(" ")
      fail "#{catering_summary} not in the catering summary page" unless array_catering_items.include? catering_summary

    end
  end

  def delete_catering_item (rm_catering,leg_num=1)

    catering_legs_edit_elements[leg_num-1].link_element(:class => 'btn btn3 btn3-smaller').when_visible

    numOfItems =catering_legs_edit_elements[leg_num-1].link_elements(:class => 'item-name').count

    for i in 0..(numOfItems-1)
      currentItem = catering_legs_edit_elements[leg_num-1].link_element(:class => 'item-name', :index => i).text
      if currentItem.strip.downcase == rm_catering.strip.downcase
        catering_legs_edit_elements[leg_num-1].link_element(:class => 'remove', :index => i).when_present.click
        break
      end
    end
  end

  def change_catering_quantity (catering_item,num,leg_num=1)
    wait_for_ajax_loader
    numOfItems = catering_legs_edit_elements[leg_num-1].link_elements(:class => 'item-name').count
    for i in 0..(numOfItems-1)
      currentItem = catering_legs_edit_elements[leg_num-1].link_element(:class => 'item-name', :index => i).text
      if currentItem.strip.downcase == catering_item.strip.downcase
        #Set the quantity.
        catering_legs_edit_elements[leg_num-1].text_field_element(:class => 'quantity', :index => i).value = num
        break
      end
    end
  end


  def verify_food_per_cabin(food_temp,leg_num=1)

    case food_temp

      when 'cold'

        fail "No cold food is servers" unless catering_legs_elements[leg_num-1].unordered_list_element(:class => 'catering-categories-menu clear').text.include? 'Cold'

      when 'hot'

        fail "No hot food is servers" unless catering_legs_elements[leg_num-1].unordered_list_element(:class => 'catering-categories-menu clear').text.include? 'Hot'

    end


  end

  def verify_catering_ordered_item (catering_item,leg_num=1)

  fail "ASI #{catering_item} is not added to the catering order" unless catering_legs_edit_elements[leg_num-1].div_element(:class => 'orders').text.downcase.include? catering_item.downcase

  end

  def select_dietary (leg_num=1)

  catering_legs_edit_elements[leg_num-1].link_element(:class => 'show-restrictions show-modal').when_present.click
  end


  def gather_passenger_dietary_restrictions
    wait_until{dietary_msg_element.visible?}
    name = dietary_msg_element.h3_element.text
    dietary = dietary_msg_element.unordered_list_element.list_item_elements.map{|x|x.text.delete(',')}
    return name,dietary
   end

  #In the catering summary page
  def gather_ordered_catering_items(leg_num = 1)
    catering_legs_elements[leg_num-1].unordered_list_element(:class => 'catering-order-summary').text.split(/\n/)
  end
  #In the catering summary page
  def gather_catering_summary_msg(leg_num=1)
    catering_legs_elements[leg_num-1].div_element(:class=>'grid g5 gmp3').text.split(/\n/)
  end
  #In the catering order page
  def gather_catering_vendor(leg_num =1)
    wait_until(10){catering_legs_elements[leg_num-1].link_element(:class=>'btn add').visible?}
    catering_legs_edit_elements[leg_num-1].div_element(:class=>'caterer-name').when_visible.text
  end


  def gather_catering_order_msg
    wait_until(10){catering_legs_elements[0].link_element(:class=>'btn add').visible?}
    catering_legs_elements[0].div_element(:class=>'caterer-wrap clear').text.sub(/\d\nYour order/, ' ').strip
  end

end