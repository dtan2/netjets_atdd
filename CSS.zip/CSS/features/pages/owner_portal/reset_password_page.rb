class ResetPasswordPage
  include PageObject

  text_field(:password, :id => 'NewPassword')
  text_field(:password_confirmation, :id => 'ConfirmPassword')
  button(:submit_password, :value => 'Confirm & sign in')

  def submit_password_as(password = 'abc123ABC')
    set_password_fields_to password
    submit_password
  end

  def set_password_fields_to(password)
    self.password = password
    self.password_confirmation = password
  end
end