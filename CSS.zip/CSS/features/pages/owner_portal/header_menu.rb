class HeaderMenu
  include PageObject
  require_relative "../../../features/support/global_settings"
  include GlobalSettings
  include TopMenuHeader

  list_item(:flights){|page|page.header_menu_element.list_item_element(:class=>'first done')}
  list_item(:passengers){|page|page.header_menu_element.list_item_element(:class=>'done done2')}
  list_item(:catering){|page|page.header_menu_element.list_item_element(:class=>'done done3')}
  list_item(:ground){|page|page.header_menu_element.list_item_element(:class=>'done done4')}
  list_item(:review){|page|page.header_menu_element.list_item_element(:class=>'review')}
  # link(:profile, :text => 'Profile')
  # link(:account, :text => 'Account')
  # link(:netJetsNews, :text => 'NetJets News')
  # link(:netJetsCom, :text => 'NetJets.com')
  # link(:fleet, :text => 'Fleet')
  # div(:header_menu,:id=>'content')
  ordered_list(:header_menu,:class=>'progress clear')


  #****************************************
  # Main Methods
  #****************************************

  def select_header_flights_link
    @browser.ul(:class => 'complete clear').li(:text => 'Flights').when_present(small_wait).click
  end

  def select_header_profile_link
    profile_element.when_visible(small_wait).click
  end

  def select_header_account_link
    account_element.when_visible(small_wait).click
  end

  def select_header_netjets_news_link
    netJetsNews_element.when_visible(small_wait).click
  end

  def select_header_netjets_com_link
    netJetsCom_element.when_visible(small_wait).click
  end

  def select_header_fleet_link
    fleet_element.when_visible(small_wait).click
  end

  def select_passenger
  self.passengers_element.click
  end

  def select_flights
    self.flights_element.click
  end

  def select_catering
    self.catering_element.click
  end

  def select_ground
    self.ground_element.click
  end

  def select_submit
    self.review_element.click
  end

end