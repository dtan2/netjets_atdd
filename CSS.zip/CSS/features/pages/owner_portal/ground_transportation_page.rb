class GroundPage
  include PageObject
  require_relative "../../../features/support/global_settings"
  include GlobalSettings


  link(:reviewAndRequest, :class => 'btn btn3 next-step')
  link(:neg_reviewAndRequest, :class => 'btn btn3 next-step btn-disbled')
  link(:back, :class => 'btn btn13 next-step')
  link(:skip_to_ground, :class => 'btn btn10 next-step add-ground')
  link(:confirm_del, :class => 'btn btn1', :text => 'Yes')
  link(:cancel, :class => 'primary')
  link(:back_summary, :class => 'btn btn3 next-step')
  divs(:ground_leg, :class => 'choose-transport clear')
  div(:calendar, :class => 'modal calendar clear show')
  text_field(:address, :class => 'text new-address1')
  span(:actual_month, :class => 'month-display')
  span(:passengers, :class => 'passengers')
  unordered_list(:drop_down, :class => 'fancy-select-general-ul open')
  divs(:flight_leg, :class => 'flight clear')
  form(:rental_form, :id => 'order-edit-form-rental')
  form(:chauffeured_form, :id => 'order-edit-form-chauffeured')


  #****************************************
  # Main Methods
  #****************************************

  def verify_on_ground_page
    verify_on_page("Ground")
  end

  def gather_ground_flight_info (leg_num =1)
    self.flight_leg_elements[leg_num-1].text.split(/\n/)
  end

  def gather_chauffeured_form_pickup_time_format
    chauffeured_form_element.div_element(:class => 'fancy-select-wrapper clear', :index => 2).should_not exist
    chauffeured_form_element.div_element(:class => 'fancy-select-wrapper clear').text.split(/\n/).map { |pickup_time| pickup_time.delete(' ') }
  end

  def gather_nje_rental_calendar_return_time_format
    calendar_element.select_list_element(:id => 'depart-time-ampm-').should_not exist
    calendar_element.select_list_element(:id => 'dropoff-hour').text.split(/\n/).map { |return_time| return_time.delete(' ') }
  end

  def gather_rental_form_time_format
    rental_form_element.span_element(:class => 'day').text.split(/\n/)
  end


  def select_review_and_request_button
    reviewAndRequest_element.when_visible(small_wait).click
    #verify_on_page("Ground")
  end

  def select_back_button
    back_element.when_visible(small_wait).click
    #verify_on_page("Ground")
  end

  #****************************************
  # Taxi Methods
  #****************************************
  def add_taxi(leg_num=1)
    # @browser.a(:xpath, "(//div[@data-direction='arrival'])[#{leg_num}]//a[@data-order-type='taxi']").click
    self.ground_leg_elements[leg_num-1].link_element(:class => 'btn add', :index => 3).click

  end

  def delete_taxi(leg)
    @browser.a(:xpath, "(//div[@data-order-type='taxi'])[#{leg}]//a[@data-action='action-delete']").click
    @browser.span(:xpath, "//div[@class='remove-flight-overlay confirmation-overlay modal-window']//span[text()='Yes']").click
  end

  #****************************************
  # Departure Chauffeured Methods
  #****************************************
  def add_departure_chauffeured(leg, chauffeur_data)
    @browser.a(:xpath, "(//div[@data-direction='departure'])[#{leg}]//a[@data-order-type='chauffeured']").click

  end

  def add_dep_chauffeured(leg_num=1)
    self.ground_leg_elements[leg_num-1].link_element(:class => 'btn add').click
  end

  def add_arr_chauffeured(leg_num=1)
    self.ground_leg_elements[leg_num-1].link_element(:class => 'btn add', :index => 1).click
  end

  def add_arr_rental(leg_num=1)

    self.ground_leg_elements[leg_num-1].link_element(:class => 'btn add', :index => 2).click

  end


  def edit_ground_order(leg_num=1)

    ground_leg_elements[leg_num-1].link_element(:text => 'Edit', :index => leg_num-1).click

  end

  def delete_ground_order(leg_num=1)

    ground_leg_elements[leg_num-1].link_element(:text => 'Delete', :index => leg_num-1).click

    confirm_del

  end

  def set_chauffeured_lead_rider(lead)
    wait_for_ajax_loader
    # @browser.div(:class => 'section-data lead-rider').span(:index => 0).click
    # @browser.a(:xpath, "//div[@class='section-data lead-rider']//a[contains(.,'#{lead}')]").click
    chauffeured_form_element.div_element(:class => 'section-data lead-rider').click

    drop_down_element.list_item_element(:text => lead).click
  end


  def set_rental_lead_rider(lead)
    wait_for_ajax_loader
    rental_form_element.div_element(:class => 'section-data lead-rider').click

    drop_down_element.list_item_element(:text => lead).click
  end

  def set_chauffeured_vendor(vendor)
    wait_for_ajax_loader

    chauffeured_form_element.span_element(:class => 'fancy-select-general select-vendor').click

    drop_down_element.list_item_element(:text => vendor).click

  end

  def set_rental_vendor(vendor)
    wait_for_ajax_loader
    rental_form_element.span_element(:class => 'fancy-select-general select-vendor').click
    drop_down_element.list_item_element(:text => vendor).click

  end

  def set_chauffeured_vehicle(type='Sedan (3 + Driver)')
    wait_for_ajax_loader
    chauffeured_form_element.span_element(:class => 'fancy-select-general select-vehicle').click
    drop_down_element.list_item_element(:text => type).click
  end


  def set_rental_vehicle(type='Mid Size')
    wait_for_ajax_loader
    rental_form_element.span_element(:class => 'fancy-select-general select-vehicle').click
    drop_down_element.list_item_element(:text => type).when_present.click
  end


  def add_chauffeured_child_seat(seat_type ='Child seat')

    chauffeured_form_element.link_element(:class => 'btn btn12').click
    chauffeured_form_element.span_element(:class => 'fancy-select-general-value', :index => 3).click
    drop_down_element.list_item_element(:text => seat_type).click

  end

  def add_rental_child_seat(seat_type ='Child seat')

    rental_form_element.link_element(:class => 'btn btn12').click
    rental_form_element.span_element(:class => 'fancy-select-general-value', :index => 3).click
    drop_down_element.list_item_element(:text => seat_type).click

  end

  def set_passengers(riders = ['Rob Higbee', 'Daniel Zukas'])
    #work in progress
    #pass the riders array for a departure chauffeur order
    #flight passengers not in the riders array will have their checkboxes unchecked
    @browser.divs(:class => 'section-data passengers').each do |passenger|
      unless riders.include? passenger.text
        unless rider.checkbox().attribute_value('disabled') == 'true'
          rider_block.checkbox().clear
        end
      end
    end
  end

  def set_chauffeured_billing_type (option = 'Bill through NetJets')
    chauffeured_form_element.label_element(:text => option).click
    chauffeured_form_element.label_element(:text => option).click
    fail "Billing Option -  #{option} has not selected" unless  chauffeured_form_element.label_element(:class => 'fancy-check fancy-checked', :text => "#{option}").when_present.visible?
  end

  def set_rental_billing_type (option = "Use enrollment number")
    rental_form_element.label_element(:text => option).click
    rental_form_element.label_element(:text => option).click
    fail "Billing Option -  #{option} has not selected" unless  rental_form_element.label_element(:class => 'fancy-check fancy-checked', :text => "#{option}").when_present.visible?
  end

  def select_chauffeured_credit_card (card_number)

    chauffeured_form_element.label_element(:text => "Use credit card").click
    if card_number != 'none'
      chauffeured_form_element.span_element(:class => 'fancy-select-general select-creditcard').click
      drop_down_element.list_item_element(:text => card_number).click
      fail "Credit Card not checked" unless chauffeured_form_element.label_element(:class => 'fancy-check fancy-checked', :text => 'Use credit card').visible?
      fail "Credit Card number #{card_number} does not match" unless chauffeured_form_element.span_element(:class => 'fancy-select-general select-creditcard').text[0..16].strip == card_number
    end
  end

  def select_rental_credit_card (card_number)

    rental_form_element.label_element(:text => 'Use credit card').click

    if card_number != 'none'
      rental_form_element.span_element(:class => 'fancy-select-general select-creditcard').click
      drop_down_element.list_item_element(:text => card_number).click
      wait_for_ajax_loader
      fail "Credit Card not checked" unless rental_form_element.label_element(:class => 'fancy-check fancy-checked', :text => 'Use credit card').visible?
      fail "Credit Card number #{card_number} does not match" unless rental_form_element.span_element(:class => 'fancy-select-general select-creditcard').text[0..16].strip == card_number
    end
  end


  def get_dep_ground_passenger_list (passenger_list_res)

    if @browser.div(:class => 'ground-order clear').when_present.text.include? 'Chauffeured vehicle 1'
    else

      if @browser.div(:class => 'ground-order clear').when_present.text.include? 'Rental vehicle 1'
      else
        fail "Not ready to collect passenger list"
      end

    end

    grnd_list_temp = @browser.div(:class => 'ground-order-column ground-order-pax', :index => 0).text.split("\n").drop(1).map { |ground_order_pax| ground_order_pax.gsub(" (Infant)", '') }

    fail "Passenger list not match" unless grnd_list_temp.sort.map { |ground_order_pax| ground_order_pax.downcase.strip } == passenger_list_res.sort.map { |reservation_pax_list| reservation_pax_list.downcase.strip }
   end

  def set_chauffeured_enrollment_number (enrollment_number)

    chauffeured_form_element.label_element(:text => 'Use enrollment number').click
    #set the value in edit box - enrollment_number
    chauffeured_form_element.text_field_element(:class => 'text bill-enrollment-number').value = enrollment_number
    fail "Enrollment number #{enrollment_number} does not match" unless chauffeured_form_element.text_field_element(:class => 'text bill-enrollment-number').value.include? enrollment_number
  end

  def set_rental_enrollment_number (enrollment_number)

    rental_form_element.label_element(:text => "Use enrollment number").click
    #set the value in edit box - enrollment_number
    rental_form_element.text_field_element(:class => 'text bill-enrollment-number').value = enrollment_number
    fail "Enrollment number #{enrollment_number} does not match" unless rental_form_element.text_field_element(:class => 'text bill-enrollment-number').value.include? enrollment_number
  end


  def verify_chauffeured_lead_rider passenger

    fail "#{passenger} is not the lead rider" unless gather_chauffeured_lead_rider.downcase.include? passenger.downcase
  end

  def verify_rental_lead_rider passenger

    fail "#{passenger} is not the lead rider" unless gather_rental_lead_rider.downcase.include? passenger.downcase
  end

  def set_chauffeured_pickup_address
    #(change_pickup = @browser.a(:xpath, "//a[@data-action='action-change-address']")).click if change_pickup.visible?
    if chauffeured_form_element.label_element(:text => 'Select a profile address').visible?
      chauffeured_form_element.label_element(:text => "OR Enter address manually").click
    end

    # ^|{}<>#$&%()' add to address later

    chauffeured_form_element.text_field_element(:class => 'text new-address1').value = 'line 1 test^|{}<>#$&%()/'
    chauffeured_form_element.text_field_element(:class => 'text new-address2').value = 'line 2 test^|{}<>#$&%()/'
    chauffeured_form_element.text_field_element(:class => 'text new-address-city').value = 'city test^|{}<>#$&%()/'
    chauffeured_form_element.text_field_element(:class => 'text new-address-state').value = 'state test^|{}<>#$&%()/'
    chauffeured_form_element.text_field_element(:class => 'text new-address-zip').value = 'zip code test^|{}<>#$&%()/'
  end

  def set_rental_dropoff_address
    #(change_pickup = @browser.a(:xpath, "//a[@data-action='action-change-address']")).click if change_pickup.visible?
    if rental_form_element.label_element(:text => 'Default drop off address').visible?
      rental_form_element.label_element(:text => "OR Enter address manually").click
    end

    # ^|{}<>#$&%()' add to address later

    rental_form_element.text_field_element(:class => 'text new-address1').value = 'line 1 test^|{}<>#$&%()/'
    rental_form_element.text_field_element(:class => 'text new-address2').value = 'line 2 test^|{}<>#$&%()/'
    rental_form_element.text_field_element(:class => 'text new-address-city').value = 'city test^|{}<>#$&%()/'
    rental_form_element.text_field_element(:class => 'text new-address-state').value = 'state test^|{}<>#$&%()/'
    rental_form_element.text_field_element(:class => 'text new-address-zip').value = 'zip code test^|{}<>#$&%()/'
  end

  def set_chauffeured_pickup_time (hour, min, meridian, account_type='NJA')

    chauffeured_form_element.div_element(:class => 'fancy-select-wrapper clear').text_field.value = hour
    chauffeured_form_element.div_element(:class => 'fancy-select-wrapper clear', :index => 1).text_field.value = min

    if account_type !='NJE'
      chauffeured_form_element.div_element(:class => 'fancy-select-wrapper clear', :index => 2).text_field.value = meridian
    end

  end


  #****************************************
  # Arrival Chauffeured Methods
  #****************************************

  def edit_arrival_chauffeured(leg)
    #work in progress
  end

  def delete_arrival_chauffeured(leg)
    #work in progress
  end


  def verify_passenger_vendor_preference lead_passenger

    fail "Wrong ground preference " unless @browser.span(:class => 'fancy-select-general-value', :index => 1).text.downcase.include? lead_passenger.downcase
  end

  #Create departure chauffeured order with enrollment number


  def create_dep_chauffeured_enrollment_num (entered_vehicle_type, lead_passenger, leg_num=1)

    self.wait_for_ajax_loader
    self.add_dep_chauffeured leg_num
    self.chauffeured_form_element.when_visible
    self.wait_for_ajax_loader

    temp_enroll_num =chauffeured_form_element.span_element(:class => 'fancy-select-general-value', :index => 1).when_present.text
    #Getting the enrollment number from GUI
    fail "Enrolment number not checked" unless chauffeured_form_element.label_element(:class => 'fancy-check fancy-checked', :text => 'Use enrollment number').visible?
    sleep 1
    fail "Enrollment number does not match" unless temp_enroll_num.include? chauffeured_form_element.text_field_element(:class => 'text bill-enrollment-number').value
    add_chauffeured_child_seat
    #self.grnd_chauffered entered_vehicle_type ,lead_passenger,account_type
    verify_chauffeured_lead_rider lead_passenger
    #select vehicle drop down
    set_chauffeured_vehicle entered_vehicle_type
    set_chauffeured_pickup_address
    #verify the ground preference
    # fail "Wrong ground preference " unless @browser.span(:class=>'fancy-select-general-value',:index=> 1).text.downcase.include? lead_passenger.downcase
  end


  def create_dep_chauffeured_credit_card (entered_vehicle_type, card_number, lead_passenger, leg_num=1)

    self.wait_for_ajax_loader
    self.add_dep_chauffeured leg_num
    chauffeured_form_element.when_visible
    self.wait_for_ajax
    select_chauffeured_credit_card card_number
    add_chauffeured_child_seat
    verify_chauffeured_lead_rider lead_passenger
    #select vehicle drop down
    set_chauffeured_vehicle entered_vehicle_type
    set_chauffeured_pickup_address
  end


  def create_dep_chauffeured_NJ (entered_vehicle_type, lead_passenger, leg_num=1)

    self.wait_for_ajax_loader
    #click of add departure chauffeured
    self.add_dep_chauffeured leg_num
    self.chauffeured_form_element.when_visible
    self.wait_for_ajax
    #wait for selecting a ground vendor
    set_chauffeured_billing_type
    add_chauffeured_child_seat
    verify_chauffeured_lead_rider lead_passenger
    #select vehicle drop down
    set_chauffeured_vehicle entered_vehicle_type
    set_chauffeured_pickup_address

    # fail "Wrong ground preference " unless @browser.span(:class=>'fancy-select-general-value',:index=> 1).text.downcase.include? lead_passenger.downcase

  end


  def create_arr_chauffeured_enrollment_num (entered_vehicle_type, lead_passenger, leg_num=1)

    self.wait_for_ajax_loader
    #click of add arrival chauffeured
    self.add_arr_chauffeured leg_num
    self.chauffeured_form_element.when_visible
    self.wait_for_ajax
    arr_enroll_num_temp =chauffeured_form_element.span_element(:class => 'fancy-select-general-value', :index => 1).text
    arr_enroll_num = chauffeured_form_element.text_field_element(:class => 'text bill-enrollment-number', :index => 0).when_present.value
    self.wait_for_ajax
    fail "Enrolment number not checked" unless chauffeured_form_element.label_element(:class => 'fancy-check fancy-checked', :text => 'Use enrollment number', :index => 0).visible?
    fail "Enrollment number does not match" unless arr_enroll_num_temp.include? arr_enroll_num

    add_chauffeured_child_seat

    # verify_chauffeured_lead_rider lead_passenger
    #select vehicle drop down

    set_chauffeured_vehicle entered_vehicle_type

    set_chauffeured_pickup_address

    #fail "Wrong ground preference " unless @browser.span(:class=>'fancy-select-general-value',:index=> 1).text.downcase.include? lead_passenger.downcase
  end


  def create_arr_chauffeured_credit_crd (entered_vehicle_type, card_number, lead_passenger, leg_num =1)

    self.wait_for_ajax_loader
    self.add_arr_chauffeured leg_num
    self.chauffeured_form_element.when_visible
    self.wait_for_ajax_loader
    select_chauffeured_credit_card card_number
    add_chauffeured_child_seat
    verify_chauffeured_lead_rider lead_passenger

    #select vehicle drop down
    set_chauffeured_vehicle entered_vehicle_type

    set_chauffeured_pickup_address

    #fail "Wrong ground preference " unless @browser.span(:class=>'fancy-select-general-value',:index=> 1).text.downcase.include? lead_passenger.downcase

  end


  def create_arr_chauffeured_NJ (entered_vehicle_type, lead_passenger, leg_num =1)

    self.wait_for_ajax_loader
    self.add_arr_chauffeured leg_num
    self.chauffeured_form_element.when_visible
    self.wait_for_ajax_loader

    set_chauffeured_billing_type
    #@browser.label(:class => 'fancy-check',:text => 'Bill through NetJets').when_present.click

    #verify the box is checked.

    fail "Bill NJ not checked" unless chauffeured_form_element.label_element(:class => 'fancy-check fancy-checked', :text => 'Bill through NetJets').visible?
    add_chauffeured_child_seat
    verify_chauffeured_lead_rider lead_passenger
    #select vehicle drop down
    set_chauffeured_vehicle entered_vehicle_type
    set_chauffeured_pickup_address

    #fail "Wrong ground preference " unless @browser.span(:class=>'fancy-select-general-value',:index=> 1).text.downcase.include? lead_passenger.downcase

  end


  def create_arr_rental_enrollment_num (vehicle_type, lead_passenger, leg_num =1)

    self.wait_for_ajax_loader
    self.add_arr_rental leg_num
    rental_form_element.when_visible
    self.wait_for_ajax_loader
    verify_rental_lead_rider lead_passenger
    set_rental_vehicle vehicle_type
    set_rental_dropoff_address
    #Geting the enrollment number from lead passenger.
    rental_enroll_num_temp =rental_form_element.span_element(:class => 'fancy-select-general-value', :index => 1).when_present.text

    rental_enroll_num = rental_form_element.text_field_element(:class => 'text bill-enrollment-number', :index => 0).value
    fail "enrollment does not match" unless rental_enroll_num_temp.include? rental_enroll_num

    fail "Enrolment number not checked" unless rental_form_element.label_element(:class => 'fancy-check fancy-checked', :text => 'Use enrollment number', :index => 0).visible?

    add_rental_child_seat

  end


  def set_rental_return_date (return_days, dep_time, flight_time, account_type="NJA")
    rental_form_element.link_element(:text => 'Set return time').when_present.click
    fail "No calender" unless calendar_element.visible?
    drop_off = (dep_time*60*60) + (flight_time.to_i*60*60) + (24*return_days.to_i*60*60)
    #Calling select_date(drop_off,account_type)
    select_rental_dropoff_date(drop_off, account_type)
  end

  #24hrs dropoff
  def set_simple_rental_dropoff
    rental_form_element.link_element(:text => 'Set return time').click
    wait_for_ajax
    calendar_element.link_element(:text => 'Confirm').click
  end


  def create_arr_rental_credit_card (vehicle_type, card_number, lead_passenger, leg_num=1)

    self.wait_for_ajax_loader
    self.add_arr_rental leg_num
    self.rental_form_element.when_visible
    browser.wait_until { browser.text.include? "Adult" }
    self.wait_for_ajax_loader
    verify_rental_lead_rider lead_passenger
    set_rental_vehicle vehicle_type
    select_rental_credit_card card_number
    # select_rental_credit_card card_number
    set_rental_dropoff_address
    sleep 1
    #add child car seat
    add_rental_child_seat


  end


  def delete_all_ground (leg_num =1)

    self.verify_on_ground_page

    begin

      ground_leg_elements[leg_num-1].link_element(:class => 'btn', :text => 'Delete', :index => 0).when_visible
      wait_for_ajax_loader
      ground_leg_elements[leg_num-1].link_element(:class => 'btn', :text => 'Delete', :index => 0).click
      wait_for_ajax_loader
      confirm_del #confirm delete
      wait_for_ajax_loader
      dep = ground_leg_elements[leg_num-1].text.include? "No departure ground transportation"
      wait_for_ajax_loader
      arr = ground_leg_elements[leg_num-1].text.include? "No arrival ground transportation"

    end until dep && arr

  end

  def create_nje_dep_chauffeured (entered_vehicle_type, lead_passenger, leg_num =1)

    self.verify_on_ground_page

    #click of add departure chauffeured
    self.add_dep_chauffeured leg_num
    chauffeured_form_element.when_visible
    self.wait_for_ajax_loader

    verify_chauffeured_lead_rider lead_passenger

    #select vehicle drop down
    set_chauffeured_vehicle entered_vehicle_type
    set_chauffeured_pickup_address

    #Verify FBO is selected for taxi
    if chauffeured_form_element.span_element(:class => 'fancy-select-general-value', :index => 2).text.include? 'Taxi'

      fail 'FBO not selected' unless chauffeured_form_element.span_element(:class => 'fancy-select-general-value', :index => 1).text.include? 'FBO'

    end


    add_chauffeured_child_seat

  end


  def create_nje_arr_chauffeured (entered_vehicle_type, lead_passenger, leg_num=1)

    self.verify_on_ground_page
    add_arr_chauffeured leg_num
    chauffeured_form_element.when_visible
    self.wait_for_ajax_loader

    # chauffeured_form_element.span_element(:class => 'fancy-select-general-value', :text => 'Please select a vendor').wait_while_present
    add_chauffeured_child_seat
    verify_chauffeured_lead_rider lead_passenger
    #select vehicle drop down
    set_chauffeured_vehicle entered_vehicle_type
    set_chauffeured_pickup_address
    #Verify FBO is selected for taxi
    if chauffeured_form_element.span_element(:class => 'fancy-select-general-value', :index => 2).text.include? 'Taxi'

      fail 'FBO not selected' unless chauffeured_form_element.span_element(:class => 'fancy-select-general-value', :index => 1).text.include? 'FBO'

    end

  end

  def create_nje_arr_rental_credit_card (vehicle_type, card_number, lead_passenger, leg_num =1)

    self.verify_on_ground_page
    #Add rental
    self.add_arr_rental leg_num
    rental_form_element.when_visible
    self.wait_for_ajax_loader
    verify_rental_lead_rider lead_passenger
    set_rental_vehicle vehicle_type
    select_rental_credit_card card_number
    set_rental_dropoff_address
    #add child car seat
    add_rental_child_seat

  end

  def select_rental_dropoff_date(noOfhrs, account_type)

    departure_actual_month = calendar_element.span_element(:class => 'month-display')
    departure_next_month = calendar_element.span_element(:class => 'next-but next-month')

    offset_date = Time.now + (noOfhrs) #dep+flighttime+dropoffdays

    expected_day = offset_date.day
    expected_hour = offset_date.hour
    expected_minute = offset_date.min
    expected_month = offset_date.strftime "%B"
    expected_meridian = offset_date.strftime "%p"

    # This Loop make sure we are in right month
    for correct_month in 1..5
      actual_month = departure_actual_month.when_present.text.to_s.strip.downcase # strip the white spaces and downcase
      if expected_month.downcase == actual_month.downcase
        # bolStatus = true
        break
      end
      departure_next_month.when_present.click
    end

    expected_day_element = calendar_element.cell_element(:title => /#{expected_day},/)

    if expected_day_element.attribute("aria-selected") != "true"
      expected_day_element.when_present.click
    end


    if account_type != "NJE"
      calendar_element.div_element(:class => 'field time clear').text_field_element(:index => 0).value = expected_hour # Indexes for Departure Hour is 2,12,22 etc and Arrival Hour is 7,17,27 etc
      calendar_element.div_element(:class => 'field time clear').text_field_element(:index => 1).value = expected_minute # Indexes for Departure Hour is 3,13,23 etc and Arrival Hour is 8,18,28 etc
      calendar_element.div_element(:class => 'field time clear').text_field_element(:index => 2).value = expected_meridian # Indexes for Departure Hour is 4,14,24 etc and Arrival Hour is 9,19,29 etc
    else
      expected_hour = offset_date.strftime "%H"
      calendar_element.div_element(:class => 'field time clear').text_field_element(:index => 0).value = expected_hour # Indexes for Departure Hour is 2,12,22 etc and Arrival Hour is 7,17,27 etc
      calendar_element.div_element(:class => 'field time clear').text_field_element(:index => 1).value = expected_minute # Indexes for Departure Hour is 3,13,23 etc and Arrival Hour is 8,18,28 etc

    end

    ##set the return date and time
    calendar_element.link_element(:class => 'btn btn1 tick', :text => 'Confirm').click

    return offset_date

  end

  def save_chauffeured_order
    chauffeured_form_element.link_element(:class => 'btn btn3 btn3-smaller').click
  end

  def save_rental_order
    rental_form_element.link_element(:class => 'btn btn3 btn3-smaller').when_visible.click
  end


  def gather_taxi(leg_num =1)
    wait_for_ajax_loader
    self.ground_leg_elements[leg_num-1].when_present.text
  end

  def gather_chauffeured_vendor
    chauffeured_form_element.span_element(:class => 'fancy-select-general-value', :index => 1).text.split(/\(/)
  end

  def gather_rental_vendor
    rental_form_element.span_element(:class => 'fancy-select-general-value', :index => 1).text.split(/\(/)
  end

  def gather_chauffeured_lead_rider
    chauffeured_form_element.span_element(:class => 'fancy-select-general-value').text.sub(/\(Adult\)/,'').strip
  end

  def gather_rental_lead_rider
    rental_form_element.span_element(:class => 'fancy-select-general-value').text.sub(/\(Adult\)/,'').strip
  end


end