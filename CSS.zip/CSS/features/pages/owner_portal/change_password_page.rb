class ChangePasswordPage
  include PageObject
  require_relative 'modules/top_menu_header'
  include TopMenuHeader
  include GlobalSettings

  link(:edit_password, :class => 'btn btn1 edit')
  link(:submit_password, :class => 'btn btn1 none save')
  link(:cancel_password, :class => 'btn btn12 cancel')
  link(:log_out, :text => 'Log out')
  text_field(:old_password, :id => 'old-password')
  text_field(:new_password, :id => 'new-password')
  text_field(:confirm_password, :id => 'confirm-password')
  div(:password_drop_down, :class => 'edit-mode username-edit edit-open')
  div(:error_message, :class => 'errors show clear')
  span(:password_msg,:id=>'password-match')
  div(:pop_msg,:id=>'errors')

  def verify_on_chg_password_page
    verify_on_page('ChangePassword')
  end


  def change_password_from_to(from, to)
    sleep 1
    self.edit_password_element.when_visible.click
    self.password_drop_down_element.when_visible
    self.old_password = from
    self.new_password = to
    self.confirm_password = to
    self.submit_password
    wait_for_ajax
  end

  def gather_error_msg
  self.error_message.split(/\n/)
  end

  def gather_pop_msg
  self.pop_msg.split(/\n/)
  end



end