class RequestedReservationPage < ReviewAndRequest
  include PageObject
  include DataMagic
  require_relative "../../../features/support/global_settings"
  include GlobalSettings
  require 'yaml'

  link(:yes_cancel, :class => 'btn btn1 tick', :index => 1)
  link(:edit_flight, :class => 'edit btn', :index => 0)
  link(:edit_passenger, :class => 'edit btn', :index => 1)
  link(:edit_ground, :class => 'btn edit')
  links(:edit, :class => 'edit btn')
  div(:reservation_num, :class => 'intro clear')
  divs(:flights, :class => 'flight-details')
  divs(:flights_header, :class => 'flight-head clear')
  #****************************************
  # Main Methods
  #****************************************

  def verify_on_requested_reservation_page
    verify_on_page("RequestedReservation")
  end

  def select_flight(leg_number =1)
    sleep 3
    flight_leg_list = @browser.ul(:class => 'flight-list')

    flight_leg_list.when_present.lis.each do |flight_number|
      actual_flight_number = flight_number.text.split(" ")
      if actual_flight_number.at(1).to_i == leg_number.to_i
        flight_number.click
        break
      end
    end
  end

  def select_edit_flight(leg_num = 1)
    edit_departure = self.flights_elements[leg_num-1].link_element(:text => 'Edit flight')
    edit_departure.when_present.click
    verify_on_page("Flights")
  end

  def select_edit_passengers(leg_num = 1)
    edit_departure = self.flights_elements[leg_num-1].link_element(:text => 'Edit passengers')
    edit_departure.when_present.click
    verify_on_page("Passengers")
  end

  def select_edit_catering(leg_num = 1)
    edit_departure = self.flights_elements[leg_num-1].link_element(:text => 'Edit catering')
    edit_departure.when_present.click
    verify_on_page("Catering")
  end


  def select_edit_ground(leg_num = 1)
    edit_departure = self.flights_elements[leg_num-1].link_element(:text => 'Edit ground transportation')
    edit_departure.when_present.click
    verify_on_page("Ground")
  end


  def verify_aircraft_details(aircraft_name, leg_num)
    aircraft = self.flights_elements[leg_num-1].div_element(:class => 'section aircraft clear')
    fail "#{aircraft_name} is not displayed under the Aircraft section" unless aircraft.when_present.text.include? aircraft_name

  end

  def verify_departure_airport_details(airport_name_or_time, leg_num)
    aircraft = self.flights_elements[leg_num-1].div_element(:class => 'section departure clear')
    fail "#{airport_name_or_time} is not displayed under the Departure section" unless aircraft.text.gsub("\n", " ").include? airport_name_or_time
  end

  def verify_arrival_airport_details(airport_name_or_time, leg_num=1)
    aircraft = self.flights_elements[leg_num-1].div_element(:class => 'section arrival clear')
    fail "#{airport_name_or_time} is not displayed under the Departure section" unless aircraft.text.gsub("\n", " ").include? airport_name_or_time
  end

  def verify_arrival_time_details(noOfHours, leg_num=1)
    aircraft = self.flights_elements[leg_num-1].div_element(:class => 'section arrival clear')

    noOfHours = noOfHours.to_i
    offset_date = Time.now + (noOfHours*60*60) #offset_date =   Time.now + (noOfDays *24*60*60)

    expected_year = offset_date.year
    expected_day = offset_date.day
                                               #expected_hour = offset_date.hour
                                               #expected_minute = offset_date.min
    expected_week = offset_date.strftime "%a"
                                               #expected_meridian = offset_date.strftime "%p"
    expected_month = offset_date.strftime "%b"

    expected_time = "#{expected_week} #{expected_day} #{expected_month} #{expected_year}"
                                               #expectedTime = ":#{expected_minute}#{expected_meridian}, #{expected_week} #{expected_day} #{expected_month} #{expected_year}"

    fail "#{expected_time} is not displayed under the Departure section" unless aircraft.text.include? expected_time
  end

  def verify_passengers_exists(passenger_name, leg_num=1)
    #@browser.link(:class=> 'res-details res-passengers', :index=> leg_number.to_i-1).click
    passenger_exists = self.flights_elements[leg_num-1].div_element(:class => 'section passengers clear')
    p "#{passenger_exists.text} and the index is #{leg_number.to_i-1}"
    fail "#{passenger_name} is not displayed under the Passenger List" unless passenger_exists.text.include? passenger_name
  end


  def verify_passengers_not_exists(passenger_name, leg_num=1)
    #@browser.link(:class=> 'res-details res-passengers', :index=> leg_number.to_i-1).click
    passenger__not_exists = self.flights_elements[leg_num-1].div_elment(:class => 'section passengers clear')
    fail "#{passenger_name} is displayed under the Passenger List" if passenger_not_exists.text.include? passenger_name
  end

  def select_cancel_flight_button (leg_num=1)
    self.flights_header_elements[leg_num-1].form_element(:class => 'cancel-reservation-flight').click
    self.yes_cancel
  end

  def verify_catering_item_submitted catering_item
    fail "#{catering_item} not added to catering order" unless @browser.ul(:class => 'catering-order-summary').text.include? catering_item
  end

  def gather_reservation_num
    reservation_number = self.reservation_num_element.text.split(/#/).map { |reservation_text| reservation_text[/\d+/] }
    return reservation_number[1]
  end

  class FlightSummary
    attr_accessor :departure, :arrival, :departure_time, :departure_date, :arrival_time, :arrival_date, :departure_fbo, :arrival_fbo

  end

  def gather_departure_itinerary(leg_num=1)

    data = self.flights_elements[leg_num-1].div_element(:class => 'row clear', :index => 1).text.split(/\n/)

    departure = data[0]
    departure_fbo = data[2]
    departure_time =data[3]
    departure_date =data[4]
    summary_dept = FlightSummary.new
    summary_dept.departure = departure
    summary_dept.departure_fbo = departure_fbo
    summary_dept.departure_time = departure_time
    summary_dept.departure_date = departure_date

    return summary_dept
  end

  def gather_arrival_itinerary(leg_num=1)

    data = self.flights_elements[leg_num-1].div_element(:class => 'row clear', :index => 2).text.split(/\n/)

    arrival = data[0]
    arrival_fbo = data[2]
    arrival_time =data[3]
    arrival_date =data[4]
    summary_arrl = FlightSummary.new
    summary_arrl.departure = arrival
    summary_arrl.departure_fbo = arrival_fbo
    summary_arrl.departure_time = arrival_time
    summary_arrl.departure_date = arrival_date

    return summary_arrl
  end

  def gather_contract_info(leg_num=1)
    self.flights_elements[leg_num-1].div_element(:class => 'row clear').text.split(/\n/)
  end


  def gather_passenger_list(leg_num=1)
    self.flights_elements[leg_num-1].div_element(:class => 'reservation-block clear', :index => 1).text.split(/\n/).map { |pax_list| pax_list.gsub(/\(lead passenger\)/, '').strip }
  end

  def gather_catering_order(leg_num=1)
    self.flights_elements[leg_num-1].div_element(:class => 'reservation-block clear', :index => 2).text.split(/\n/)
  end

  def gather_departure_ground_order(leg_num=1)
    self.flights_elements[leg_num-1].div_element(:class => 'reservation-block clear', :index => 3).div_element(:class => 'row clear').text.split(/\n/)
  end

  def gather_arrival_ground_order(leg_num=1)
    self.flights_elements[leg_num-1].div_element(:class => 'reservation-block clear', :index => 3).div_element(:class => 'row clear', :index => 1).text.split(/\n/)
  end

  def gather_rental_ground_order(leg_num=1)
    self.flights_elements[leg_num-1].div_element(:class => 'reservation-block clear', :index => 3).div_element(:class => 'row clear', :index => 2).text.split(/\n/)
  end


end



