class FlightsEditPage < FlightsPage

  def verify_on_flights_edit_page
    verify_on_page("Edit")
  end

  def select_save_exit_button
    sleep 4
    #@browser.span(:text=>'Save & Exit').click
    @browser.link(:class => 'btn btn3 next-step add-passengers').click
    verify_on_page("RequestedReservation")
  end

end