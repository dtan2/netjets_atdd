class Individual
  include Workflow
  require_relative '../css_admin/enrollment_status'
  include EnrollmentStatus

  attr_reader :workflow_state

  def enrollment_status=(status)
    status.downcase!
    status.gsub!(' ','_')
    persist_workflow_state(status)
  end

  def get_individual_into_desired_state(desired_state)
    #Get the individual's current state
    #Get the path to the desired state

  end

end