class NetjetsWebmailLoginPage
  include PageObject
  require_relative "../../../features/support/global_settings"
  include GlobalSettings

  text_field(:username, :id => 'username')
  text_field(:password, :id => 'password')
  button(:sign_in_button, :value => 'Sign in')

  def login_to_webmail
    open_webmail
    webmail_login
  end

  def open_webmail
    @browser.goto 'https://owa.netjets.com/owa/auth/logon.aspx?replaceCurrent=1&url=https%3a%2f%2fowa.netjets.com%2fowa%2fcss-project-dev%40netjets.com%2f'
  end

  def webmail_login
    self.username = 'cmh\QATESTER'
    self.password = 'abc123ABC'
    sign_in_button
  end

end