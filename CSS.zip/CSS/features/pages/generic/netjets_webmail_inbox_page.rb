class NetjetsWebmailInboxPage
  include PageObject
  require_relative "../../../features/support/global_settings"
  include GlobalSettings

  divs(:enrollment_email, :id => 'vr')
  link(:enrollment_link, :text => 'Complete Your Enrollment')
  link(:reset_password, :text => 'Reset Your Password')
  div(:email_loaded_check, :id => 'divExp')
  div(:email_body,:id=>'divBdy')
  div(:email_panel,:id=>'divList')
  divs(:email_list){|page|page.email_panel_element.div_elements(:id=>'vr')}
  #================================
  #Main Methods
  #================================

  def close
    window = @browser.window(:url => /owa.netjets.com/).use
    begin
    window.close
    rescue => exceptions
      puts exceptions
    end
  end

  def open_complete_self_enrollment_page(email_address = 'kat@redrobin.com')
    find_enrollment_link(email_address)
    enrollment_link
    close
    @browser.window(:url => /CompleteSelfEnrollment/).use
  end

  def open_complete_enrollment_page(email_address = Session[:user_email])
    find_enrollment_link(email_address)
    enrollment_link
    close
    @browser.window(:title => /Enroll/).use
  end

  def reset_password_for_user(email_address = $user_email)
    @browser.window(:title => 'css-project-dev - Outlook Web App').use
    find_reset_password_link(email_address)
    reset_password
    close
  end

  #================================
  #Builder Methods for Main Methods
  #================================

  #opens emails from top to bottom based upon index numbering
  def open_email(index)
    wait_until{enrollment_email_elements.count > 0}
    # enrollment_email_elements[index].when_visible.click
    email_list_elements[index].when_visible.click
  end

  def check_complete_enrollment(email_address)
    email_loaded_check_element.when_visible
    email_loaded_check_element.when_visible
    if enrollment_link_element.visible?
      enrollment_link_element.attribute('href').sub('%40', '@').include? email_address
    else
      false #enrollment_link was not visible
    end
  end

  def check_reset_password(email_address)
    email_loaded_check_element.when_visible
    email_loaded_check_element.when_visible
    if reset_password_element.visible?
      reset_password_element.attribute('href').sub('%40', '@').include? email_address
    else
      false #enrollment_link was not visible
    end
  end

  def find_enrollment_link(email_address)
    sleep 2
    wait_until{email_list_elements.count > 0}
    email_list_elements.each do |enrollment_link|
    enrollment_link.click
    link_found = check_complete_enrollment email_address
    return link_found
    break

    end
    # i = 0
    # link_found = false
    # until link_found == true
    #   open_email i
    #   link_found = check_complete_enrollment email_address
    #   i += 1
    #   break if i > 10
    # end
    # unless link_found == true
    #   # fail "Enrollment link for email: #{email_address} not found"
    # end
    # return link_found
  end

  def find_reset_password_link(email_address)
    password_link = 0
    link_found = false
    until link_found == true
      open_email password_link
      link_found = check_reset_password email_address
      password_link += 1
      break if password_link > 10
    end
    unless link_found == true
      fail "Reset Password link for email: #{email_address} not found"
    end
    return link_found
  end

  def verify_reservation_notes_email(reservation_num,user_id,notes)

    email_body = email_body_element.text.split("\n")

    email_body[4].should include reservation_num
    email_body[16].should include user_id
    email_body[7].should include notes

    return email_body
  end

   def verify_recent_reservation_notes(recent_notes)

   @email_body[7].should include recent_notes

   end

    def verify_previous_reservation_notes(previous_notes)

    @email_body[11].should include previous_notes
    end

  def gather_email_body
  email_body_element.text.split("\n")
  end



end