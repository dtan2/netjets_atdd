class EnrollPage
  include PageObject

  def set_enrollment_link_in_new_browser(linkDetails)
    #@@newBrowser = create_new_browser
    #@@newBrowser.goto linkDetails
    @browser.goto linkDetails
  end


  def set_security_question(answer)

    @browser.text_field(:id => 'SecretAnswer').set answer

  end

  def set_security_question_reset_password(answer)

    @browser.text_field(:id => 'secret-question').set answer

  end

  def set_next_button()
   @browser.button(:class=>'btn btn3').click
  end

 def complete_enrollment()

   @browser.text_field(:id => 'Password').set 'abc123ABC'
   @browser.text_field(:id => 'PasswordRepeat').set 'abc123ABC'
   @browser.checkbox(:id => 'AcceptedTerms').set
   @browser.button(:class => 'btn btn3').click
 end

  def complete_enrollment_password_mismatch()

    @browser.text_field(:id => 'Password').set 'abc123ABC'
    @browser.text_field(:id => 'PasswordRepeat').set 'abcdfdfaBC'
    @browser.checkbox(:id => 'AcceptedTerms').set
    @browser.button(:class => 'btn btn3').click
  end
  ########################################################################

  def Password_Reset()

    @browser.text_field(:id => 'NewPassword').set 'abc123ABC'
    @browser.text_field(:id => 'ConfirmPassword').set 'abc123ABC'
    @browser.button(:class => 'btn btn3').click
  end


  def new_browser_css_admin()
    #@@newBrowser = create_new_browser
    #@@newBrowser.goto linkDetails
    @browser.goto  'http://securityserviceqa.webservice.netjets.com/css-admin-web/login'
  end

  def Owner_portal_login(userid,password)
    @browser.goto  'http://flyqa.netjets.com/Account/Authenticate/LogOn?unauthorized=true'
    @browser.text_field(:id => 'UserName').set userid
    @browser.text_field(:id => 'Password').set password
    @browser.button(:class => 'btn btn3').click
  end

  def open_browser()
    @browser.goto  'http://flyqa.netjets.com/Account/Authenticate/LogOn?unauthorized=true'
  end
def op_login(userid,password)
  @browser.text_field(:id => 'UserName').set userid
  @browser.text_field(:id => 'Password').set password
  @browser.button(:class => 'btn btn3').click
end

  def login_admin_verify_status(map)
    @browser.goto  'http://securityserviceqa.webservice.netjets.com/css-admin-web/login'
    @browser.text_field(:id => 'j_username').set map['username']
    @browser.text_field(:id => 'j_password').set map['password']
    @browser.button(:id => 'loginButton').click
  end

  def password_reset_owner_portal()
 @browser.link(:text => 'Reset your password').click
  end

  def set_username_password_reset_owner_portal(user_email)
    @browser.text_field(:id => 'UserName').set user_email
    @browser.button(:class => 'btn btn3').click
  end

  def change_password()
     @browser.link(:text => 'Profile').click
     @browser.link(:text => 'Username & Password').click
     @browser.link(:text => 'Edit').click
  end

  def set_oldpassword_for_change_password(arg1)
    sleep 2
    @browser.text_field(:id => 'old-password').set arg1
  end

  def set_newpassword_for_change_password(arg1)
    @browser.text_field(:id => 'new-password').set arg1
  end

  def set_confirmpassword_for_change_password(arg1)
    @browser.text_field(:id => 'confirm-password').set arg1
  end

  def set_Save_password_change()
   @browser.link(:text => 'Save').click
  end

  def signout_op()
    @browser.link(:text => 'Sign out').click
  end

end