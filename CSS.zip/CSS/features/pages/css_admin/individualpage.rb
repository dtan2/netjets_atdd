class IndividualPage
  include PageObject
  require 'win32ole'
  #require_relative '../../../features/support/global_settings'
  include GlobalSettings
  require_relative 'modules/individual_actions_module'
  include IndividualActions

  ###################################################################################################################
  # BEGIN Page interactions via page-object
  ###################################################################################################################

  text_field(:account_search_field, :id => 'accountName')
  text_field(:individual_search_field, :id => 'lastName')
  button(:account_search_button, :text => /Search Accounts/)
  button(:individual_search_button, :id => 'findLastNameButton')
  button(:account_activity_button, :text => /View Activity/)
  button(:individual_actions, class: 'btn btn-primary dropdown-toggle')
  link(:advanced_search_link, :text => /Advanced Search/)
  link(:previous_page_link, :class => 'prevLink')
  link(:next_page_link, :class => 'nextLink')
  link(:enroll_action_link, :text => /Enroll/)
  link(:reset_password_action_link, :text => /Reset Password/)
  link(:disable_user_action_link, :text => /Disable User/)
  link(:enable_user_action, :text => /Enable User/)
  link(:update_q_and_a_action_link, :text => /Update Question \/ Answer/)
  link(:impersonate_action_link, :text => /Impersonate/)
  link(:view_activity_action_link, :text => /View Activity/)
  link(:resend_enrollment_action_link, :text => /Resend Enrollment/)
  link(:delete_enrollment_action_link, :text => /Delete Enrollment/)
  link(:confirm_action,:id=>'confirm')
  link(:unlock_user_account, :text => /Unlock User/)
  div(:action_drop,:class=>'btn-group inline pull-right open')
  unordered_list(:action_dropdown){|page|page.action_drop_element.unordered_list_element(:class=>'dropdown-menu')}
  div(:individual_table, :id => 'individualsZone')
  div(:result,:id=>'resultsSection')
  div(:msg_section,:class=>'span12')
  div(:result_msg,:id=>'messageSection')
  div(:error_msg,:class=>'alert alert-info')
  div(:process_info){|page|page.error_msg_element.div_element(:text=>'Your request has been processed.')}
  div(:pagination,:class=>'pagination')
  link(:next){|page|page.pagination_element.link_element(:class=>'nextLink')}

  table(:individual_list, :class => 'table')
  # table(:individuals, class: 'table')
  unordered_list(:actions_available, class: 'dropdown-menu')

  ###################################################################################################################
  # END Page interactions via page-object
  ###################################################################################################################

  ###################################################################################################################
  # BEGIN Work In Progress Methods
  ###################################################################################################################

  ###################################################################################################################
  # End Work In Progress Methods
  ###################################################################################################################

  ###################################################################################################################
  # BEGIN Main Methods
  ###################################################################################################################
  def verify_on_individual_page
      verify_on_page('/account/view/')
  end

  def available_actions_for(user)
    user_details = find_user_on_page(user)
    user_details.unordered_list_element.collect { |action| action.text }
  end

  def enroll_a_not_enrolled_user
    user = get_first_not_enrolled_user_id
    Session[:user_id] = user
    # $user_id = user
    # enroll_user(user, $user_security)
    enroll_user(user, Session[:question],Session[:answer])
    # $user_email = get_email_of_user(user)
  Session[:user_email] = get_email_of_user(user)
  end

  def get_security_answer_of_user(user)
    user_details = collect_user_details_of_user(user)
    user_details.each do |detail|
      if detail.include? 'Answer:'
        return detail.gsub('Answer:', '').strip
      end
    end
  end

  def get_security_question_of_user(user)
    user_details = collect_user_details_of_user(user)
    user_details.each do |detail|
      if detail.include? 'Security Question:'
        return detail.gsub('Security Question:', '').strip
      end
    end
  end

  def get_enrollment_status_of_user(user)
    user_details = collect_user_details_of_user(user)
    user_details.each do |detail|
      if detail.include? 'Enrollment Status:'
        return detail.gsub('Enrollment Status:', '').strip
      end
    end
  end

  def get_email_of_user(user)
    #wait_until do
    #  individual_message = individual_list_element.tr(:id => "#{user}").div(:id => /individualMessage/)
    #  individual_message.when_present.attribute_value('style').include? 'display: none'
    #  sleep 1
    #end
    # wait_for_confirmation_message user
    user_details = collect_user_details_of_user(user)
    user_details.each do |detail|
      if detail.include? 'Email:'
        return detail.gsub('Email:', '').strip
      end
    end
  end

  def get_first_not_enrolled_user_id
    until individual_list_element.text.include? 'NOT ENROLLED'
      next_page_link_element.click
    end
    individual_list_element.each do |user|
      if user.text.include? 'NOT ENROLLED'
        return user.attribute('id')
      end
    end
  end

  def  clean_up_enrollment(user_id)

    data = collect_user_details_of_user user_id

    if data.include? 'Enrollment Status: ACTIVE'
    self.select_action user_id,'Disable User'
    wait_for_processing user_id
    self.select_action user_id,'Delete Enrollment'
    wait_for_processing user_id
    elsif temp = (data.include? 'Enrollment Status: PENDING') || (data.include? 'Enrollment Status: DISABLED')
      temp || (data.include? 'Enrollment Status: EXPIRED')
    self.select_action user_id,'Delete Enrollment'
    wait_for_processing user_id
    end
  end

  def wait_for_processing (user)
    sleep 2
    wait_until{!individual_list_element.div_element(:id=>"individualMessage#{user}",:text=>'Your request has been processed.').visible?}
  end




###################################################################################################################
# END Main Methods
###################################################################################################################

###################################################################################################################
# BEGIN Builder Methods
###################################################################################################################

  def collect_user_details_of_user(user)
    user_details = find_user_on_page(user)
    user_details.paragraph_elements.collect do |paragraph|
    paragraph.text
    end
  end

  #def find_user_on_page(user)
  #  while user_on_page?(user) == false
  #    next_page_link_element.when_visible.click
  #  end
  #  individual_list_element.tr(:id => "#{user}").when_present
  #end

  def find_user_on_page(user)
    #while user_on_page?(user) == false
    #  next_page_link_element.when_visible.click
    #end
    #individual_list_element.each do |row|
    #  if row.attribute('id') == user
    #    return row
    #  end
    #end
    next_page_link_element.when_visible.click until user_on_page?(user)
    individual_list_element.find { |row| row.attribute('id') == user }
  end

  def user_on_page?(user)
    users = individual_list_element.collect{ |row| row.attribute('id') }
    users.include? user
  end

  def select_action (user,action)
  self.click_actions_button_for user
  self.action_dropdown_element.list_item_element(:text=>action).click
  sleep 1
  self.confirm_action_element.when_visible.click
  end



  def click_actions_button_for(user)
    #individual_list_element.tr(:id=>"#{user}").button(:class=>'btn btn-primary dropdown-toggle').click
    user_details = find_user_on_page(user)
    user_details.button_element.click
    #user_details.button(:class => 'btn btn-primary dropdown-toggle').click
  end

  def get_available_actions_for_user(user)
    click_actions_button_for user
    user_details = find_user_on_page(user)
    user_details.unordered_list_element.collect { |action| action.text }
    #user_details.ul(class: 'dropdown-menu').lis.collect do |list_item|
    #  list_item.text.strip
    #end
  end

###################################################################################################################
# END Action Button Behaviors
###################################################################################################################

  def enrollment_status_to(status)
#    Enrollment status flows
#    NOT ENROLLED > PENDING
#    PENDING > NOT ENROLLED
#    PENDING > EXPIRED
#    PENDING > ACTIVE
#    EXPIRED > PENDING
#    EXPIRED > NOT ENROLLED
#    ACTIVE > DISABLED
#    ACTIVE > LOCKED
#    DISABLED > ACTIVE
#    DISABLED > NOT ENROLLED
#    LOCKED > ACTIVE
    case @enroll_status
      when 'NOT ENROLLED'
        case status
          when 'PENDING'
            #TODO: add flow logic
            enroll_action_for 'user'

            @enroll_status = 'PENDING'
          else
            fail "Unexpected end status of #{status}"
        end
      when 'PENDING'
        case status
          when 'NOT ENROLLED'
            #TODO: add flow logic
            @enroll_status = 'NOT ENROLLED'
          when 'EXPIRED'
            #TODO: add flow logic
            @enroll_status = 'EXPIRED'
          when 'ACTIVE'
            #TODO: add flow logic
            @enroll_status = 'ACTIVE'
          else
            fail "Unexpected end status of #{status}"
        end
      when 'EXPIRED'
        case status
          when 'PENDING'
            #TODO: add flow logic
            @enroll_status = 'PENDING'
          when 'NOT ENROLLED'
            #TODO: add flow logic
            @enroll_status = 'NOT ENROLLED'
          else
            fail "Unexpected end status of #{status}"
        end
      when 'ACTIVE'
        case status
          when 'DISABLED'
            #TODO: add flow logic
            @enroll_status = 'DISABLED'
          when 'LOCKED'
            #TODO: add flow logic
            @enroll_status = 'LOCKED'
          else
            fail "Unexpected end status of #{status}"
        end
      when 'DISABLED'
        case status
          when 'ACTIVE'
            #TODO: add flow logic
            @enroll_status = 'ACTIVE'
          when 'NOT ENROLLED'
            #TODO: add flow logic
            @enroll_status = 'NOT ENROLLED'
          else
            fail "Unexpected end status of #{status}"
        end
      when 'LOCKED'
        case status
          when 'ACTIVE'
            #TODO: add flow logic
            @enroll_status = 'ACTIVE'
          else
            fail "Unexpected end status: #{status}"
        end
      else
        fail "Unexpected current enrollment status: #{@enroll_status}"
    end
  end

###################################################################################################################
# Old code below
###################################################################################################################


  def select_action_in_all_pages(enrollmentStatus, actionItem)

    number_of_results = get_count_results()

    action_item_found = select_action_in_current_page(number_of_results, enrollmentStatus, actionItem)
    arrival_state = action_item_found.split(" ")
    until (arrival_state.at(0) != "false") and self.next_element.visible?
      self.next
      number_of_results = get_count_results()
      action_item_found = select_action_in_current_page(number_of_results, enrollmentStatus, actionItem)
      arrival_state = action_item_found.split(" ")
    end
    return (arrival_state.at(1).to_i) -1
  end


  def get_count_results()
    @browser.tds(:style => "text-align:right;").count
  end


  def select_action_in_current_page(noOfResults, enrollmentStatus, actionItem)
    action_item_found = "false"
    for enrollment in 0..noOfResults-1

      if @browser.td(:style => "text-align:right;", :index => enrollment).text.include? enrollmentStatus
        @browser.button(:class => "btn btn-primary dropdown-toggle", :index => enrollment-1).click
        @browser.ul(:class => 'dropdown-menu', :index => enrollment-1).lis.each do |action|
          if action.text.include? actionItem
            sleep 4
            action.click
            action_item_found = "true"
            sleep 5
            p "Inside the function - #{action_item_found} #{enrollment}"
            return "#{action_item_found} #{enrollment}"
          end
          enrollmentStatus
        end
      end

    end
    return actionItemFound
  end


  def verify_action(index, verify, message)
    sleep 10
    case verify
      when "Security Question"
        expected_text = "Security Question: " + message
      when "Answer"
        expected_text = "Answer: " + message
      when "initiate enrollment"
        expected_text = "Enrollment Status: " + message
      when "deleting a Pending enrollment"
        expected_text = "Enrollment Status: " + message
      else
        p "No Text Found"

    end

    fail "#{expected_text} message is not displayed " unless @browser.table(:class => 'table')[index].text.include? expected_text
  end


  def verify_view_activity(userid, actionitem, date, createdby)
    sleep 10
    fail "#{userid} message is not displayed " unless @browser.table(:class => 'table table-bordered')[1][1].text.include? userid
    fail "#{actionitem} not found" unless @browser.table(:class => 'table table-bordered')[1][2].text.include? actionitem
    user_name = Time.now()
    user_name_temp = user_name.strftime "%a %b %d"
    fail "#{date} not found" unless @browser.table(:class => 'table table-bordered')[1][4].text.include? user_name_temp
    fail "#{createdby} not found" unless @browser.table(:class => 'table table-bordered')[1][5].text.include? createdby
  end

  def verify_text_enrollment_page(message)
    sleep 10
    fail "The text - #{message} has not found in the page " unless @browser.div(:class => 'modal hide fade in').text.include? message
  end

######################################################################################################################
#############################Owner Portal Actions ####################################################################

  def confirmation_yes()
    sleep 2
    @browser.div(:id => 'confirm-modal').a(:id => "confirm").click
  end

  def confirmation_no()
    sleep 2
    @browser.a(:id => "cancel").click
  end

  def update_questionanswer(question, answer)
    sleep 2
    @browser.select_list(:id => 'question').select question
    @browser.text_field(:id => 'answer').set answer
  end

  def update_button()
    @browser.button(:id => 'enrollButton').click
    sleep 6
  end

  def enrollment(email_address, question, answer)

    @browser.div(:class => 'modal hide fade in').text_field(:id => 'emailAddress').set email_address
    @browser.select_list(:id => 'question').select question
    @browser.text_field(:id => 'answer').set answer
    @browser.button(:id => 'enrollButton').click

  end


  def input_box(message, title="Message from #{__FILE__}")
    vb_msg = %Q| "#{message.gsub("\n", '"& vbcrlf &"')}"|
    vb_msg.gsub!("\t", '"& vbtab &"')
    vb_msg.gsub!('&""&', '&')
    vb_title = %Q|"#{title}"|
    # go!
    sc = WIN32OLE.new("ScriptControl")
    sc.language = "VBScript"
    sc.eval(%Q|Inputbox(#{vb_msg}, #{vb_title})|)
    #~ sc.eval(%Q|Inputbox(#{vb_msg}, #{vb_title}, aa,hide)|)
  end

######################################################################################################
##########################Checking Eligibility - Owner Portal Actions


  def verify_action_in_all_pages(enrollmentStatus, actionItem)
    sleep 8
    number_of_results = get_count_results()
    action_item_found = verify_action_in_current_page(number_of_results, enrollmentStatus, actionItem)
    arrival_state = action_item_found.split(" ")
    until (arrival_state.at(0) != "false") and (@browser.a(:class => "nextLink").exist?)
      @browser.a(:class => "nextLink").click
      number_of_results = get_count_results()
      #action_item_found = verify_action_in_current_page(number_of_results, enrollmentStatus, actionItem)
    end
    return (arrival_state.at(1).to_i) -1
  end


  def verify_action_in_current_page(noOfResults, enrollmentStatus, actionItem)
    action_item_found = "false"
    for index_value in 0..noOfResults-1
      if @browser.td(:style => "text-align:right;", :index => index_value).text.include? enrollmentStatus
        @browser.button(:class => "btn btn-primary dropdown-toggle", :index => index_value-1).click
        @browser.ul(:class => 'dropdown-menu', :index => index_value-1).lis.each do |action|
          if action.text.include? actionItem
            #p "#{actionItem} found"
            action_item_found = "true"
            @browser.button(:class => "btn btn-primary dropdown-toggle", :index => index_value-1).click
            p "Action Item Found #{actionItem}"
            return "#{action_item_found} #{index_value}"
          end
          enrollmentStatus
        end
        fail "#{actionItem} not found ..test Failed" unless action_item_found == "true"
        return action_item_found
      end
    end
    return action_item_found
  end


########################################################################
##########################Individual Page Pagination############################################


  def verify_pagination()
    wait_for_ajax
    number_of_results = self.individual_list_element.rows
    expect(number_of_results.to_i-1).to be <= 25
    while self.next_element.visible? do
      self.next
      number_of_results = self.individual_list_element.rows
    expect(number_of_results.to_i-1).to be <= 25
    end


  end

####################################Account Page Pagination###################################################

  def account_verify_pagination()
    wait_for_ajax
    number_of_results = self.individual_list_element.rows
     expect(number_of_results.to_i).to be <= 25
    while self.next_element.visible? do
      self.next

      number_of_results = self.individual_list_element.rows
    expect(number_of_results.to_i).to be <= 25
    end


  end

#############################################################################

  def individual_search_by_last_name(last_name)

    @browser.text_field(:id => 'lastName').set last_name
    @browser.button(:class => 'btn btn-small btn-primary', :index => 1).click

  end

##################################################################################

  def verify_enrollment_status(enrollmentStatus, emailaddress)

    number_of_results = get_count_results()
    enrollment_status_found = verify_enrollment_status_current_page(number_of_results, enrollmentStatus, emailaddress)
    arrival_state = enrollment_status_found.split(" ")
    until (arrival_state.at(0) != "false") and (@browser.a(:class => "nextLink").exist?)
      @browser.a(:class => "nextLink").click


      number_of_results = get_count_results()
      #enrollment_status_found = verify_enrollment_status_current_page(number_of_results, enrollmentStatus, emailaddress)

    end
    return (arrival_state.at(1).to_i) -1
  end


  def verify_enrollment_status_current_page(noOfResults, enrollmentStatus, emailaddress)
    enrollment_status_found = "false"
    for index_value in 0..noOfResults-1

      #fail "The text - #{message} has not found in the page " unless @browser.td(:style => "text-align:right;", :index=>i).text.include? enrollmentStatus

      #@browser.button(:class => "btn btn-primary dropdown-toggle", :index=>i-1).click

      #@browser.ul(:class=> 'dropdown-menu', :index=>i-1).lis.each do |action|
      #
      if @browser.td(:style => "text-align:right;", :index => index_value).text.include? emailaddress #enrollmentStatus
        fail "The Enrollment status #{enrollmentStatus} not found  for #{emailaddress}" unless @browser.td(:style => "text-align:right;", :index => index_value).text.include? enrollmentStatus
        enrollment_status_found = "true"
        p "Enrollment Status  #{enrollmentStatus} found for #{emailaddress}"
        return "#{enrollment_status_found} #{index_value}"
      end
      #  enrollmentStatus
      #end
      #fail "#{actionItem} not found ..test Failed" unless actionItemFound == "true"
      #return actionItemFound
      #  fail "The text - #{message} has not found in the page " unless @browser.div(:class => 'text-alt').text.include? message
      #end

    end

    return enrollment_status_found
  end

  def gather_individual_from_result
  self.individual_list_element.row.text.split(/\n/)
  end


###############################################################################################################################


end
