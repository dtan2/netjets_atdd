class SelfEnrollPage
  include PageObject
  require_relative "../../../features/support/global_settings"
  include GlobalSettings
  include DataMagic

  DataMagic.yml_directory = "features/support/page_input_data"

  text_field(:email_id, :id => 'Email')
  button(:next_button, :class => 'btn btn3')
  div(:error_validation_box, :class => 'validation-summary-errors validation-error')

  def enroll_with(email)
    self.email_id = email
  end

  def submit_enrollment(data =:red_robin_self)
    DataMagic.load('self_enroll.yml')
    populate_page_with data_for(data)
    next_button
  end

  # def submit_enrollment_route (email = 'kat@redrobin.com')
  # submit_enrollment(email)
  # end

  def error_validation(text)
    error_validation_box_element.text.should == text
  end





end