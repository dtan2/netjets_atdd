class CompleteSelfEnrollPage
  include PageObject
  require_relative "../../../features/support/global_settings"
  include GlobalSettings

  radio_button(:toll_free_radio, :id =>'account-tollfree' )
  radio_button(:ar_number_radio, :id => 'account-number')
  radio_button(:personal_phone,:id=>'account-phone')
  text_field(:account_identifier_field, :id => 'AccountNumber')
  span(:security_question_drop_down, :class => 'fancy-select-general-value')
  ul(:security_question_list, :class => 'fancy-select-general-ul')
  text_field(:security_answer, :id => 'SecretAnswer')
  text_field(:password_field, :id => 'Password')
  text_field(:repeat_password_field, :id => 'PasswordRepeat')
  checkbox(:eula_checkbox, :id => 'accept')
  button(:submit_button, :id => 'submit')

  #================================
  #Main Methods
  #================================

  def set_identifier (phone_number)
  # self.personal_phone_element.select
  self.account_identifier_field = phone_number
  end

  def complete_self_enrollment(key = 'enroll_with_ar_num')
    #populates self enroll page with happy path data and submits the enrollment
    populate_self_enroll_data(key)
    submit_button
  end

  def verify_on_complete_self_enroll_page
    verify_on_page 'CompleteSelfEnrollment'
  end

  def validate_toll_free_num(phone_number)
    #method will use active-record to call the database and validate the account's Phone Number
    phone_number == 1234567890
  end

  #================================
  #Builder Methods for Main Methods
  #================================

  def populate_self_enroll_data(key)

    InputDataHelper.load_yml("self_enroll")
    map =InputDataHelper.get_map(key)

    # set_account_identifier(map)
    set_security_question map['sec_question']
    self.security_answer = map['sec_answer']
    self.password_field = map['password']
    self.repeat_password_field = map['password_repeat']
    check_eula_checkbox
  end


  def set_toll_free_num(phone_number)
    toll_free_radio_element.select
    self.account_identifier_field = phone_number
  end

  def validate_ar_num(ar_number)
    #method will use active-record to call the database and validate the account's AR Number
    ar_number == 1234567
  end

  def set_ar_num(ar_number)
    ar_number_radio_element.select
    self.account_identifier_field = ar_number
  end

  def set_security_question(index)
    #index values correspond to questions
    # *  0 - "Select from the questions provided"
    # *  1 - "What was your childhood nickname?"
    # *  3 - "What is the name of your favorite childhood friend?"
    # *  4 - "What is the middle name of your oldest child"
    # *  5 - "What is your oldest sibling's middle name?"
    # *  6 - "In what city or town did your mother and father meet?"
    # *  7 - "In what city does your nearest sibling live?"
    # *  8 - "What is your maternal grandmother's name?"
    # *  9 - "In what city or town was your first job?"
    # * 10 - "What street did you live on in third grade?"
    # * 11 - "What is your oldest sibling's birthday month and year?"
    # * 12 - "What school did you attend for sixth grade?"
    security_question_drop_down_element.click
    security_question_list_element[index].click
  end

  def complete_self_enrollment_route
    complete_self_enrollment()
  end

  #radio is either 'ar_number' or 'phone_number'

  #def set_account_identifier(id_type, id)
  #  if id_type == 'enroll_with_ar_num'
  #    set_ar_num id
  #  elsif id_type == 'enroll_with_toll_free_num'
  #    set_toll_free_num id
  #  else
  #    fail "Invalid radio selection of #{identifier}, expecting: 'ar_number' or 'phone_number'"
  #  end
  #end

  def set_account_identifier(key)
    if key['identifier_type'] == 'ar_num'
      set_ar_num key['identifier_num']
    elsif key['identifier_type'] == 'phone_num'
      set_toll_free_num key['identifier_num']
    else
      fail "Invalid radio selection of #{key['identifier_type']}, expecting: 'ar_number' or 'phone_number'"
    end
  end

  def set_self_enroll_info_toll_free (identifier)
    toll_free_radio_element.when_visible.click
    set_identifier identifier
    populate_self_enroll_data(key = 'enroll_with_ar_num')
    submit_button
  end


end