class AdvancedSearchPage
  include PageObject
  require_relative '../../../features/support/global_settings'
  include GlobalSettings

  text_field(:account_field, :id => 'accountName')
  text_field(:first_name_field, :id => 'principalFirstName')
  text_field(:last_name_field, :id => 'principalLastName')
  text_field(:card_number_field, :id => 'cardNumber')
  button(:all_programs_filter, :text => /All Programs/)
  button(:nj_us_button_filter, :text => /NJ US/)
  button(:nje_button_filter, :text => /NJ Europe/)
  button(:search_button, :id => 'searchButton')
  radio_button(:valid_status_radial, :text => /Active, Credit Watch, Restricted/)
  radio_button(:all_status_radial, :text => /All/)
  link(:basic_search_link, :text => /Basic Search/)

end