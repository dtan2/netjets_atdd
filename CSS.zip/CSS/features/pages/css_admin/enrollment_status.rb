module EnrollmentStatus

  Individual.workflow do
    state :not_enrolled do
      event :request_enrollment, :transitions_to => :pending
      event :request_self_enrollment, :transitions_to => :pending
    end
    state :pending do
      event :delete_enrollment, :transitions_to => :not_enrolled
      event :expire_enrollment, :transitions_to => :expired
      event :expire_self_enrollment, :transitions_to => :expired
      event :complete_enrollment, :transitions_to => :active
      event :complete_self_enrollment, :transitions_to => :active
    end
    state :expired do
      event :delete_enrollment, :transitions_to => :not_enrolled
      event :resend_enrollment, :transitions_to => :pending
    end
    state :active do
      event :disable_user, :transitions_to => :disabled
      event :lock_user, :transitions_to => :locked
    end
    state :disabled do
      event :enable_user, :transitions_to => :active
      event :delete_enrollment, :transitions_to => :not_enrolled
    end
    state :locked do
      event :unlock, :transitions_to => :active
    end
  end

  def request_enrollment
    Event.all
  end

  def set_enrollment_status_to(status)
    if self.workflow_state == status
      puts 'user is in the expected status'
    else
      puts 'something'
    end

  end

  def collect_events

  end

  private
  def enrollment_status_to_not_enrolled

  end

  def enrollment_status_to_pending

  end

  def enrollment_status_to_expired

  end

  def enrollment_status_to_active

  end

  def enrollment_status_to_disabled

  end

  def enrollment_status_to_locked

  end
  public


end