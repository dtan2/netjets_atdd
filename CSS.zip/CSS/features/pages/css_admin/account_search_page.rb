class AccountSearchPage
  include PageObject
  require_relative '../../../features/support/global_settings'
  include GlobalSettings
  require_relative '../../../features/pages/css_admin/advanced_search_page'
  require 'rspec'
  include RSpec

  text_field(:account_field, :id => 'accountName')
  button(:search_button, :id => 'searchButton')
  button(:all_programs_filter, :text => /All Programs/)
  button(:nj_us_button_filter, :text => /NJ US/)
  button(:nje_button_filter, :text => /NJ Europe/)
  link(:advanced_search_link, :text => /Advanced Search/)
  # table(:search_results_table, :xpath => '//div[@id="resultsSection"]/div/div/table')
  table(:table_result, :class => 'table')
  div(:result_section, :id => 'resultsSection')
  div(:result_text) { |page| page.result_section_element.div_element(:class => 'alert alert-info') }
  div(:warning_msg, :class => 'alert alert-warn')
  div(:alert_msg, :class => 'alert alert-error')

  def verify_on_page
    @browser.wait_until(large_wait, "Login page has not loaded") do
      @browser.text.include? 'Search Accounts'
    end
  end

  def gather_account_name
    account_name_temp =[]
    table_result_element.each do |row|
      account_name_temp << row.text
    end
    msg = account_name_temp.map { |account_name| account_name.split(/\n/) }

    final_account_name =[]
    msg.each do |data|
      final_account_name << data[0]
    end
    return final_account_name

  end


  def search_from_yaml
    InputDataHelper.load_yml('css_admin_data')
    account = InputDataHelper.get_map('account_search')
    sleep 2
    search_for(account['default'])
    open_account(account['default'])
  end

  def search_for(account)
    self.account_field = account
    search_button
  end

  def open_account(account)
    self.table_result_element.each do |row|
      # search_results_table_element.each do | row |
      if row.cell_element.h3_element.text.downcase == account.downcase
        row.click
        return
      end
    end
    # search_results_table_element.each do | row |
    #   if row[0].account_name_element.text.downcase == account.downcase
    #     row.click
    #     return
    #   end
    # end

  end

  def get_account_status_for(account)
    table_result_element.each do |row|
      if row.cell_element.h3_element.text.downcase == account.downcase
        status = row.cell_element(index: 1).div_element.text.gsub('Account Status:', '').strip
        return status
      end
    end
  end

  ###################################################################################################################
  # Old code below
  ###################################################################################################################

  def set_account_search_field(accstatus, map)


    case accstatus
      when "Active"
        actname = map['NJA_Active']
      when "Credit Card Only"
        actname = map['NJA_Credit_Card_Only']
      when "Credit Hold"
        actname = map['NJA_Credit_Hold']
      when "Credit Limit"
        actname = map['NJA_Credit_Limit']
      when "Credit Watch"
        actname = map['NJA_Credit_Watch']
      when "Restricted"
        actname = map['NJA_Restricted']
      when "Inactive"
        actname = map['NJA_Inactive']
      when "Termination Pending"
        actname = map['NJA_Termination']
      when "Account_Name"
        actname = map['Account_Actions']

      when "NJE_Active"
        actname = map['NJE_Active']
      when "NJE_Credit Card Only"
        actname = map['NJE_Credit_Card_Only']
      when "NJE_Credit Hold"
        actname = map['NJE_Credit_Hold']
      when "NJE_Credit Limit"
        actname = map['NJE_Credit_Limit']
      when "NJE_Credit Watch"
        actname = map['NJE_Credit_Watch']
      when "NJE_Restricted"
        actname = map['NJE_Restricted']
      when "NJE_Inactive"
        actname = map['NJE_Inactive']
      when "NJE_Termination Pending"
        actname = map['NJE_Termination']
      when "Account_Name"
        actname = map['Account_Actions']
      else
        actname = accstatus
    end
    @browser.text_field(:id => 'accountName').set actname
    @browser.button(:id => 'searchButton').click

    return actname

  end


  def select_account(accountName)
    table_results = @browser.table(:class => 'table')
    #p "Results Table text is #{resultsTable.text}"
    results_search = @browser.trs(:style => "cursor:hand; cursor:pointer;").count
    for account_name in 0..results_search
      #p "The TR value is #{resultsTable[i].text}"
      get_account_name = resultsTable[account_name].text.split(/\n/)

      if get_account_name.at(0) == accountName
        table_results[account_name].click
        break
      end
    end

  end

  ########################################################################################################################################
  def select_program_filter(filter)
    sleep 10
    case filter
      when "NJ US"
        @browser.button(:id => 'nja').click
      when "NJ Europe"
        @browser.button(:id => 'nje').click

      else
        nil
      #  p "No Text Found"

    end


    #fail "#{expText} message is not displayed " unless @browser.table(:class=>'table')[index].text.include? expText
  end

  ########################################################################################################################################
  #advanced search#


  def click_advanced_search_link()
    @browser.link(:text => 'Advanced Search').click

  end


  def set_advanced_account_lastName(val)
    @browser.text_field(:id => 'principalLastName').set val
  end

  def set_advanced_account_firstName(val)
    @browser.text_field(:id => 'principalFirstName').set val
  end

  def set_advanced_account_cardNumber(val)
    @browser.text_field(:id => 'cardNumber').set val
  end

  def set_advanced_account_acctstatus()
    @browser.radio(:class => 'input-xlarge').set
  end

  def set_search()
    @browser.button(:id => 'searchButton').click
  end

  def get_account_in_status(status)
    #SELECT a.account_name,
    #       COUNT(a.account_name) AS CONTRACT_STATUS
    #FROM account a,
    #             contract c
    #WHERE a.accountid         = c.acct_id
    #AND c.contract_status_id IN (1,4)
    #AND a.program_id         IN (1000011,1000021)
    #AND a.account_status_cd   = 'W'
    #GROUP BY a.account_name
    #-- account_status_cd = 'A'
    #-- status 'Active'
    #-- #=> Columbus Blue Jackets
    #
    #-- account_status_cd = 'C'
    #-- status 'Credit Card Only'
    #-- #=> <no data>
    #
    #-- account_status_cd = 'H'
    #-- status 'Credit Hold'
    #-- #=> Dallas Capital Management
    #
    #-- account_status_cd = 'I'
    #-- status 'Inactive'
    #-- #=> <no data>
    #
    #-- account_status_cd = 'L'
    #-- status 'Credit Limit'
    #-- #=> <no data>
    #
    #-- account_status_cd = 'R'
    #-- status 'Restricted'
    #-- #=> The Legacy Agency, Inc.
    #
    #-- account_status_cd = 'T'
    #-- status 'Termination Pending'
    #-- #=> <no data>
    #
    #-- account_status_cd = 'W'
    #-- status 'Credit Watch'
    #-- #=> Falcon United International, Inc.
    #;
  end


end




