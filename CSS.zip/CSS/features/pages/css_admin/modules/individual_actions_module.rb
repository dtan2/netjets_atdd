module IndividualActions
  include PageObject

  text_field(:email_address_field, :id => 'emailAddress')
  text_field(:security_answer_field, :id => 'answer')
  select_list(:security_question_list, :id => 'question')
  select_list(:email_list, :id => 'emailAddressSuggestion')
  button(:enroll_button, :id => 'enrollButton')
  button(:cancel_button, :id => 'cancelButton')
  link(:yes_button, :id => 'confirm')
  link(:no_button, :id => 'cancel')
  table(:activity_log, :class => 'table table-bordered')
  div(:actions_modal_overlay, :class => 'modal hide fade in')
  div(:confirmation_message, :id => /individualMessage/)
  div(:enroll_form, :class => 'modal-body')

  ###################################################################################################################
  # BEGIN Main Methods
  ###################################################################################################################

  def enroll_user(user, question, answer, email=nil)
    enroll_action_for(user)
    actions_modal_overlay_element.when_visible
    # email_address_field_element.when_visible(10)
    #if email_list_element.present? == true
    #  email_list_element.when_visible.options[1].click
    #else
    #  self.email_address_field = (0...8).map { (65 + rand(26)).chr }.join.downcase + '@netjets.com'
    #end
    set_email_address email
    set_security_question_and_answer(question, answer)
    enroll_button
    wait_for_confirmation_message(user)
  end

  def update_security_q_and_a_for_user(user, security={})
    update_q_and_a_action_for(user)
    set_security_question_and_answer(security[:question], security[:answer])
    enroll_button
  end

  def resend_enrollment_email_to_user(user)
    resend_enrollment_action_for(user)
    wait_for_confirmation_overlay
    wait_for_confirmation_overlay
    yes_button_element.when_visible.click
    wait_for_confirmation_message(user)
  end

  def delete_enrollment_for_user(user)
    delete_enrollment_action_for(user)
    wait_for_confirmation_overlay
    wait_for_confirmation_overlay
    yes_button_element.when_visible.click
    wait_for_confirmation_message(user)
  end

  def view_activity_for_user(user)
    view_activity_action_for(user)
  end

  def unlock_account_for_user(user)
    unlock_action_for user
    wait_for_confirmation_overlay
    wait_for_confirmation_overlay
    yes_button_element.when_visible.click
    wait_for_confirmation_message(user)
  end

  def disable_account_for_user(user)
    disable_user_action_for user
    wait_for_confirmation_overlay
    wait_for_confirmation_overlay
    yes_button_element.when_visible.click
    wait_for_confirmation_message(user)
  end

  def enable_account_for_user(user)
    enable_user user
    wait_for_confirmation_overlay
    wait_for_confirmation_overlay
    yes_button_element.when_visible.click
    wait_for_confirmation_message(user)
  end

  def reset_password_for_user(user)
    reset_password_action_for user
    wait_for_confirmation_overlay
    wait_for_confirmation_overlay
    yes_button_element.when_visible.click
    wait_for_confirmation_message(user)
  end

  ###################################################################################################################
  # END Main Methods
  ###################################################################################################################

  ###################################################################################################################
  # BEGIN Builder Methods
  ###################################################################################################################

  def set_email_address(email=nil)
    if email != nil
      self.email_address_field = email
      # elsif email_list_element.present?
      #   email_list_element.when_visible.options[1].click
    else
      self.email_address_field = (0...8).map { (65 + rand(26)).chr }.join.downcase + '@netjets.com'
    end
  end

  def wait_for_confirmation_overlay
    actions_modal_overlay_element.when_visible
  end

  def wait_for_confirmation_message(user)
    user_details = find_user_on_page(user)
    confirmation_message = user_details.div_element(id: /individualMessage/)
    begin
      confirmation_message.when_visible(3)
    rescue
    end
    # if confirmation_message.visible?
    #   wait_until do
    #     user_details.div_element(id: /individualMessage/).visible? #stale element reference occurring sleep added above
    #   end
    # end
  end

  def reset_password_action_for(user)
    click_actions_button_for(user)
    reset_password_action_link_element.click
  end

  def disable_user_action_for(user)
    click_actions_button_for(user)
    disable_user_action_link_element.click
  end

  def enable_user(user)
    click_actions_button_for(user)
    enable_user_action_element.click
  end

  def update_q_and_a_action_for(user)
    click_actions_button_for(user)
    update_q_and_a_action_link_element.click
  end

  def impersonate_action_for(user)
    click_actions_button_for(user)
    impersonate_action_link_element.click
  end

  def view_activity_action_for(user)
    click_actions_button_for(user)
    view_activity_action_link_element.click
  end

  def resend_enrollment_action_for(user)
    click_actions_button_for(user)
    resend_enrollment_action_link_element.click
  end

  def delete_enrollment_action_for(user)
    click_actions_button_for(user)
    delete_enrollment_action_link_element.click
  end

  def enroll_action_for(user)
    click_actions_button_for(user)
    enroll_action_link_element.click
  end

  def unlock_action_for(user)
    click_actions_button_for(user)
    unlock_user_account_element.click
  end

  def get_security_question_option_number(question)
    security_question_list_element.when_visible.options.each do |option|
      if option.text.include? question
        return option.attribute('value').to_i
      end
    end
  end

  def set_security_question_and_answer(question, answer)
    question_index = get_security_question_option_number(question)
    security_question_list_element.when_visible.options[question_index].click
    self.security_answer_field = answer if answer != 'null'
  end

  def get_recent_activity_log_for_user(user)
    view_activity_for_user user
    activity_log_element.when_visible(10)
    recent_activity = get_activity_from_last_minutes
    return recent_activity
  end

  def get_activity_from_last_minutes(minutes=3)
    # activity_log_element.tbody.trs.collect do |row|
    data = activity_log_element.cell_elements.collect { |activity| activity }
    # date_time = DateTime.strptime(row.cell(:index => 4).text, '%a %b %d %H:%M:%S %Z %Y').to_time
    date_time = DateTime.strptime(data[4].text, '%a %b %d %H:%M:%S %Z %Y').to_time
    if date_time > (Time.now - (3 * 60))
      Hash[:user_id => (data[1].text),
           :event_description => (data[2].text),
           :additional_info => (data[3].text),
           :date_created => (data[4].text),
           :created_by => (data[5].text)]
    end
  end

  def log_entry_user_id_include?(user, log)
    log[:user_id].include? user
  end

  def log_entry_event_desc_include?(event, log)
    log[:event_description].include? event
  end

  def log_entry_info_include?(info, log)
    log[:additional_info].include? info
  end

  def log_entry_date_created_include?(time_stamp, log)
    log[:date_created].include? time_stamp
  end

  def log_entry_created_by_include?(created_by, log)
    log[:created_by].include? created_by
  end


  ###################################################################################################################
  # END Builder Methods
  ###################################################################################################################

end