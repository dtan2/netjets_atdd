module EnrollmentWorkflow


  def get_enrollment_status_of(individual_id)
    individual_table_element.table.trs.each do |row|
      if row.attribute_value('id').should == individual_id
        @enroll_status = return_included_status(row.td(:index => 1).p(:index => 1).text)
      end
    end
  end

  def set_enrollment_status_to(status)
    case @enroll_status
      when 'NOT ENROLLED'
        set_not_enrolled_status_to status
      when 'PENDING'
        set_pending_status_to status
      when 'EXPIRED'
        set_expired_status_to status
      when 'ACTIVE'
        set_active_status_to status
      when 'DISABLED'
        set_disabled_status_to status
      when 'LOCKED'
        set_locked_status_to status
      else
        fail "Unexpected current enrollment status of: '#{status}'"
    end
  end

  def return_included_status(text)
    case text
      when /NOT ENROLLED/
        'NOT ENROLLED'
      when /PENDING/
        'PENDING'
      when /EXPIRED/
        'EXPIRED'
      when /ACTIVE/
        'ACTIVE'
      when /DISABLED/
        'DISABLED'
      when /LOCKED/
        'LOCKED'
      else
        fail 'Expected status is not present'
    end
  end

  def set_not_enrolled_status_to(status)
    case status
      when 'PENDING'
        enrollment_status_workflow_to status
      when 'EXPIRED'
        enrollment_status_workflow_to 'PENDING'
        enrollment_status_workflow_to status
      when 'ACTIVE'
        enrollment_status_workflow_to 'PENDING'
        enrollment_status_workflow_to status
      when 'DISABLED'
        enrollment_status_workflow_to 'PENDING'
        enrollment_status_workflow_to 'ACTIVE'
        enrollment_status_workflow_to status
      when 'LOCKED'
        enrollment_status_workflow_to 'PENDING'
        enrollment_status_workflow_to 'ACTIVE'
        enrollment_status_workflow_to status
      else
        fail "Unexpected end status of: '#{status}'"
    end
  end

  def set_pending_status_to(status)
    case status
      when 'NOT ENROLLED'
        enrollment_status_workflow_to status
      when 'EXPIRED'
        enrollment_status_workflow_to status
      when 'ACTIVE'
        enrollment_status_workflow_to status
      when 'DISABLED'
        enrollment_status_workflow_to 'ACTIVE'
        enrollment_status_workflow_to status
      when 'LOCKED'
        enrollment_status_workflow_to 'ACTIVE'
        enrollment_status_workflow_to status
      else
        fail "Unexpected end status of #{status}"
    end
  end

  def set_expired_status_to(status)
    case status
      when 'NOT ENROLLED'
        enrollment_status_workflow_to status
      when 'PENDING'
        enrollment_status_workflow_to 'NOT ENROLLED'
        enrollment_status_workflow_to status
      when 'ACTIVE'
        enrollment_status_workflow_to 'NOT ENROLLED'
        enrollment_status_workflow_to 'PENDING'
        enrollment_status_workflow_to status
      when 'DISABLED'
        enrollment_status_workflow_to 'NOT ENROLLED'
        enrollment_status_workflow_to 'PENDING'
        enrollment_status_workflow_to 'ACTIVE'
        enrollment_status_workflow_to status
      when 'LOCKED'
        enrollment_status_workflow_to 'NOT ENROLLED'
        enrollment_status_workflow_to 'PENDING'
        enrollment_status_workflow_to 'ACTIVE'
        enrollment_status_workflow_to status
      else
        fail "Unexpected end status of #{status}"
    end
  end

  def set_active_status_to(status)
    case status
      when 'NOT ENROLLED'
        enrollment_status_workflow_to 'DISABLED'
        enrollment_status_workflow_to status
      when 'PENDING'
        enrollment_status_workflow_to 'DISABLED'
        enrollment_status_workflow_to 'NOT ENROLLED'
        enrollment_status_workflow_to status
      when 'EXPIRED'
        enrollment_status_workflow_to 'DISABLED'
        enrollment_status_workflow_to 'NOT ENROLLED'
        enrollment_status_workflow_to 'PENDING'
        enrollment_status_workflow_to status
      when 'DISABLED'
        enrollment_status_workflow_to status
      when 'LOCKED'
        enrollment_status_workflow_to status
      else
        fail "Unexpected end status of #{status}"
    end
  end

  def set_disabled_status_to(status)
    case status
      when 'NOT ENROLLED'
        enrollment_status_workflow_to status
      when 'PENDING'
        enrollment_status_workflow_to 'NOT ENROLLED'
        enrollment_status_workflow_to status
      when 'EXPIRED'
        enrollment_status_workflow_to 'NOT ENROLLED'
        enrollment_status_workflow_to 'PENDING'
        enrollment_status_workflow_to status
      when 'ACTIVE'
        enrollment_status_workflow_to status
      when 'LOCKED'
        enrollment_status_workflow_to 'ACTIVE'
        enrollment_status_workflow_to status
      else
        fail "Unexpected end status of #{status}"
    end
  end

  def set_locked_status_to(status)
    case status
      when 'NOT ENROLLED'
        enrollment_status_workflow_to 'ACTIVE'
        enrollment_status_workflow_to 'DISABLED'
        enrollment_status_workflow_to status
      when 'PENDING'
        enrollment_status_workflow_to 'ACTIVE'
        enrollment_status_workflow_to 'DISABLED'
        enrollment_status_workflow_to 'NOT ENROLLED'
        enrollment_status_workflow_to status
      when 'EXPIRED'
        enrollment_status_workflow_to 'ACTIVE'
        enrollment_status_workflow_to 'DISABLED'
        enrollment_status_workflow_to 'NOT ENROLLED'
        enrollment_status_workflow_to 'PENDING'
        enrollment_status_workflow_to status
      when 'DISABLED'
        enrollment_status_workflow_to 'ACTIVE'
        enrollment_status_workflow_to status
      when 'ACTIVE'
        enrollment_status_workflow_to status
      else
        fail "Unexpected end status of #{status}"
    end
  end


end