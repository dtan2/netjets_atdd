class CssAdminLoginPage
  include PageObject
  require_relative '../../../features/support/global_settings'
  include GlobalSettings

  text_field(:username_field, :id => 'j_username')
  text_field(:password_field, :id => 'j_password')
  button(:login_button, :id => 'loginButton')


  def open_css_admin_url
    @browser.goto(select_login_url 'op_admin_login')
  end

  def login_credentials(username, password)
    username_field_element.when_visible
    self.username_field = username
    self.password_field = password
    login_button
    obj_current_page = AccountSearchPage.new(@browser)
    obj_current_page.verify_on_page
  end

  def login_to_css_admin_with(credentials = 'qa_login')
    InputDataHelper.load_yml('css_admin_data')
    login = InputDataHelper.get_map(credentials)
    Session[:osr_user] = login['username']
    open_css_admin_url
    wait_until {login_button_element.visible?}
    login_credentials(login['username'], login['password'])
  end

  ###################################################################################################################
  # Old code below
  ###################################################################################################################

  def set_login_username_password (map)
    sleep 2
    @browser.text_field(:id => 'j_username').set map['username']
    @browser.text_field(:id => 'j_password').set map['password']
    @browser.button(:id => 'loginButton').click
  end


  def verify_text_resend_enrollment(message)
    sleep 5
    p "Actual text -#{@browser.div(:class => 'alert alert-info',:index=>1).text}"
    p "Expected text - #{message}"
    fail "The text - #{message} has not found in the page " unless @browser.div(:class => 'alert alert-info',:index=>1).text.include? message

  end

  def verify_OP_landingpage(message)
    sleep 5
    fail "The text - #{message} has not found in the page " unless @browser.div(:class => 'text-alt').text.include? message
  end


end