class SelfEnrollConfirmPage
  include PageObject
  require_relative "../../../features/support/global_settings"
  include GlobalSettings

  div(:text_box, :class => 'login clear')
  link(:sign_in, :class => 'sign-out')

  def verify_on__enrollment_confirm_page
    verify_on_page ('/Account/Enroll/SelfEnrollmentConfirm')
  end
  def validate_text_box(text)
    text_box_element.text.should == text
  end

  def go_to_login_page
    sign_in
  end

end