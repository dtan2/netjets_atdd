module GlobalSettings
  require 'yaml'
  require 'base64'

  #SMALL_WAIT = 10
  #LARGE_WAIT = 20

  def small_wait
    10
  end

  def large_wait
    20
  end

  def wait_for_object(objName)
    @browser.wait_until(large_wait,"#{objName} not visible") do
      #p "I am inside wait_for_object function and the value is #{objName.exist?}"
      objName.exist?
    end
  end

  def verify_on_page(pageName)
    @browser.wait_until(large_wait,"#{pageName} page has not loaded") do
      @browser.url.include? pageName
    end
    #p "I have sucessfully verified the #{pageName} page has loaded"
  end

  def verify_text_exists(text)
    @browser.wait_until(large_wait,"#{text} - does not exists on the page") do
      @browser.text.include? text
    end
  end

  def wait_for_loading_overlay
    #@browser.div(:class => 'curtain').wait_until_present 2
    #@browser.div(:class => 'curtain').wait_while_present
    @browser.div(:id => 'spinner').wait_while_present #mgraf -- basing off spinner now as it's more reliable
  end

  def wait_for_ajax_loader
    while @browser.div(:class => /ajax-loader/).present?
      @browser.div(:class => /ajax-loader/).wait_while_present
    end
  end

  def wait_loader
      @browser.div(:class=>'loader').wait_while_present
  end

  #use in profile and account page
  def wait_for_loading
    @browser.div(:class=>'loading').wait_while_present
  end

  def wait_for_predictive_search
    # @browser.div(:class=>'predictive-results').li(:text => /Searching/).wait_while_present

    @browser.wait_until do
      @browser.div(:class=>'predictive-results').li(:index =>0).visible?
    end
  end





 end
