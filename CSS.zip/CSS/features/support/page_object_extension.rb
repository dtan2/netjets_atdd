module PageObject
  module Elements
    class TextField
      def type(text, wait=0.05)
        text.each_char do |char|
          element.send_keys(char)
          sleep wait
        end
      end
    end
  end
end
