#module UrlSelector


def select_login_url(application)
    url_hash = {}

    case test_environment.downcase
      when 'itg2'
        url_hash = {
            "op_login" => 'http://flydev.netjets.com/Account/Authenticate/LogOn?unauthorized=true',
            "op_enroll" => 'http://flydev.netjets.com/Account/Enroll',
            "op_admin_login" => "http://itg2naf.netjets.com/css-admin-web/login"
        }
      when 'qa'
        url_hash = {
            "op_login" => 'http://flyqa.netjets.com/Account/Authenticate/LogOn',
            "op_enroll" => 'http://flyqa.netjets.com/Account/Enroll',
            "op_admin_login" => "http://securityserviceqa.webservice.netjets.com/css-admin-web/login",
            'opop_clear_payments' => 'https://ftwqa.netjets.com/invoke/removeAllInvoicePaymentStatuses'
        }
      when 'patch'
        url_hash = {
            #"op_admin_login" => "http://bdla6720:9080/css-admin-web/login",
            "op_admin_login" => 'http://reservationservicepatch.webservice.netjets.com/css-admin-web/login',
            "op_enroll" => 'https://flypatch.netjets.com/Account/Enroll',
            "op_login" => 'https://flypatch.netjets.com/Account/Authenticate/LogOn'
        }
      when 'itg1'
        url_hash = {
            "op_login" => 'http://test.netjetsus-ownerportal.fortunecookie.co.uk/Account/Invoices/Authenticate/LogOn',
            "op_enroll" => 'http://test.netjetsus-ownerportal.fortunecookie.co.uk/Account/Enroll',
            "op_admin_login" => "http://itgnaf.netjets.com/css-admin-web/login",
            'opop_clear_payments' => 'https://ftwci.netjets.com/invoke/removeAllInvoicePaymentStatuses'
        }
      else
        fail "Could not get URL. Invalid test environment: #{$test_environment}, please re-run with a valid environment"
    end
    puts "Accessing Application #{application} at URL: #{url_hash[application.downcase]}"
    @url = url_hash[application.downcase]

  end

#end




