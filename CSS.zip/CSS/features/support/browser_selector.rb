class BrowserSelector

  def self.create_browser(browser_code = nil)

    puts "Creating a browser instance for #{browser_code}..."
    #profile = Selenium::WebDriver::IE::Profile.new
    #profile.assume_untrusted_certificate_issuer = false
    case browser_code
      when 'firefox'
        browser_instance = Watir::Browser.new :firefox

      when 'ie'
        browser_instance = Watir::Browser.new(:ie, :introduce_flakiness_by_ignoring_security_domains => true)

      when 'chrome'
        browser_instance = Watir::Browser.new :chrome


      else
        raise "create a TEST_BROWSER env variable to continue"
    end
    browser_instance
  end


end