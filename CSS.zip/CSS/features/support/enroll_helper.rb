require_relative '../pages/css_admin/account_search_page'
require_relative '../pages/css_admin/enroll_page'
require_relative '../pages/generic/netjets_webmail_login_page'
require_relative '../pages/generic/netjets_webmail_inbox_page'

def enroll_user_without_financial_permissions(enrollee_data)
  search_for(enrollee_data[:account_name])
  open(enrollee_data[:account_name])
  enroll_user(enrollee_data[:individual_id])
  login_to_webmail
  open_complete_enrollment_page(enrollee_data[:individual_email])
end
