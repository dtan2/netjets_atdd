#
#module Date
#
#
#
#  def is_a_holiday?
#    #TODO: need to define method so it parses XML file with holidays
#  end
#end
