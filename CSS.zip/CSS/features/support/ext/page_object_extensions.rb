module PageObject
  module Elements

    class Table
      def [](idx)
        idx = find_index_by_title(idx) if idx.kind_of?(String)
        return nil unless idx
        initialize_row(element.rows[idx], :platform => :watir_webdriver)
      end

      def initialize_row(row_elements, platform)
        rows = [row_elements].flatten.map { |row_element|
          ::PageObject::Elements::TableRow.new(row_element, platform)
        }
        (rows.size == 1) ? rows.first : rows
      end

    end
  end
end