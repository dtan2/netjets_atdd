require 'monetize'

module Monetize
  def self.parse(input, currency = Money.default_currency, options = {})
    if input.include?('(') && input.include?(')')
      input = input.to_s.strip.delete('()').reverse.concat('-').reverse
    else
      input = input.to_s.strip
    end


    computed_currency = if options.fetch(:assume_from_symbol) { assume_from_symbol }
                          compute_currency(input)
                        else
                          input[/[A-Z]{2,3}/]
                        end

    currency = computed_currency || currency || Money.default_currency
    currency = Money::Currency.wrap(currency)

    fractional = extract_cents(input, currency)
    Money.new(fractional, currency)
  end
end