require 'yaml'
require 'base64'

class InputDataHelper

  def self.load_yml(yml)
    @input_data = YAML.load_file("features/support/page_input_data/#{yml}.yml")
  end

  def self.get_map(key)
    @input_data[key]
  end

end

