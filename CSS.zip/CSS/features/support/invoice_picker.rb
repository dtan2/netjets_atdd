module InvoicePicker
  def self.select_invoice_ids_whose_sum_is_less_than_or_equal_to_dollar(invoices_and_amounts)
    running_total = 0.0
    invoices_and_amounts.collect do |item|
      if (running_total + item[1]) < 1.00
        running_total += item[1]
        item[0]
      end
    end.compact
  end
end