

Before do
  begin
    @browser = BrowserSelector.create_browser ENV['TEST_BROWSER'] || 'chrome'
    @browser.window.maximize
  rescue => e
    fail(e)
  end

end



After do
  @browser.close if 'yes' == (ENV['CLOSE_BROWSER'] || $close_browser)
end

#clear up the photo
Before do
  Dir["screenshots/*.*"].each do |file|
    File.delete Dir.pwd + '/' + file
  end
end


After do |scenario|
  if (scenario.failed? || scenario.status == :pending)
    @browser.windows.each_with_index do |window, index|
      window.use do
        screenshot_name = "screenshots/error_#{Time.now.to_i}"
        warn "Capturing failed test screenshot files to #{screenshot_name}"
        @browser.driver.save_screenshot screenshot_name + "_window_#{index+1}.png"
        embed screenshot_name + "_window_#{index+1}.png", 'image/png'

        if @browser.respond_to?('xml')
          File.open("#{screenshot_name}.xml", 'w') { |f| f.write(@browser.xml) }
        end
        if @browser.respond_to?('text')
          File.open("#{screenshot_name}.txt", 'w') { |f| f.write(@browser.text) }
        end

      end
    end
  end
end




