class Session
  # this class can be used to store data to a hash of the class
  # for example...
  #
  # Session[:new_item] = 'data'
  #
  # The above line of code will create a relationship between
  # the hash[key] Session[:new_item] and the value 'data'.
  # Therefore whenever Session[:new_item] is called it will return 'data'

  def self.[]=(key, value)
    @@hash ||= {}
    @@hash[key] = value
  end

  def self.[](key)
    @@hash[key]
  end

  def self.load_default_data
    load_stored_data = default_data
    load_stored_data.each do |key, value|
      self.[]=(key, value)
    end
  end

end