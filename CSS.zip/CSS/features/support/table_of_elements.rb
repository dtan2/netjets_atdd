module PageObject
  module IndexedProperties

    class RowOfElements

      attr_writer :attribute_names

      def click
        send("#{@attribute_names[0]}_element").click
      end

      def text
        attribute_text = []
        @attribute_names.each do |attribute_name|
          attribute_text << (eval "#{attribute_name.to_s}_element.text")
        end
        attribute_text.join(' ')
      end

      def visible?
        visible = false
        @attribute_names.each do |attribute_name|
          visible ||= eval attribute_name.to_s+"_element.visible?"
        end
        visible
      end

      def exists?
        exists = false
        @attribute_names.each do |attribute_name|
          exists ||= send attribute_name.to_s+"?"
        end
        exists
      end
    end

    class TableOfElements

      def [] (index)
        r = RowOfElements.new(@browser, index, @identifier_list)
        r.attribute_names = self.attribute_names
        r
      end

      def text
        attribute_text = []
        self.each do |recipient|
          attribute_text << recipient.text
        end
        attribute_text.join(' ')
      end

      def size
        size = 0
        row_exists = true
        while row_exists
          x = self[size]
          x.attribute_names = self.attribute_names
          if x.exists?
            size +=1
          else
            row_exists = false
          end
        end
        size
      end

      def each
        current_index = 1
        row_exists = true
        while row_exists
          x = self[current_index]
          x.attribute_names = self.attribute_names
          if x.exists?
            yield x
            current_index +=1
          else
            row_exists = false
          end
        end
      end

      def find
        current_index = 1
        row_exists = true
        result = false
        x = nil
        while row_exists
          x = self[current_index]
          x.attribute_names = self.attribute_names
          if x.exists? && !result
            result = yield x
            current_index +=1
          else
            row_exists = false
          end
        end
        x
      end

      def each_with_index
        current_index = 1
        row_exists = true
        while row_exists
          x = self[current_index]
          x.attribute_names = self.attribute_names
          if x.exists?
            yield x, current_index
            current_index +=1
          else
            row_exists = false
          end
        end
      end

      def select
        results = []
        #each do |element|
        #  if yield element
        #    results << element
        #  end
        #end
        (0...self.size).each do |index|
          current = self[index]
          if yield current
            results << current
          end
        end
        results
      end

      def attribute_names
        @identifier_list.collect do |identifier|
          identifier[1].to_sym
        end
      end
    end
  end
end