require 'active_record'
require 'oci8'
require 'logger'

def set_database_env_to_qa
  {
      adapter: 'oracle_enhanced',
      host: 'ijet2dv4',
      port: 1521,
      database: 'ijet2dv4',
      username: 'EVEREST_APP_TEAM',
      password: 'r1pp3rc3r'
  }
end

def set_database_env_to_patch
  {
      adapter: 'oracle_enhanced',
      host: 'ijet2dv4',
      port: 1521,
      database: 'ijet2dv4',
      username: 'EVEREST_APP_TEAM',
      password: 'r1pp3rc3r'
  }
end

def set_database_env_to_itg1
  {
      adapter: 'oracle_enhanced',
      host: 'ijet2dv4',
      port: 1521,
      database: 'ijet2dv4',
      username: 'EVEREST_APP_TEAM',
      password: 'r1pp3rc3r'
  }
end

def set_database_env_to_itg2
  {
      adapter: 'oracle_enhanced',
      host: 'ijet2dv4',
      port: 1521,
      database: 'ijet2dv4',
      username: 'EVEREST_APP_TEAM',
      password: 'r1pp3rc3r'
  }
end

database_env = send("set_database_env_to_#{test_environment.downcase}")

class BillingEntity < ActiveRecord::Base
  self.abstract_class = true
  self.inheritance_column = 'column_that_is_not_type'
end

BillingEntity.establish_connection(
    adapter: database_env[:adapter],
    host: database_env[:host],
    port: database_env[:port],
    database: database_env[:database],
    username: database_env[:username],
    password: database_env[:password]
)
# puts "Using #{BillingEntity.connection.current_database} as database"

ActiveRecord::Base.logger = Logger.new(STDERR)
ActiveRecord::Base.logger.level = Logger::DEBUG
