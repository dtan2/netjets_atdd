require_all 'features/pages'
# World(PageObject::PageFactory)

PageObject::PageFactory.routes = {
    :default => [[LoginPage, :login_application_with],
                 [HomePage, :select_plan_book_flight_link],
                 [FlightsPage, :set_req_data_for_reservation],
                 [PassengersPage, :set_req_data_for_passenger_manifest],
                 [CateringPage, :select_ground_transportation_button],
                 [GroundPage, :select_review_and_request_button],
                 [ReviewAndRequest, :verify_on_review_and_request_page]],

    :self_enroll => [[LoginPage, :open_self_enroll_page],
                     [SelfEnrollPage, :submit_enrollment],
                     # [SelfEnrollConfirmPage, :go_to_login_page],
                     [NetjetsWebmailLoginPage, :login_to_webmail],
                     [NetjetsWebmailInboxPage, :open_complete_self_enrollment_page],
                     [CompleteSelfEnrollPage, :complete_self_enrollment_route],
                     [HomePage, :verify_on_home_page]],

    :css_admin_individual => [[CssAdminLoginPage, :login_to_css_admin_with],
                              [AccountSearchPage, :search_from_yaml],
                              [IndividualPage, :verify_on_page]],

    :css_admin_enroll => [[CssAdminLoginPage, :login_to_css_admin_with],
                          [AccountSearchPage, :search_from_yaml],
                          [IndividualPage, :enroll_a_not_enrolled_user],
                          [NetjetsWebmailLoginPage, :login_to_webmail],
                          [NetjetsWebmailInboxPage, :open_complete_enrollment_page],
                          [CompleteEnrollmentSecurityPage, :submit_security_enrollment_answer_as],
                          [CompleteEnrollmentPasswordPage, :submit_enrollment_password_as],
                          [HomePage, :verify_on_home_page]],

    :webmail => [[NetjetsWebmailLoginPage, :login_to_webmail],
                 [NetjetsWebmailInboxPage, :open_reset_password_page]]
}
