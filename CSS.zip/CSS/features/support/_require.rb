require 'page-object'
require 'rubygems'
require 'watir-webdriver'

require "page-object/page_factory"
require "watir-webdriver"
require "watir-webdriver/wait"
require "selenium-webdriver"
require 'data_magic'
require 'require_all'
require 'workflow'
# require 'monetize'
#Setup environment for page.wait_for_ajax method
PageObject.javascript_framework = :jquery
require_relative "../support/browser_selector"
require_relative "../support/url_selector"
require_relative '../support/login_helper'
require_relative 'ext/page_object_extensions'
require_relative 'ext/monetize_extensions'
require 'rspec'

include RSpec::Matchers
World(PageObject::PageFactory)

def test_environment
  ENV['TEST_ENVIRONMENT'] || $default_environment
end
