require 'rspec'
require_relative '../features/support/invoice_picker'

describe InvoicePicker do
  it 'returns an empty array if there are no invoices'  do
    invoices_and_amounts = {}
    invoice_ids = InvoicePicker.select_invoice_ids_whose_sum_is_less_than_or_equal_to_dollar(invoices_and_amounts)
    expect(invoice_ids).to be_empty
  end

  it 'returns an empty array if the invoice values are above a dollar' do
    invoices_and_amounts = {1200012=>1.01, 1200013=>1.50, 1200014=>500.0 }
    invoice_ids = InvoicePicker.select_invoice_ids_whose_sum_is_less_than_or_equal_to_dollar(invoices_and_amounts)
    expect(invoice_ids).to be_empty
  end

  it 'returns an array with invoice ids that are below a dollar' do
    invoices_and_amounts = {1200001=>0.01, 1200002=>0.02, 1200003=>0.03}
    invoice_ids = InvoicePicker.select_invoice_ids_whose_sum_is_less_than_or_equal_to_dollar(invoices_and_amounts)
    expect(invoice_ids).to eq [1200001,1200002,1200003]
  end

  it 'returns an array with invoice ids summing to less than a dollar' do
    invoices_and_amounts = {1200001=>0.01, 1200002=>1.03, 1200003=>0.03, 1200004=>0.72, 1200005=>0.25}
    invoice_ids = InvoicePicker.select_invoice_ids_whose_sum_is_less_than_or_equal_to_dollar(invoices_and_amounts)
    expect(invoice_ids).to eq [1200001,1200003,1200004]
  end
end
